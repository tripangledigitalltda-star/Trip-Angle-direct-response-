# Parecer de compliance

## Cabeçalho
Projeto · peça ou pasta revisada · versão e data · país · categoria do produto · nicho · políticas e normas conferidas e data da conferência · revisor (agente) · decisão do operador (pendente, aprovado, aprovado com ajustes, reprovado).

## Resumo
| Peça | Tipo | Semáforo | Pontos vermelhos | Pontos amarelos | Documento pendente |

## Pontos por peça
| # | Trecho literal ou descrição da imagem | Onde (linha, tempo, bloco) | Categoria | Semáforo | Por que é risco | Regra (política ou norma) | Versão segura | Prova necessária para manter |

Categorias: atributo pessoal · resultado ou promessa · saúde ou medicamento · antes e depois · autoridade ou prova · depoimento · urgência ou escassez · renda · interface falsa · IA ou identidade · continuidade · dados pessoais · identificação do fornecedor.

## Checklist de página e checkout
- [ ] Rótulo de publicidade em advertorial
- [ ] Nome empresarial e CNPJ ou CPF
- [ ] Endereço físico e eletrônico e canal de atendimento
- [ ] Preço total, parcelas e custos adicionais antes da confirmação
- [ ] Condições da oferta, restrições e garantia descritas
- [ ] Direito de arrependimento de 7 dias informado
- [ ] Política de privacidade e termos de uso acessíveis
- [ ] Consentimento claro na captura de dados; dado de saúde só se necessário
- [ ] Anúncio, página e checkout com a mesma promessa e as mesmas condições
- [ ] Sem timer falso, escassez sem prova ou notificação falsa
- [ ] Aviso "resultados variam" junto de casos e depoimentos
- [ ] Recomendação de acompanhamento profissional quando o tema for saúde

## Risco consolidado
Baixo · Médio · Alto, com os três principais motivos e o que reduz o risco mais rápido.

## Documentos pendentes
| Claim ou elemento | Documento necessário (prova, autorização, registro, contrato, licença) | Responsável | Status |
