# Claims de risco e versões seguras por nicho

Cada linha: o padrão arriscado, por que é risco e como manter a força. Versões seguras são moldes; adapte à prova real da oferta.

## Emagrecimento
| Padrão arriscado | Risco | Versão segura (molde) |
|---|---|---|
| "Perca 10 kg em 7 dias" | Resultado irreal e específico sem prova; Meta saúde; CDC 37 | "O protocolo de [N] dias que organiza sua alimentação para [benefício de rotina]" |
| "Sem dieta e sem exercício" | Enganoso por omissão; resultado improvável | "Sem cortar tudo o que você gosta: [mecanismo de adaptação]" |
| "Mounjaro natural", "Ozempic de pobre", "canetinha caseira", grafias ofuscadas | Associação a medicamento de prescrição; burla de revisão; ANVISA | Remover nome e alusão; falar do mecanismo alimentar: "o jeito de montar o prato que [benefício]" |
| "Você está acima do peso?" | Atributo pessoal | "Para quem sente que a calça apertou depois dos 40" ou pergunta aberta sobre rotina |
| Antes e depois, barriga em close, balança | Meta saúde; imagem de resultado improvável | Demonstração de receita, rotina, processo; pessoa em situação neutra |
| "Queima gordura", "derrete", "acelera o metabolismo" como efeito do infoproduto | Alegação fisiológica sem prova | "Receitas que ajudam a manter a saciedade" (se houver base) ou foco em praticidade |
| "Detox elimina toxinas" | Alegação sem base; saúde | "Cardápio leve de [N] dias para reorganizar a rotina" |
| "Médico revela", "Harvard", "Nobel", "estudo comprova" | Autoridade não verificável ou não pertinente; CDC 38 | Citar só fonte real, específica e pertinente; senão, explicação do mecanismo sem autoridade |
| "Perdi 15 kg" em depoimento | Resultado atípico apresentado como típico; autorização | Depoimento real, autorizado, com contexto e aviso de que resultados variam |

## Saúde e suplementos
| Padrão arriscado | Risco | Versão segura |
|---|---|---|
| "Cura", "trata", "reverte" doença | Alegação terapêutica; ANVISA; CDC 37 | Hábito e bem-estar, sem doença |
| "Controla diabetes", "baixa a pressão" | Alegação medicamentosa | Remover; sugerir acompanhamento profissional |
| "Substitui o remédio" | Risco à saúde; abusiva | Proibido; nunca sugerir |
| "Aprovado pela ANVISA" para infoproduto ou produto sem registro | Falso | Só se houver registro real e aplicável, com número |
| "100% natural, sem efeitos colaterais" | Absoluto e sem prova | Ingredientes listados; recomendação de consultar profissional |

## Renda e finanças
| Padrão arriscado | Risco | Versão segura |
|---|---|---|
| "Ganhe R$ 500 por dia" | Renda garantida; Meta práticas comerciais | "Aprenda o método de [processo] que [aluno real] usou para [resultado documentado], resultados variam" |
| "Sem esforço", "trabalhe 1 hora" | Enganoso | Tempo real de dedicação exigido |
| "Fique rico", "liberdade financeira garantida" | Promessa improvável | Habilidade, processo, primeiro resultado mensurável |
| Print de ganhos sem contexto | Prova seletiva | Caso documentado, autorizado, com período e contexto |

## Relacionamento e espiritualidade
| Padrão arriscado | Risco | Versão segura |
|---|---|---|
| "Faça ele voltar em 7 dias" | Resultado garantido sobre terceiros | Comunicação, autoconhecimento, passos práticos |
| "Oração que atrai dinheiro", "quebra maldição" | Exploração de superstição; CDC 37 abusiva | Prática, reflexão, rotina; sem promessa material |
| "Você está sozinha", "seu casamento está acabando" | Atributo pessoal | Situação reconhecível em terceira pessoa |

## Beleza e estética
| Padrão arriscado | Risco | Versão segura |
|---|---|---|
| "Rejuvenesça 10 anos" | Resultado irreal | Rotina de cuidados e benefício sensorial |
| Antes e depois de pele sem controle | Enganoso; Meta | Demonstração de uso com condições iguais e autorização |

## Pressão e urgência (todos os nichos)
| Padrão arriscado | Risco | Versão segura |
|---|---|---|
| Timer que reinicia, "últimas 3 vagas" sem limite real | CDC 37 enganosa; Meta | Prazo real de lote, bônus ou turma, com data verificável |
| "Só hoje" permanente | Enganoso | Condição com data de término cumprida |
| Notificação falsa de compra | Enganoso | Remover |
