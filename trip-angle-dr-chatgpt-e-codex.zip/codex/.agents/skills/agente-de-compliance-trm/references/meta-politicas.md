# Padrões de Publicidade da Meta mais acionados em direct response

Resumo operacional. A política vigente está na Central de Transparência da Meta (Padrões de Publicidade); confira o texto atual e registre a data antes de parecer em categoria sensível. Nomes e escopo das seções mudam.

| Tema | O que costuma gerar reprovação ou restrição | Como ajustar |
|---|---|---|
| Atributos pessoais | Afirmar ou insinuar característica pessoal do público: saúde, peso, condição médica, finanças, orientação, religião, etnia, antecedentes. Ex.: "Você está acima do peso?", "Seu diabetes..." | Falar da situação ou do tema, não da pessoa: "Para quem quer...", "Mulheres depois dos 40 relatam..." (se houver fonte) |
| Saúde e bem-estar, perda de peso | Antes e depois; foco em partes do corpo com enquadramento negativo; resultados irreais ou rápidos; promover produtos de emagrecimento para menores; segmentação etária inadequada | Demonstração do processo, rotina, receitas; público 18+; sem prazo e quilos prometidos |
| Medicamentos com prescrição | Anunciar ou sugerir venda, substituto ou versão "natural" de medicamento de prescrição; usar nome comercial ou substância | Remover nome de medicamento e comparação com ele; falar de hábito, alimentação, rotina |
| Suplementos e substâncias | Produtos ou ingredientes proibidos ou sem segurança; alegações de tratamento | Alegações permitidas pelo órgão regulador; sem cura ou tratamento |
| Afirmações enganosas ou falsas | Promessas de resultado improvável, falsa descoberta, falsa notícia, falsa associação com celebridade, órgão público ou mídia | Mecanismo explicado sem garantia; sem logos e nomes de terceiros sem autorização |
| Conteúdo sensacionalista ou chocante | Imagens chocantes, medo excessivo, conteúdo que explora vulnerabilidade | Contraste sem choque; tensão pela situação |
| Oportunidades de renda e práticas comerciais | Renda garantida, enriquecimento rápido, pouco esforço para muito dinheiro, esquemas de pirâmide, ocultar custos | Descrever o que se aprende e o processo; resultados como exemplo documentado, não como típico |
| Funcionalidade inexistente | Botões falsos de play, notificações falsas, caixas de seleção ou interfaces que enganam | Imagem sem elemento de interface falso |
| Página de destino | Página que não corresponde ao anúncio, sem funcionar, com pop-ups que impedem saída, ou que muda depois da revisão | Continuidade anúncio → página; página estável |
| Burla de sistemas | Cloaking, contas de terceiros para contornar bloqueio, grafias ofuscadas para escapar da revisão, alterar destino após aprovação | Não fazer. Contingência é conformidade |
| Conteúdo gerado por IA | Pessoa sintética apresentada como real, depoimento sintético, uso de imagem ou voz de pessoa real sem autorização; falta de rótulo quando exigido | Rótulo quando exigido; avatar não se passa por cliente ou especialista |
| Categorias especiais | Crédito, emprego, moradia e temas sociais exigem declaração de categoria e têm segmentação restrita | Declarar a categoria correta na campanha |

Sinais de risco de conta: reprovações repetidas no mesmo tema, contestações sem ajuste, uso de grafia ofuscada ("m0unj4r0") para evitar revisão, reclamações de usuários e baixa nota de qualidade de página.
