# Leis e normas brasileiras aplicáveis à publicidade de direct response

Referência operacional, não parecer jurídico. Confira o texto vigente no Planalto, na ANVISA, no CONAR e nos conselhos profissionais antes de parecer em categoria regulada.

## Código de Defesa do Consumidor (Lei 8.078/1990)
- **Art. 30 e 31:** oferta e apresentação obrigam o fornecedor e devem trazer informação clara, precisa e ostensiva sobre características, preço, prazos e riscos.
- **Art. 36:** a publicidade deve ser identificada como tal de forma fácil e imediata. Advertorial precisa de rótulo.
- **Art. 37:** proíbe publicidade enganosa (inclusive por omissão de dado essencial) e abusiva (que explora medo, superstição, deficiência de julgamento, ou induz a comportamento prejudicial à saúde ou segurança).
- **Art. 38:** o ônus de provar a veracidade da informação é de quem a patrocina. Guarde a prova de cada claim.
- **Art. 49:** direito de arrependimento em 7 dias para compras fora do estabelecimento, como internet, com devolução dos valores pagos. Garantia comercial pode ampliar, nunca reduzir.

## Decreto 7.962/2013 (comércio eletrônico)
Página de venda deve informar com destaque: nome empresarial e CNPJ ou CPF, endereço físico e eletrônico, características do produto, preço total com despesas adicionais, condições da oferta e restrições, e informações sobre o exercício do direito de arrependimento. Atendimento eletrônico eficaz e confirmação imediata da compra.

## CONAR (Código Brasileiro de Autorregulamentação Publicitária)
Princípios de apresentação verdadeira, identificação publicitária, respeito à dignidade e não exploração de medo ou superstição. Testemunhos e depoimentos devem ser reais, representar opinião genuína e ter autorização; resultados atípicos não podem ser apresentados como típicos. Anexos específicos tratam de categorias como alimentos, produtos farmacêuticos e cosméticos: confira o anexo aplicável.

## ANVISA
- **Medicamentos:** propaganda regida pela Lei 9.294/1996 e pela RDC 96/2008. Medicamento de venda sob prescrição não pode ter propaganda dirigida ao público leigo. Não associe produto próprio a nome de medicamento nem sugira substituição.
- **Suplementos alimentares:** RDC 243/2018 e normas relacionadas definem ingredientes e alegações permitidas. Alegação fora da lista, terapêutica ou de cura, é irregular.
- **Alimentos e cosméticos:** não podem ter alegação terapêutica ou medicamentosa.
- Infoproduto (ebook, curso, protocolo alimentar) não é registrado na ANVISA, mas não pode prometer tratamento ou cura nem sugerir substituir tratamento médico.

## LGPD (Lei 13.709/2018)
Captura de dados em quiz, página e checkout exige finalidade informada, base legal (em regra consentimento para marketing), política de privacidade acessível e respeito aos direitos do titular. Dado de saúde é dado sensível: coletar só o necessário e com consentimento específico. Pixel e cookies devem constar da política.

## Conselhos profissionais
- **Médicos:** publicidade médica regida por resolução do CFM (Resolução CFM 2.336/2023 e atualizações). Médico em anúncio exige cuidado com promessa de resultado, antes e depois e autopromoção.
- **Nutricionistas, psicólogos, educadores físicos e outros:** cada conselho tem código de ética com regras de publicidade. Profissional real em criativo precisa estar de acordo com o próprio conselho.
- Nunca usar pessoa ou avatar vestido de profissional de saúde para dar autoridade a claim.

## Ofertas financeiras e de renda
Promessa de rendimento de investimento pode envolver regras da CVM. Esquemas de pirâmide são ilícitos. Renda com infoproduto: resultado como exemplo documentado e autorizado, com aviso de que não é típico nem garantido.
