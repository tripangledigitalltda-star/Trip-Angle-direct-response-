// Percorre um quiz de funil clicando a primeira opção de cada tela e "Continuar" quando existir.
// Para antes de botões de compra/checkout e de links externos. Retorna o texto de cada tela e a URL final.
// Uso: colar no console; rodar de novo se a tela travar (telas com imagem-botão precisam de clique manual).
(async () => {
  const BUDGET_MS = 36000, MAX_STEPS = 20;
  const vis = e => e.offsetParent !== null;
  const steps = []; const t0 = Date.now();
  for (let i = 0; i < MAX_STEPS && Date.now() - t0 < BUDGET_MS; i++) {
    await new Promise(r => setTimeout(r, 1300));
    const root = document.body;
    steps.push(root.innerText.replace(/\n{2,}/g, '\n').trim().slice(0, 900));
    let btns = [...root.querySelectorAll('button,[role=button],a')].filter(b => vis(b) && b.innerText.trim().length > 1 && !/voltar|back/i.test(b.innerText));
    if (!btns.length) btns = [...root.querySelectorAll('div,label,span,p')].filter(b => vis(b) && getComputedStyle(b).cursor === 'pointer' && b.innerText.trim().length > 1 && b.innerText.trim().length < 60);
    if (!btns.length) { steps.push('NO-BTN (clique manual necessário)'); break; }
    const buy = btns.find(b => /comprar|garantir|checkout|pagar|finalizar|adquirir/i.test(b.innerText) || (b.href && /^http/.test(b.href) && !b.href.includes(location.host)));
    if (buy) { steps.push('CTA-> ' + buy.innerText.trim().slice(0, 80) + ' href=' + (buy.href || '')); break; }
    const opt = btns.find(b => !/^(continuar|próximo|avançar|prosseguir)/i.test(b.innerText.trim())) || btns[0];
    steps.push('CLICK: ' + opt.innerText.trim().slice(0, 40));
    opt.click();
    await new Promise(r => setTimeout(r, 700));
    const cont = [...document.body.querySelectorAll('button,[role=button]')].find(b => vis(b) && /^(continuar|próximo|avançar|prosseguir)/i.test(b.innerText.trim()));
    if (cont) cont.click();
  }
  const out = { url: location.href, steps };
  console.log(JSON.stringify(out));
  return out;
})();
