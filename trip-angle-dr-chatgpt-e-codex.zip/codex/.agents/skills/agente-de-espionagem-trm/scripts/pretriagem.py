#!/usr/bin/env python3
"""Pré-triagem heurística de cartões extraídos da Biblioteca de Anúncios.

Uso: python3 pretriagem.py cartoes.json [--md]
Entrada: JSON com lista de cartões (ou objeto com chave "cartoes"/"cards"), cada um com
id, page, start, n, dur, dom, u, body (saída do adlib_extract.js).
Saída: tabela com uma sugestão de rota por cartão e famílias de texto idêntico.

A pré-triagem NÃO decide. Ela ordena o trabalho e aponta descartes prováveis por padrão
de destino; a decisão final exige abrir o destino (skill, seções 4 e 5).
"""
import json, re, sys
from collections import defaultdict
from datetime import date

CHECKOUT = ("pay.hotmart", "hotmart.com", "kiwify", "cakto", "wiapy", "perfectpay", "lastlink",
            "cartpanda", "monetizze", "eduzz", "braip", "ticto", "greenn", "kirvano", "payt.", "pepper.")
SOCIAL = ("instagram.com", "facebook.com", "tiktok.com", "youtube.com", "youtu.be", "t.me", "linktr.ee")
APPSTORE = ("apps.apple.com", "play.google.com")
SPA = ("lovable.app", "vercel.app", "netlify.app", "xpages", "framer.app", "webflow.io")
ECOM_URL = (".shop", "/produto", "/product", "/collections", "/carrinho", "/cart", "myshopify", "nuvemshop", "lojaintegrada")
ECOM_TXT = ("frete", "compre 3", "leve 4", "cupom", "off só hoje", "kit com", "entrega para todo")
WPP_TXT = ("whatsapp", "agende", "avaliação gratuita", "chame no")
LEAD_TXT = ("inscreva", "cadastre", "gratuito", "vagas", "aplicação", "preencha")

def route(c):
    u = (c.get("u") or "").lower(); dom = (c.get("dom") or "").lower(); body = (c.get("body") or "").lower()
    target = u or dom
    flags = []
    if not target and any(k in body for k in WPP_TXT):
        return "E3? WhatsApp direto / local", ["sem URL exposta"]
    if not target:
        return "abrir (sem URL no cartão; ver 'Ver resumo' ou modal por ID)", []
    if any(k in target for k in SOCIAL): return "E4? perfil social ou conteúdo", []
    if any(k in target for k in APPSTORE): return "E5? loja de app", []
    if any(k in target for k in CHECKOUT): return "abrir: checkout direto (oferta pode estar observável no checkout)", []
    if any(k in target for k in ECOM_URL) or sum(k in body for k in ECOM_TXT) >= 2:
        return "abrir: possível E1 e-commerce de catálogo (confirmar se há VSL/página longa: pode ser DR físico)", []
    if "quiz" in target: return "abrir: quiz (percorrer com quiz_walker.js até a oferta)", []
    if any(k in target for k in SPA): flags.append("SPA de funil: abrir no navegador, fetch não funciona")
    if any(k in body for k in LEAD_TXT): flags.append("possível captura/aplicação/lançamento: oferta pode não estar na sessão")
    try:
        d = c.get("dur") or ""
        m, s = d.split(":")[:2] if ":" in d else (0, 0)
        if int(m) >= 5: flags.append("vídeo longo: candidato a VSL")
    except Exception: pass
    return "abrir: página/VSL", flags

def age_days(start):
    try:
        y, m, d = [int(x) for x in start[:10].split("-")]; return (date.today() - date(y, m, d)).days
    except Exception: return None

def main():
    if len(sys.argv) < 2: print(__doc__); sys.exit(1)
    data = json.load(open(sys.argv[1]))
    cards = data if isinstance(data, list) else data.get("cartoes") or data.get("cards") or []
    fam = defaultdict(list)
    rows = []
    for c in cards:
        key = re.sub(r"\W+", " ", (c.get("body") or "").lower()).strip()[:120]
        if key: fam[key].append(c)
        r, flags = route(c)
        a = age_days(c.get("start") or "")
        rows.append((str(c.get("id")), c.get("page", ""), str(c.get("n", "")), f"{a}d" if a is not None else "?", c.get("dom") or "(sem URL)", r, "; ".join(flags)))
    print("| ID | Anunciante | N criativos | Ativo há | Destino | Rota sugerida | Observações |")
    print("|---|---|---|---|---|---|---|")
    for r in rows: print("| " + " | ".join(r) + " |")
    clones = {k: v for k, v in fam.items() if len({x.get('page') for x in v}) > 1}
    print("\nFamílias com texto idêntico em anunciantes diferentes (candidatas a clone; PADRÃO IDENTIFICADO, não vínculo):")
    if not clones: print("- nenhuma")
    for k, v in clones.items():
        print(f"- IDs {', '.join(str(x.get('id')) for x in v)} | anunciantes: {', '.join(sorted({x.get('page','') for x in v}))} | texto: \"{k[:70]}…\"")
    print("\nLembrete: rota sugerida não é decisão. Abra cada destino antes de qualificar, observar ou excluir.")

if __name__ == "__main__": main()
