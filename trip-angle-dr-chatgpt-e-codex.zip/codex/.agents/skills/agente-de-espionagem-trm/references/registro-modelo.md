# Modelos de registro (páginas de mineração no Notion Trip Angle)

## A. Página "Nova Mineração — Funis e Sinais de Escala" (modelo literal, 07 — Nova Mineração Brasil + Colômbia)

Cabeçalho: "Coleta ao vivo na Biblioteca de Anúncios da Meta, com destinos abertos e verificados em <data>." · Mercados · Status: anúncios ativos · Critério: funil verificado + sinais de escala · Fonte.

**Resumo executivo** — quantas ofertas qualificadas, quantas em observação, por quê. Aviso fixo: "Sinal de escala não é comprovação de faturamento. Repetição de anúncios, longevidade e arquitetura do funil mostram investimento e continuidade observáveis, mas não comprovam vendas, lucro ou ROAS."

**Ofertas qualificadas** — tabela: Prioridade | Funil confirmado | Sinal observado | Mercado | Oferta.

**Uma seção por oferta**:
- Destino verificado · Anunciante observado · IDs observados · Início exibido
- Entrada (o que a primeira tela faz)
- Mecanismo de entrada / mecanismo comercial (como a copy explica)
- Estrutura de copy (identidade → inimigo → prazo → prazer preservado, etc.)
- Sinal de mercado (volume da busca, agrupamentos observados) com a ressalva "confirma repetição do mecanismo, mas não vínculo entre as operações"
- Hipótese reutilizável (função, não frase)
- Risco (alegações não validadas)

**Ofertas em observação** — destino, ID, início, motivo (um só cartão; provas não auditadas; referências incoerentes).

**Exclusões relevantes** — o que ficou fora e por quê (já conhecida; produto físico; WhatsApp direto; destino quebrado).

**Padrões reutilizáveis para o próximo teste** — lista numerada (prazo fechado; persona declarada; inimigo nomeado; fases visíveis; entrada de baixa fricção; ativo concreto; prazer preservado).

**Prioridade para o próximo teste** — primeira tese + Variação A/B/C como hipóteses independentes: "Não misturar as três causas no mesmo criativo."

**Limites da pesquisa** — amostra, mutabilidade, o que não foi auditado.

## B. Página "Registro de Evidências — N anúncios" (modelo)
Tabela por cartão: ID | Anunciante | Data de início | Agrupamento (N criativos) | Formato/duração | Destino | Texto (literal, truncado) | Etapa acessada | Observações. Rodapé: "Foram documentados N cartões distintos: X da busca ampla e Y da página <anunciante>, descontando Z sobreposições." Regra de evolução: preservar data e fonte da observação anterior; distinguir mudança real de falha de carregamento; não substituir contagem histórica.

## C. Classificação de cada anotação (Emagrecimento — hub)
| Classificação | Significado | Exemplo |
|---|---|---|
| Dado observado | Informação lida na fonte e datada | ID e data de início exibidos pela Meta |
| Alegação do anunciante | Promessa ou informação comercial não verificada | Preço na copy, prazo de preparo, valor nutricional |
| Interpretação | Nossa leitura do que o anúncio tenta comunicar | Monotonia como obstáculo à constância |
| Hipótese | Ideia que precisa de validação própria | Testar produto organizado por ingrediente |
| Pendente | Ainda não acessado ou confirmado | Checkout, upsell, entrega comprada, vendas |

## D. Ficha de Fonte e Linhagem (Como Ler uma Oferta do Zero)
[ ] URL do anúncio e URL final · [ ] Página/anunciante, domínio, país, idioma · [ ] Data da primeira captura e da revisão · [ ] Texto, headline, criativo, CTA, formato · [ ] Transcrição integral do vídeo/áudio · [ ] Página/VSL/quiz e ordem dos blocos · [ ] Produto, entregáveis, preço, parcelas, garantia, condições · [ ] Checkout, bump, upsell, downsell, pós-compra quando observados · [ ] Evidências ausentes e links quebrados · [ ] Código interno e versão da análise.

## E. Registro na base 19 — Mapa de Oportunidades
Nome (`<OFERTA>-OP0n — <oportunidade>`) · Oportunidade · Lacuna · Tipo (Teste/Pesquisa/Produto) · Prioridade · Base observada (IDs) · Persona · Dor · Desejo · Mecanismo · Ângulo · Funil sugerido · Produto sugerido · Prova necessária · Risco · Confiabilidade (Nível D — Hipótese) · Status (Hipótese). Regra: "Oportunidade derivada de lacuna observada, não de desejo importado dos livros." "Não criar produto novo; revisar a clareza da oferta observada antes de qualquer modelagem" quando a lacuna for de evidência.

## F. Ficha de análise por oferta (Aplicação — seção 7, literal)
Data e fonte · Anunciante e oferta (separadamente) · ID do anúncio ou cartão · País, categoria e status da consulta · Quantidade observada (separar total da página, cartões e agrupamentos) · Data de início informada (não assumir continuidade) · Situação do público sugerida pela copy (interpretação) · Consciência pressuposta (hipótese com justificativa) · Sofisticação e concorrência (não inferir estágio pelo volume) · Headline e lead (observado ou autoral?) · Referência de copy (autor, obra, páginas) · Promessa e mecanismo comercial (alegação) · Produto, preço e condições (fonte) · Formato visual (só o que foi visto) · Destino (link extraído ou página aberta?) · Checkout, complementos e entrega (confirmado/pendente) · Evidência de vendas (normalmente não disponível) · Aprendizado transferível · Hipótese própria · Mapa promessa–prova · Objeções e condições · Decisão e pendências (aprofundar, testar, aguardar ou descartar).

## G. Ficha de oferta das rodadas 04/06/07
Destino · Preço · Anunciante · ID Meta · Início exibido · Status observado · Busca utilizada · Mecanismo comercial · Evidência · Ressalva · (CO) Oferta observada · Mecanismo nomeado · Estrutura de copy · Leitura de copy · Provas que faltam · Aprendizado transferível · Teste recomendado · (07) Sinal observado · Hipótese reutilizável · Risco · Persona · Causa narrada · Sequência da solução · Entregas exibidas.
Tabela de termos: Termo | Total aproximado mostrado pela Meta | Cartões lidos nesta amostra.

## H. Como foram as rodadas anteriores (referência de método)
- Rodada 01 (28/08/2026, BR, "receitas proteicas"): busca ampla → 25 cartões → aprofundar na página do anunciante mais concentrado (28 cartões) → tabela comparativa → ângulos por ID → hipóteses → limitações. Total 49 IDs.
- Rodada 04 (28/08, BR): 10 termos por frente (doces, marmitas, café da manhã, cardápio, pilates, cadeira, caminhada, sem whey, air fryer, saladas) → 17–26 cartões por termo (221 IDs) → abrir cada destino → qualificar só quiz (até a primeira pergunta, sem enviar dados) ou página de vendas digital → excluir físicos, WhatsApp, Instagram, lojas de app, fora do nicho, já conhecidos → 14 ofertas.
- Rodada 06 (29/08, CO): 10 buscas em espanhol, ordenação por impressões → 122 cartões / 56 destinos → 10 ofertas, com "Provas que faltam" e "Leitura de copy".
- Rodada 07 (02/09, BR+CO): critério "funil verificado + sinais de escala" → 4 qualificadas, 2 em observação, exclusões, padrões reutilizáveis, tese + 3 variações.
Entregável da página-mãe: ficha de oferta com fontes, hipótese de posicionamento, três briefs de criativos e plano de medição.

## I. Tabela de triagem (todos os cartões da rodada)
| ID | Anunciante | Destino final | Tipo de funil | Decisão | Categoria e motivo | Confiança (A–D) | Sinais de escala (n, IDs, início) | Família/clone |
Uma linha por cartão aberto; cartões descartados na pré-triagem por categoria óbvia (perfil social, loja de app) também entram, com "Excluída — E4/E5" e a URL. Decisão só entre Qualificada / Em observação / Excluída; motivo com rótulo. Critérios em `triagem-dr.md`.

## J. Ficha de criativo (uma por Ad analisado)
Campos em `analise-de-criativos.md`, seção 2. Anexe ao bloco da oferta correspondente no relatório, pareada por ID.
