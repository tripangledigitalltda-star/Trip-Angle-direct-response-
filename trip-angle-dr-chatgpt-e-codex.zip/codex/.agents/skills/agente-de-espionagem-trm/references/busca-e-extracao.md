# Busca e extração na Biblioteca de Anúncios da Meta

## URLs de busca
- Não ordenada: `https://www.facebook.com/ads/library/?active_status=active&ad_type=all&country=BR&q=<termo>&search_type=keyword_unordered&media_type=all`
- Frase exata: `...&q=%22<termo>%22&search_type=keyword_exact_phrase&media_type=all`
- Detalhe de um anúncio: `https://www.facebook.com/ads/library/?id=<ID>` (abre modal; anúncios de WhatsApp mostram "Enviar mensagem pelo WhatsApp" e não expõem link).
- Colômbia: `country=CO`; termos em espanhol ("gelatina bariátrica", "reinicio metabólico", "plan imprimible").
- Google Ads Transparency Center: busca por anunciante ou domínio, região e período, para confirmar presença fora da Meta.

## Estratégia de termos
1. Termo pedido (acentuado e sem acento).
2. Grafia popular e ofuscada (monjaro, m0unj4r0, "canetinha").
3. Apelidos de mecanismo ("de pobre", "natural", "caseiro", "do jeito certo").
4. Formatos ("protocolo", "método", "truque do", "receita", "chá", "sopa", "gelatina", "desafio").
5. Vizinhos que aparecem nos anúncios lidos (inimigos nomeados, ingredientes, prazos).
6. Assinaturas de operação (domínios lovable.app, vercel.app, netlify.app, xpages.co, .shop; plataformas Wiapy, Cakto, PerfectPay, Kiwify, Hotmart, Lastlink) para achar clones da mesma operação.

## Extração
Cole `scripts/adlib_extract.js` no console (ou via ferramenta de JavaScript do navegador) na página de resultados. Ele:
- rola a página N vezes para carregar mais cartões;
- localiza cada cartão pelo texto "Patrocinado" + "Identificação da biblioteca";
- extrai id, start, n (contagem de criativos), page (anunciante), dom (domínio em caixa alta exibido), u (URL de destino decodificada do l.php quando existe), dur (duração do vídeo), body (texto);
- agrega por anunciante: cards, maxN, sumN, datas, domínios, URLs, durações, amostras de texto, ordenado por sumN.

Interprete `sumN` como sinal de volume dentro da busca, não como total do anunciante. Cartões sem texto costumam ser vídeo-only com link escondido em "Ver resumo".

## Quiz e páginas
- Muitos destinos são SPA (lovable, vercel): use o navegador; `fetch` retorna só o título.
- Trackers: seguir `Location` de RedTrack (`red.track.*`), `click.*/sf/?sfunnel=`, `insight.*`; registrar URL final.
- `scripts/quiz_walker.js` percorre etapas clicando a primeira opção, tratando multi-select (botão "Continuar"), sliders e telas de loading; para antes de botões de compra e de links externos; devolve o texto de cada tela e a URL final. Etapas com botões de imagem exigem clique manual (localizar por acessibilidade).
- Registrar por quiz: número de telas, perguntas literais, tela de mecanismo, prova (áudio, depoimento), diagnóstico (IMC, "zona de alerta"), loading de personalização, oferta (preço, ancoragem, bônus, garantia, escassez, timer), checkout (plataforma, bump).

## Sinais de operação clonada
Mesma copy em anunciantes diferentes; mesmo app em dois domínios; páginas com nomes de chef/nutri trocados e estrutura idêntica (2 planos, 5 bônus, "N pessoas já transformaram", 4.9 de N avaliações, timer com data do dia). Registrar como PADRÃO IDENTIFICADO, sem afirmar vínculo entre as operações.

## Limites obrigatórios no relatório
Amostra não exaustiva; contagens e datas mudam; checkout, order bump, upsell e entrega comprada não auditados salvo quando vistos; alegações de saúde/dinheiro não validadas; anúncio ativo ≠ venda.

## Seeds e snowball
Registre cada consulta como uma seed: termo | tipo de busca (não ordenada / frase exata) | país | data | volume aproximado exibido | o que rendeu (IDs, vizinhos descobertos, zero). A tabela de seeds evita repetir buscas zeradas na rodada seguinte e transforma cada hipótese ("o mercado escreve 'canetinha'") em uma consulta rastreável. Descoberta também por marca, domínio, frase de hook, mecanismo, promessa, idioma e anunciante (SOP da Mineração Avançada). Cobertura de análise: cinco Ads por oferta qualificada.

## Pré-triagem
`scripts/pretriagem.py cartoes.json` lê a saída do extrator e sugere uma rota por cartão (perfil social, loja de app, WhatsApp direto, checkout direto, e-commerce provável, quiz, SPA, página/VSL), calcula há quantos dias o anúncio está ativo e agrupa textos idênticos em anunciantes diferentes. Serve para ordenar a abertura dos destinos; não substitui a abertura.
