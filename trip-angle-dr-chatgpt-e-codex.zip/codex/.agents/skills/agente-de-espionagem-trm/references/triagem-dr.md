# Triagem: o que é e o que não é oferta de direct response

Origem: definição de direct response e de oferta das páginas "01 — Direct Response e Economics", "Conceito Canônico — Oferta", "Conceito Canônico — Funil", "Arsenal de Mineração — Direct Response & Quiz-First" e "Mineração Avançada — Meta Ads" da Trip Angle, mais as regras de exclusão praticadas nas rodadas de mineração de 08–09/2026. O Notion define o conceito; a tabela de decisão e as categorias de exclusão abaixo são **regra operacional derivada** dessa definição, marcada como tal.

## 1. Definição da casa (literal)

"Direct response é uma abordagem de marketing construída para provocar uma ação específica e rastreável em um intervalo curto ou imediatamente após a exposição. Essa ação pode ser uma compra, um cadastro, o início de um checkout, uma mensagem ou outra conversão definida previamente." Quatro componentes: oferta específica, público relevante, mensagem persuasiva, chamada para ação clara. O que descaracteriza: "campanha cujo objetivo principal é apenas construir lembrança de marca ao longo do tempo."

"Oferta é a proposta percebida de troca: produto + stack + condições + preço + ancoragem + risco + prova + urgência/escassez + CTA e, quando observados, bump, upsell e downsell." "Não é apenas produto, copy, VSL, promessa ou funil." "não deve ser preenchido por inferência quando o material não traz evidência."

"Funil é a sequência de entradas, mensagens, páginas, VSL, checkout, entrega, ascensão e possíveis saídas." Caminho público: anúncio, pré-lander, quiz, resultado, captura, VSL ou carta, checkout e continuidade. "Uma sequência de links sem motivo é inventário, não engenharia de Funil."

Limite da fonte: a Biblioteca de Anúncios revela "ângulos, formatos, oferta aparente e maturidade competitiva", e "não revela economics, targeting completo ou causalidade". "A existência de anúncio, landing, quiz, app ou assinatura não prova lucro, volume de vendas ou escala financeira."

## 2. Teste de DR em quatro perguntas (regra derivada)

Responda com o destino aberto. Cada resposta cita o que foi visto.

| # | Pergunta | "Sim" quando | Rótulo do que sustenta |
|---|---|---|---|
| 1 | Ação específica e rastreável? | O anúncio ou a primeira tela pede assistir, responder, iniciar checkout, comprar, cadastrar ou aplicar, com destino próprio. | OBSERVAÇÃO |
| 2 | Oferta observável? | No fluxo público aparecem produto ou entrega definida **e** preço ou condições **e** CTA de decisão. Preço só na copy do anúncio é ALEGAÇÃO DA COPY; preço em página ou checkout é FATO CONFIRMADO. | FATO CONFIRMADO / ALEGAÇÃO DA COPY |
| 3 | Funil com etapa de decisão? | Há página, VSL, quiz ou carta que conduz a checkout, ou a uma captura cuja continuidade está declarada. | OBSERVAÇÃO |
| 4 | Mensagem de resposta direta? | A peça organiza problema ou desejo, mecanismo e alguma prova, e não apenas lembrança de marca, catálogo ou conteúdo. | INTERPRETAÇÃO ESTRATÉGICA |

Quatro "sim" não bastam para qualificar: falta o recorte (seção 0 da skill) e o sinal de escala.

## 3. Tabela de decisão (regra derivada)

| Estado | Entra quando | O que registrar |
|---|---|---|
| **Qualificada** | Destino verificado · quatro "sim" · oferta compatível com o recorte · pelo menos um sinal de escala documentado | Tipo de funil, oferta observada (produto, preço, plataforma), sinais de escala, confiança A ou B, família (se clone) |
| **Em observação** | Funil real mas oferta não observada na sessão · sinal insuficiente (um cartão isolado, sem repetição) · destino fora do ar · provas ou referências incoerentes · gate não contornável antes da oferta | Motivo específico, o que falta ver, data das tentativas, confiança C ou D |
| **Excluída** | Qualquer categoria de exclusão abaixo, ou "não" em uma das quatro perguntas sem chance de mudar com mais navegação | Categoria (E1–E7) e evidência de uma linha |

Sinais de escala que contam (todos são OBSERVAÇÃO, nenhum é prova de venda): contagem "N anúncios usam esse criativo"; número de IDs do mesmo anunciante na busca; data de início antiga com anúncio ainda ativo (longevidade); repetição do mecanismo ou da estrutura entre anunciantes independentes. Registre os números com data; não substitua contagem antiga por atual sem anotar a revisão.

## 4. Categorias de exclusão (regra derivada das rodadas)

| Código | Categoria | Como reconhecer | Por que sai |
|---|---|---|---|
| E1 | E-commerce de catálogo | Loja com vários produtos, carrinho, CEP e frete, sem página de vendas, VSL ou quiz | Não há mensagem de resposta direta nem funil de decisão; é varejo |
| E2 | Marca ou institucional | Site da marca, catálogo, "conheça a linha", localizador de lojas, sem oferta nem CTA de conversão | Objetivo é lembrança de marca |
| E3 | Serviço local ou WhatsApp direto | Botão "Enviar mensagem pelo WhatsApp" sem página pública, clínica ou negócio com endereço e agendamento | Funil não é auditável e a oferta não é observável; fora do recorte de infoproduto |
| E4 | Perfil social ou conteúdo | Destino é perfil de Instagram, TikTok, YouTube ou post, sem oferta | Não há etapa de decisão |
| E5 | Loja de app | App Store ou Google Play | Oferta é assinatura in-app fora do funil público; registrar como "app" se o recorte pedir |
| E6 | Fora do recorte | Nicho, país ou tipo de produto diferentes do definido na seção 0 | Ruído para esta rodada; pode virar seed de outra |
| E7 | Já conhecida | Oferta já registrada nas bases | Registra a nova observação (IDs, contagem, data) na ficha existente; não conta como achado novo |

Exclusão sempre vem com o motivo em uma linha e o rótulo. Exemplo: "Excluída — E3: destino é botão de WhatsApp, sem página pública [OBSERVAÇÃO]."

## 5. Casos-limite e a decisão correta

| Situação | Decisão | Por quê |
|---|---|---|
| Anúncio manda direto para checkout (Hotmart, Kiwify, Cakto, Wiapy, PerfectPay, Lastlink, CartPanda) com produto e preço visíveis | **Qualificada**, funil "checkout direto", ressalva "página de vendas não localizada" | Oferta observada (produto, preço, CTA); funil curto ainda é funil |
| Advertorial ou pré-lander que leva a VSL ou página | Classifique pelo **destino final**; registre o advertorial como etapa | Pré-lander é entrada, não oferta |
| Quiz que termina em captura de e-mail ou WhatsApp sem oferta na sessão | **Em observação**, "funil de captura; oferta NÃO MAPEADA"; qualifica só se o recorte incluir funis de lead | Ação rastreável existe, oferta não |
| Página de aplicação para mentoria ou acompanhamento (formulário, sem preço) | **Em observação**, "funil de aplicação"; qualifica se o recorte incluir alto ticket | Idem: DR de aplicação, oferta não observável publicamente |
| Evento gratuito, desafio ou webinar com inscrição e promessa de turma depois | **Em observação**, "funil de lançamento"; anotar a data prometida para revisitar | Oferta virá depois; hoje é captura |
| VSL longa em que o preço só aparece após N minutos e não foi assistida até lá | **Em observação** até ver o preço ou alcançar o checkout | Sem preço visto, a oferta é alegação |
| Produto físico (suplemento, gel, chá) vendido por VSL ou página longa com mecanismo e checkout | É **DR físico**: qualifica se o recorte aceitar físico; senão, **Excluída E6** com nota "funil DR, produto físico" | Não confundir com E1; o funil é de resposta direta |
| Vídeo de marca grande com CTA genérico ("saiba mais") para site institucional | **Excluída E2** | Sem oferta nem decisão |
| Destino retorna 404 ou fora do ar | **Em observação** com data e hora de duas tentativas; nunca qualificada | Não há destino verificado |
| Mesma copy ou vídeo em dois anunciantes, checkout em plataformas diferentes | **Família** (clone): uma entrada na lista com os anunciantes listados; PADRÃO IDENTIFICADO | Repetição é sinal de mecanismo em circulação, não duas ofertas nem vínculo provado |
| Anúncio ativo com sinais de violar política (antes/depois, nome de medicamento, promessa de emagrecimento) | Pode qualificar; marcar **risco de compliance** na ficha | "Anúncios ativos podem violar políticas": ativo não é sinal de qualidade |
| Contagem alta, mas destino é perfil ou WhatsApp | **Excluída** (E3/E4) mesmo com sinal de escala | Sinal sem funil auditável não vira oferta |

## 6. Clone, variação ou ângulo novo (literal da Mineração Avançada)

"Só classifique como ângulo novo quando houver mudança substancial de desejo, problema, mecanismo, promessa, persona ou prova; uma troca de apresentador, cenário ou avatar não basta." Classificação por peça: clone (copy, vídeo ou estrutura idênticos), variação (mesmo argumento, execução diferente), ângulo novo. Sinais de operação clonada: mesma copy em anunciantes diferentes; mesmo app em dois domínios; páginas com nome do especialista trocado e estrutura idêntica (dois planos, cinco bônus, "N pessoas já transformaram", 4.9 de N avaliações, timer com a data do dia). Registre a família e a evidência; não afirme que são a mesma empresa.

## 7. Escala de confiança por registro (literal do Arsenal de Mineração)

- **A — confirmado:** observado diretamente em fonte pública primária ou no fluxo público acessível.
- **B — forte:** confirmado por fonte oficial ou metadata consistente, mas com alguma etapa parcial.
- **C — plausível:** sinal indireto, página de loja, conteúdo editorial ou relação provável sem confirmação completa.
- **D — hipótese:** inferência útil para orientar pesquisa, ainda sem evidência suficiente.

Qualificada exige A ou B. "Atualização de escala apenas quando houver sinal observável adicional."

## 8. Erros de leitura que a triagem deve evitar (literais)

Oferta: "Confundir produto com oferta; tratar bônus como prova; aceitar urgência como fato; confundir ancoragem com valor real; omitir condições; chamar bump de produto principal; inferir performance do preço." Funil: "Chamar VSL de funil; listar URLs sem função; inventar etapa ausente; ignorar saída; não mapear checkout/entrega; medir somente entrada; importar arquitetura de outro nicho." Mineração: "'Ativo' ou 'visível' não significa 'vencedor'"; "sem tratar simples presença em loja como prova de atividade publicitária"; "não contorne esses controles nem preencha lacunas por suposição."
