# Páginas, VSL, advertorial e quiz

## 1. Página de vendas ou VSL: estrutura modular (módulo 03)
Use só os blocos necessários e reorganize conforme a consciência:
1 Entrada: headline, subheadline, contexto · 2 Reconhecimento: situação, sintomas, custo · 3 Diagnóstico: mecanismo do problema · 4 Nova oportunidade: mecanismo da solução · 5 Transformação: promessa e para quem é · 6 Como funciona: processo ou demonstração · 7 Prova · 8 Oferta: entregáveis, suporte, limites · 9 Valor e condições: preço, pagamento, custos · 10 Risco: garantia, privacidade, política · 11 Objeções: FAQ priorizada · 12 Ação: CTA e o que acontece depois.

## 2. Página de VSL (regras operacionais)
- Primeira dobra: headline com a mesma promessa do anúncio, player visível sem rolar, legenda ativa.
- Botão e bloco de oferta aparecem no momento em que a VSL apresenta a oferta. O atraso é configurável no modelo. Deixe um link "prefere ler?" para o resumo escrito quando possível.
- Abaixo do player, depois do atraso: stack, preço, garantia, FAQ e o mesmo CTA.
- Não use autoplay com som, não esconda controles e não bloqueie a página.

## 3. Advertorial (pré-lander)
- Formato de matéria ou relato, com rótulo visível de publicidade ou conteúdo patrocinado.
- Estrutura: título de descoberta ou notícia · lead com situação reconhecível · história ou explicação do mecanismo · prova disponível · transição para o próximo passo · CTA textual e botão.
- Não imite marca de veículo de imprensa real, não use logos de mídia sem autorização, não invente especialista.

## 4. Quiz (padrões observados e regras)
Estrutura observada nos quizzes minerados: tela de entrada com promessa e seleção inicial de baixa fricção (idade, gênero, objetivo) · perguntas de situação e rotina · telas informativas de mecanismo entre perguntas · loading de personalização · diagnóstico ou resultado · oferta ou VSL.
Regras:
- Toda pergunta muda o resultado, a recomendação ou a segmentação. Pergunta decorativa sai.
- Resultado baseado nas respostas, sem diagnóstico médico. Em saúde, fale de perfil e hábitos, não de doença.
- Loading de personalização só se o resultado de fato usa as respostas.
- Captura de e-mail ou WhatsApp com consentimento claro e link de privacidade (LGPD).
- Tamanho: o mínimo que sustenta o resultado. Registre a taxa de avanço por tela para cortar depois.

## 5. QA do ativo (módulo 03)
- [ ] Título e anúncio falam da mesma promessa
- [ ] Há um CTA principal
- [ ] Oferta e preço estão claros
- [ ] Prova está próxima do claim
- [ ] Botão explica a ação
- [ ] Formulário pede somente o necessário
- [ ] Página funciona no celular
- [ ] Vídeo tem legenda e controle
- [ ] Carregamento e links foram testados
- [ ] Política, termos, contato, CNPJ, arrependimento de 7 dias e reembolso estão acessíveis
- [ ] O pós-clique e o pós-compra foram definidos
Checkpoint: uma pessoa entende "para quem é, o que recebe, por que acreditar, quanto custa e o que acontece depois" sem falar com você?
