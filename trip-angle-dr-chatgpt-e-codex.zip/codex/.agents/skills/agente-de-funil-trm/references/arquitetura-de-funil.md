# Arquitetura de funil

Origem: módulo 03 — Engenharia de Ofertas, Copy e Vendas (fase 5 e 6) e Conceito Canônico FUNIL da Trip Angle. Tipos observados no mercado vêm das rodadas de mineração 08–09/2026.

## Definição
"Funil é a sequência de entradas, mensagens, páginas, VSL, checkout, entrega, ascensão e possíveis saídas pela qual a pessoa passa. VSL é apenas uma etapa ou formato dentro dessa sequência." Caminho completo: origem → mensagem → ativo → decisão → pagamento → confirmação → onboarding → entrega → aprendizado.

## Escolha pela condição (módulo 03)
| Condição | Rota provável |
|---|---|
| Produto simples e compra autônoma | Anúncio → página → checkout → onboarding |
| Necessidade de educação | Anúncio → VSL ou página → checkout |
| Necessidade de segmentação | Quiz → recomendação → página ou VSL |
| Ticket ou risco alto | Anúncio → aplicação → conversa → proposta |
| Serviço configurável | Entrada → diagnóstico → escopo → proposta |

## Formatos de ativo (módulo 03)
| Formato | Use quando | Cuidado |
|---|---|---|
| Página curta | Oferta simples, familiar, baixo risco | Não omitir informação essencial |
| Página longa | Oferta nova, cara, complexa, muitas objeções | Cada seção reduz uma dúvida |
| VSL | Mecanismo pede narrativa, demonstração ou sequência | Legenda, controles e resumo escrito |
| Quiz ou diagnóstico | Precisa segmentar ou personalizar | Nenhuma pergunta sem efeito na saída |
| WhatsApp ou ligação | Diagnóstico, configuração ou confiança | Qualificar fit, sem pressão |

## Arquiteturas comuns em DR de infoproduto (observadas nas minerações)
| Arquitetura | Quando faz sentido | Risco principal |
|---|---|---|
| Anúncio → checkout direto | Low ticket, oferta óbvia, público muito consciente | Sem espaço para objeções; reembolso |
| Anúncio → página de vendas → checkout | Oferta clara com algumas objeções | Página genérica que repete o anúncio |
| Anúncio → VSL → checkout | Mecanismo novo, consciência de problema | VSL longa sem legenda; preço escondido demais |
| Anúncio → quiz → resultado → VSL ou página → checkout | Público amplo, várias personas, necessidade de diagnóstico | Quiz longo sem efeito; queda entre resultado e oferta |
| Anúncio → advertorial → VSL ou página → checkout | Público pouco consciente, ângulo de notícia ou descoberta | Matéria que parece jornalismo sem identificação de publicidade |
| Anúncio → captura → evento ou conteúdo → oferta | Lançamento, desafio, alto envolvimento | Oferta não observável na primeira sessão |

## Perguntas de passagem (para cada seta)
O que a pessoa acabou de ver? · O que ela espera encontrar agora? · Qual dúvida precisa ser resolvida? · Qual é a única ação principal? · Que dado precisa ser registrado? · O que acontece se ela não avançar?

## Checkpoint (módulo 03)
Cada etapa entrega o que a anterior prometeu? Existem páginas órfãs, CTAs concorrentes, formulário sem destino ou compra sem onboarding?

## Erros de leitura e construção (Conceito Canônico FUNIL)
Chamar VSL de funil · listar URLs sem função · inventar etapa ausente · ignorar saída · não mapear checkout e entrega · medir somente entrada · importar arquitetura de outro nicho.
