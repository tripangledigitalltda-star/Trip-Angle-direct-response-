# Checkout, order bump, upsell e downsell

## 1. Plataformas comuns no Brasil (observadas nas minerações)
Hotmart, Kiwify, Cakto, Wiapy, PerfectPay, Lastlink, CartPanda, Ticto, Greenn, Braip, Eduzz, Monetizze. Nome de parâmetro de rastreio, integração de pixel e API de Conversões, one-click upsell e regras de reembolso variam por plataforma: confirme na documentação atual da plataforma antes de configurar e registre o que foi confirmado.

## 2. Ficha de configuração (entregar preenchida)
Plataforma · produto e ID · nome exibido no checkout · preço e moeda · parcelamento e juros · meios de pagamento (Pix, cartão, boleto) · order bump (produto, preço, texto) · upsell (produto, preço, página, one-click sim/não) · downsell · página de obrigado (URL, próximos passos, acesso) · garantia e política de reembolso · e-mail de acesso · pixel e API de Conversões da plataforma (IDs, eventos) · parâmetros de rastreio aceitos (UTMs ou equivalentes) · webhook ou integração com ferramenta de atribuição · teste de compra (quem fará e quando).

## 3. Order bump, upsell e downsell (regras operacionais)
- **Order bump:** complemento pequeno, relacionado e que acelera ou facilita o resultado do produto principal. Uma frase de benefício, preço claro, desmarcado por padrão.
- **Upsell:** próximo passo lógico depois da compra, que remove o obstáculo seguinte. Página curta ou vídeo curto, com recusa visível.
- **Downsell:** versão menor ou parcelada do upsell recusado, oferecida uma vez.
- Nada que mude as condições da compra principal, nada cobrado sem aceite claro, nenhuma pré-seleção de adicional.
- Cada peça tem copy aprovada pelo AGENTE DE COPY e claim revisado.

## 4. Atritos de checkout (módulo 03)
- [ ] Custo total aparece antes da confirmação
- [ ] Meios de pagamento adequados
- [ ] Política e suporte visíveis
- [ ] Poucos campos e sem cadastro desnecessário
- [ ] Mensagens de erro orientam a correção
- [ ] Confirmação e próximos passos são imediatos
- [ ] Evento de conversão foi validado
"Custos inesperados, falta de confiança, cadastro forçado, processo longo, erros e pouca transparência" são diagnóstico de experiência, não desculpa para aumentar pressão.

## 5. Página de obrigado e onboarding
Confirmação da compra · como acessar e em quanto tempo · primeiro passo do produto · contato de suporte · oferta de upsell só se não houver fluxo de upsell anterior.
