# Tracking do funil

Fonte das regras gerais: `../../agente-de-trafego-trm/references/base-trafego-e-escala.md` e `base-tracking-pro.md`. Aqui fica só o mapa por página.

## Tabela de eventos (modelo)
| Página | Evento | Quando dispara | Parâmetros | Origem | Onde conferir |
|---|---|---|---|---|---|
| Advertorial | PageView; ViewContent opcional | Carregamento; rolagem ou tempo | content_name | Pixel | Gerenciador de Eventos |
| Quiz | PageView; evento personalizado de início e de conclusão | Primeira resposta; tela de resultado | etapa, perfil | Pixel | Gerenciador de Eventos |
| Captura | Lead | Envio com consentimento | — | Pixel + CAPI com event_id | Gerenciador e ferramenta de e-mail |
| VSL | PageView; ViewContent; evento personalizado de CTA exibido | Carregamento; momento do CTA | segundos | Pixel | Gerenciador de Eventos |
| Botão para checkout | InitiateCheckout só se o checkout não disparar | Clique | value, currency | Pixel | Evitar duplicar com a plataforma |
| Checkout | InitiateCheckout, AddPaymentInfo | Pela plataforma | value, currency | Plataforma | Gerenciador e plataforma |
| Compra | Purchase | **Pagamento aprovado** | value, currency, event_id | Plataforma e CAPI deduplicados | Gerenciador, plataforma e atribuição |
| Upsell | Purchase separado ou evento próprio | Aprovação do upsell | value, currency | Plataforma | Idem |

Nome e existência de cada evento dependem da configuração da conta: confirme no Gerenciador de Eventos.

## UTMs atravessando o funil
- Todas as páginas próprias rodam o script de passagem que já vem nos modelos: lê os parâmetros da URL de entrada e acrescenta aos links de próxima etapa e do checkout.
- Confirme o nome dos parâmetros que a plataforma de checkout aceita e mapeie as UTMs para eles.
- Teste com uma URL marcada (`utm_source=teste&utm_campaign=qa_funil`) e confira o registro no checkout e na ferramenta de atribuição.
