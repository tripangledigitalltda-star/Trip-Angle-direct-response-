#!/usr/bin/env python3
"""Radar de temas: conta expressões recorrentes nos textos dos cartões da Biblioteca.

Uso: python3 radar_temas.py cartoes.json [--min-anunciantes 2] [--hoje AAAA-MM-DD]
Entrada: saída do adlib_extract.js (lista ou objeto com "cartoes"/"cards"); campos usados:
id, page, start, n, dur, body. Opcional: "transcricao" por cartão.
Saída: expressões de 2 a 4 palavras presentes em anunciantes diferentes, com difusão,
recência, soma de contagem e classe sugerida (emergente, em alta, perene), mais um
resumo de durações. É triagem de candidatos: o operador consolida o tema lendo as peças.
"""
import json, re, sys, statistics
from collections import defaultdict
from datetime import date

STOP = set("a o as os de da do das dos e é em um uma para por com sem que se seu sua no na nos nas ao à mais como você voce isso esse essa este esta já ja só so até ate ou the and of to".split())

def days(s, hoje):
    try: y, m, d = map(int, s[:10].split("-")); return (hoje - date(y, m, d)).days
    except Exception: return None

def grams(text):
    w = [x for x in re.findall(r"[a-zà-ú0-9]+", text.lower())]
    out = set()
    for k in (2, 3, 4):
        for i in range(len(w) - k + 1):
            g = w[i:i+k]
            if g[0] in STOP or g[-1] in STOP: continue
            out.add(" ".join(g))
    return out

def main():
    a = sys.argv[1:]
    if not a: print(__doc__); sys.exit(1)
    minadv = int(a[a.index("--min-anunciantes")+1]) if "--min-anunciantes" in a else 2
    hoje = date.fromisoformat(a[a.index("--hoje")+1]) if "--hoje" in a else date.today()
    data = json.load(open(a[0]))
    cards = data if isinstance(data, list) else data.get("cartoes") or data.get("cards") or []
    idx = defaultdict(list); body_key = defaultdict(set)
    for c in cards:
        txt = (c.get("body") or "") + " " + (c.get("transcricao") or "")
        body_key[re.sub(r"\W+", " ", txt.lower()).strip()[:120]].add(c.get("page"))
        for g in grams(txt): idx[g].append(c)
    # clones: texto idêntico conta como um anunciante
    def advertisers(cs):
        seen, n = set(), 0
        for c in cs:
            k = re.sub(r"\W+", " ", ((c.get("body") or "") + " " + (c.get("transcricao") or "")).lower()).strip()[:120]
            if k in seen: continue
            seen.add(k); n += 1
        return n, sorted({c.get("page") for c in cs})
    counts = [int(c.get("n") or 0) for c in cards] or [0]
    med = statistics.median(counts)
    rows = []
    for g, cs in idx.items():
        indep, pages = advertisers(cs)
        if len(pages) < minadv: continue
        ages = [d for d in (days(c.get("start") or "", hoje) for c in cs) if d is not None]
        soma = sum(int(c.get("n") or 0) for c in cs)
        recentes = sum(1 for d in ages if d <= 14)
        cls = []
        if indep >= 3 and ages and max(ages) <= 30 and soma > med: cls.append("em alta")
        if indep >= 2 and ages and recentes > len(ages) / 2: cls.append("emergente")
        if indep >= 2 and sum(1 for d in ages if d > 60) >= 2: cls.append("perene")
        rows.append((indep, soma, g, len(pages), pages, [c.get("id") for c in cs], min(ages) if ages else None, max(ages) if ages else None, "/".join(cls) or "candidato"))
    rows.sort(key=lambda r: (-r[0], -r[1]))
    # remove gramas contidos em outro com os mesmos IDs
    kept = []
    for r in rows:
        if any(r[2] in k[2] and set(r[5]) == set(k[5]) for k in kept): continue
        kept.append(r)
    print(f"Amostra: {len(cards)} cartões · mediana de contagem {med} · data de referência {hoje}")
    print("| Expressão | Anunciantes independentes | Páginas | Soma contagem | Ativo há (min–máx dias) | Classe sugerida | IDs |")
    print("|---|---|---|---|---|---|---|")
    for r in kept[:40]:
        print(f"| {r[2]} | {r[0]} | {r[3]} | {r[1]} | {r[6]}–{r[7]} | {r[8]} | {', '.join(map(str, r[5][:8]))} |")
    durs = defaultdict(int)
    for c in cards:
        d = c.get("dur") or ""
        try:
            m, s = map(int, d.split(":")[:2]); t = m*60+s
            durs["≤15 s" if t <= 15 else "16–60 s" if t <= 60 else "1–5 min" if t <= 300 else ">5 min (VSL?)"] += 1
        except Exception: durs["estático ou sem duração"] += 1
    print("\nDurações:", ", ".join(f"{k}: {v}" for k, v in durs.items()))
    print("Lembrete: expressão recorrente é candidata a tema. Circulação não é performance. Clones contam como um anunciante.")

if __name__ == "__main__": main()
