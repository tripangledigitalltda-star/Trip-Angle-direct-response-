// Extrator de cartões da Biblioteca de Anúncios da Meta (rodar no console da página de resultados).
// Uso: colar inteiro; ajustar SCROLLS. Retorna JSON com total exibido, cartões únicos e agregado por anunciante.
(async () => {
  const SCROLLS = 8;
  for (let i = 0; i < SCROLLS; i++) { window.scrollTo(0, document.body.scrollHeight); await new Promise(r => setTimeout(r, 1500)); }
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  const cards = new Set(); let n;
  while (n = walker.nextNode()) {
    if (n.textContent.trim() === 'Patrocinado') {
      let el = n.parentElement;
      while (el && !/Identificação da biblioteca/.test(el.innerText || '')) el = el.parentElement;
      if (el) cards.add(el);
    }
  }
  const skip = ['Saiba mais', 'Ver resumo', 'Ver detalhes do anúncio', 'Enviar mensagem pelo WhatsApp', 'Ver mais'];
  const list = [];
  for (const c of cards) {
    const t = c.innerText; const lines = t.split('\n').map(s => s.trim()).filter(Boolean);
    const id = (t.match(/Identificação da biblioteca: (\d+)/) || [])[1];
    const start = ((t.match(/Veiculação iniciada em ([^\n·]+)/) || [])[1] || '').trim();
    const num = (t.match(/(\d+) anúncios usam/) || [])[1] || '1';
    const pi = lines.findIndex(l => l === 'Patrocinado'); const page = pi > 0 ? lines[pi - 1] : '';
    const rest = lines.slice(pi + 1).filter(l => !/^\d+:\d\d \/ \d+:\d\d$/.test(l) && !skip.includes(l));
    const dom = rest.find(l => /^[A-Z0-9.\-]+\.[A-Z]{2,}$/.test(l) || l === 'WHATSAPP') || '';
    const a = c.querySelector('a[href*="l.php"]'); let u = '';
    try { u = decodeURIComponent(new URL(a.href).searchParams.get('u')); } catch (e) {}
    const dur = (t.match(/0:00 \/ (\d+:\d\d)/) || [])[1] || '';
    list.push({ id, start, n: num, page, dom, u, dur, body: rest.join(' | ').slice(0, 400) });
  }
  const m = {};
  for (const o of list) {
    const p = o.page || '?';
    const a = m[p] = m[p] || { page: p, ids: new Set(), maxN: 0, sumN: 0, starts: new Set(), bodies: new Set(), doms: new Set(), urls: new Set(), durs: new Set() };
    if (a.ids.has(o.id)) continue; a.ids.add(o.id);
    a.maxN = Math.max(a.maxN, +o.n); a.sumN += +o.n;
    if (o.start) a.starts.add(o.start); if (o.body) a.bodies.add(o.body.slice(0, 240));
    if (o.dom) a.doms.add(o.dom); if (o.u) a.urls.add(o.u.slice(0, 120)); if (o.dur) a.durs.add(o.dur);
  }
  const agg = Object.values(m).map(a => ({ page: a.page, cards: a.ids.size, maxN: a.maxN, sumN: a.sumN, starts: [...a.starts].slice(0, 3), doms: [...a.doms], urls: [...a.urls].slice(0, 3), durs: [...a.durs].slice(0, 4), bodies: [...a.bodies].slice(0, 2) })).sort((x, y) => y.sumN - x.sumN);
  const total = (document.body.innerText.match(/~?[\d.]+ resultados|Nenhum anúncio/) || [])[0];
  const uniq = Object.values(list.reduce((acc, o) => { if (o.id && !acc[o.id]) acc[o.id] = o; return acc; }, {}));
  const out = { capturedAt: new Date().toISOString(), url: location.href, total, cards: uniq.length, agg, cardsList: uniq };
  console.log(JSON.stringify(out));
  return out;
})();
