#!/usr/bin/env python3
"""Lista itens de uma pasta pública do Google Drive via embeddedfolderview.

Uso: python3 lab_listar.py [ID_DA_PASTA]   (padrão: TRM LAB CRIATIVOS)
Saída: tipo (pasta/arquivo), nome e id de cada item, para descer com o id de uma subpasta.
"""
import html, re, sys, urllib.request

ID = sys.argv[1] if len(sys.argv) > 1 else "1zvNYizDu7PcgIrRgGm7RDsKP-N88-bBK"
url = f"https://drive.google.com/embeddedfolderview?id={ID}"
req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
page = urllib.request.urlopen(req, timeout=30).read().decode("utf-8", "ignore")
items = re.findall(r'id="entry-([\w-]+)".*?href="([^"]+)".*?flip-entry-title">(.*?)</div>', page, re.S)
if not items:
    print("Nenhum item encontrado (pasta privada, vazia ou layout mudou)."); sys.exit(1)
for iid, href, name in items:
    kind = "pasta" if "/folders/" in href else "arquivo"
    print(f"{kind}\t{html.unescape(name).strip()}\t{iid}")
print(f"\n{len(items)} itens em {ID}")
