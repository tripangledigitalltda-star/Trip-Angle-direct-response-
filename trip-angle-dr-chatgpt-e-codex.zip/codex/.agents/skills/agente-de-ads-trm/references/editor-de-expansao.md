# Editor de expansão criativa

Origem: "04 — Criativos e Biblioteca Visual" (seções 1.1, 1.2, 4.1, 4.4, 5.1, 9.1, 9.2, 9.3, rubrica) e "Mineração Avançada — Meta Ads" (campos de auditoria). Campos literais salvo indicação.

## 1. Decisão por referência

Para cada criativo analisado, feche com os campos da auditoria da Mineração Avançada:

| Campo | Pergunta |
|---|---|
| O que preservar | Qual função persuasiva vale como princípio? (sequência narrativa, tipo de pergunta, categoria de hook, forma de demonstrar, lógica de prova, ritmo ou contraste, relação problema → CTA) |
| O que substituir | Forma, identidade, prova e claim que precisam ser próprios |
| O que não reutilizar | Texto, rosto, cena, depoimento, resultado, música, promessa que a oferta não sustenta |
| Gap promessa/entrega | O que o anúncio promete e o destino não entrega |
| Risco de compliance | Claims sensíveis presentes |
| Próximo teste | Hipótese que esta referência sugere |

## 2. Camadas (não confundir)

Ângulo (perspectiva estratégica) · Hook (primeiro estímulo) · Conceito (ideia central que une mensagem e representação) · Formato (recipiente narrativo) · Execução (peça concreta) · Variação (mudança controlada para aprender sobre uma variável).

## 3. Matriz de conceitos (04, 4.1)

| Ângulo | Hook visual | Hook verbal | Formato | Prova | CTA | Tema de origem | Evidência (IDs) |
|---|---|---|---|---|---|---|---|
| Uma perspectiva por linha | Primeiro frame | Primeira frase | UGC, demo, estático etc. | O que aparece | Próxima ação | Do radar | Referências que sustentam |

Regra da unidade: "Um público dominante. Uma situação principal. Uma mensagem memorável. Uma prova prioritária. Um CTA principal." Hook deve comprar atenção para a mensagem: "Curiosidade sem relação com o corpo cria ruptura e pode atrair clique sem fit."

## 4. Estrutura-base e roteiro (04, 4.4 e 5.1)

Hook → Contexto → Problema → Mecanismo → Prova → Oferta → CTA, adaptada ao estágio de consciência ("Um público muito consciente pode começar por oferta").

| Tempo | Função |
|---|---|
| 0–3 s | Hook: atenção relevante |
| 3–10 s | Situação ou problema: identificação |
| 10–20 s | Mecanismo ou demo: compreensão |
| 20–27 s | Prova e oferta: reduzir dúvida |
| 27–30 s | CTA: direção |

"Os tempos são um ponto de partida, não uma regra." Colunas do roteiro técnico: tempo/cena · imagem e ação · fala/voz · texto na tela · som · função.

## 5. Teste em ondas (04, 9.2)

| Onda | O que varia | O que permanece | Aprendizado |
|---|---|---|---|
| 1. Ângulo | Perspectiva central | Formato, oferta, prova e CTA | Qual problema ou oportunidade gera relevância |
| 2. Hook | Primeiro frame/frase | Ângulo, corpo e CTA | Qual entrada conquista atenção qualificada |
| 3. Formato | UGC, demo, estático etc. | Argumento e prova | Qual representação facilita compreensão |
| 4. Corpo/prova | Explicação ou evidência | Hook e CTA | O que reduz incerteza |
| 5. CTA | Próxima ação | Mensagem e oferta | Qual pedido é proporcional à consciência |

Variáveis possíveis de uma matriz: ângulo, hook, conceito, persona, formato, corpo, prova, CTA, duração, edição. Nunca "testar ângulo, hook, formato e CTA ao mesmo tempo".

## 6. Creative Card para a produção (04, 1.1)

Projeto e versão da oferta · Público + situação · Estágio de consciência · Objetivo (parar, educar, demonstrar, qualificar ou converter) · Mensagem única · Ângulo · Prova · Objeção · CTA · Canal e placement · Restrições (claims, imagens, palavras, direitos) · Métrica. Preencha um card por linha priorizada da matriz e entregue à `agente-de-producao-de-criativos-trm`.

Test Card criativo (04, 9.3): hipótese · evidência de partida · variável principal · controle · versões · público/canal/placement · janela e orçamento · métrica principal · métricas de guarda · critério de decisão · resultado · aprendizado · próximo teste.

## 7. Rubrica de prontidão da proposta (04; 0 ausente, 1 parcial, 2 claro e validado)

Creative Card completo · ângulo ligado a uma evidência · uma mensagem e um CTA · hook contínuo com o corpo · prova compatível com o claim · roteiro utilizável · identidade e arquivos organizados · versões adaptadas aos placements · QA, direitos e compliance aprovados · teste com decisão definida. 17–20 pronto para teste controlado; 12–16 corrigir pontos fracos; 0–11 voltar ao briefing e à hipótese.

## 8. Checkpoints do editor (04)

"Se o som for desligado, a abertura continua compreensível? Se o primeiro frame for removido, o restante ainda cumpre o que ele prometeu?" "A prova sustenta exatamente o claim — ou apenas parece impressionante?" "A nova peça mantém o princípio, mas possui mensagem, evidência, assets e expressão próprios?"
