# Roteiro de pesquisa na web

Regra de acesso: só conteúdo público, sem login forçado, CAPTCHA, paywall ou burla de bloqueio. Use navegador quando a página for dinâmica; busca e fetch para páginas estáticas. Baixar vídeo exige aprovação do operador.

## Registro de cada busca
| Plataforma | País/idioma | Termo | Filtro/ordenação | Data e hora | Resultados úteis (URLs) | Vizinhos descobertos |

## Termos
Monte quatro grupos e combine: **oferta** (nome do mecanismo, promessa, produto) · **assunto amplo** (o tema de que a oferta trata) · **dor e desejo na voz do público** (frases de comentários e fóruns) · **apelidos e grafias** (sem acento, gírias, ofuscação, tradução local). Em outros países, traduza o mecanismo e a dor, não o nome comercial.

## Fontes

| Fonte | Como pesquisar | O que capturar | O que ela mostra |
|---|---|---|---|
| Biblioteca de Anúncios da Meta | País fixo, ativos, busca por frase exata e por anunciante; repetir em US, MX, ES, CO, PT e mercados grandes do nicho | ID, anunciante, início, contagem por criativo, duração, texto, destino | Circulação paga e longevidade; não mostra views nem resultado |
| TikTok busca e hashtags | Termos e hashtags do assunto; abrir os vídeos com mais views e os recentes | URL, criador, seguidores, data, views, curtidas, comentários, compartilhamentos, salvamentos, som, legenda, comentários mais curtidos | Alcance orgânico e linguagem do público |
| TikTok Creative Center | Top Ads por setor e país, Trends (hashtags, sons, criadores) | Anúncio, setor, país, métricas que a própria página exibe, período | Anúncios e tendências destacados pela plataforma; usar só o que a página mostra |
| YouTube e Shorts | Busca ordenada por relevância e por contagem de visualizações; filtro de data | URL, canal, inscritos, data, views, curtidas, comentários, duração, título, thumbnail, capítulos, legenda automática | Temas perenes e vídeos longos que explicam mecanismo |
| Instagram Reels, Kwai, Pinterest | Busca por termo e hashtag quando acessível sem login | Os mesmos campos de alcance visíveis | Formatos nativos do nicho |
| Reddit, Quora, grupos e fóruns de afiliados | Termo + "reddit", subreddits do nicho, threads mais votadas | Título, votos, comentários, frases literais, objeções, perguntas | Voz real do público, dúvidas e polêmicas; não é ranking |
| Sites e blogs de outros países | Busca no idioma local pelo mecanismo e pela dor | URL, país, data, título, argumento | Temas antes de chegarem ao mercado local |
| Google Trends | Termo e variações, país e últimos 12 meses e 90 dias | Curva, pico, consultas relacionadas em alta | Se o assunto está subindo |

## Cobertura mínima por rodada (ajustável)
Três fontes diferentes, pelo menos uma paga (Biblioteca ou Creative Center) e uma orgânica (TikTok ou YouTube), mais uma de voz do público (comentários ou fórum). Anote quando uma fonte não pôde ser acessada e por quê.

## Limites por fonte
Views e curtidas podem ser infladas ou incluir impulsionamento pago não declarado. Creative Center e Biblioteca mostram recortes da própria plataforma. Fórum dá sinal qualitativo, não representatividade. Métrica que exige login ou ferramenta paga fica NÃO MAPEADO, a menos que o operador forneça.
