# Análise de alcance e viralização

Origem: a separação entre sinal e performance, os rótulos e as fichas de hook, ângulo, formato e prova vêm da Trip Angle. A normalização de números e os gatilhos de viralização abaixo são **regra operacional derivada**, não estão no Notion. Tudo nesta leitura é INTERPRETAÇÃO ESTRATÉGICA ou HIPÓTESE, porque a causa de um viral não é confirmável de fora.

## 1. Campos de alcance (capturar só o que está visível)
Plataforma · URL · criador · seguidores ou inscritos · data de publicação · data e hora da captura · views · curtidas · comentários · compartilhamentos · salvamentos · duração · som ou música · pago ou orgânico (se declarado).

## 2. Normalização

| Indicador | Cálculo | Leitura |
|---|---|---|
| Multiplicador de audiência | views ÷ seguidores | Acima de 1 indica alcance além da própria base |
| Fora da curva do perfil | views ÷ mediana de views dos últimos 10 a 20 vídeos do mesmo perfil | Acima de 3 sugere que o vídeo, e não o perfil, puxou o alcance |
| Taxa de conversa | comentários ÷ views | Alta indica polêmica, dúvida ou identificação forte |
| Taxa de compartilhamento | compartilhamentos ÷ views | Alta indica conteúdo que as pessoas usam para falar com outras |
| Taxa de salvamento | salvamentos ÷ views | Alta indica utilidade, receita, lista ou passo a passo |
| Velocidade | views ÷ dias desde a publicação | Diferencia pico recente de acúmulo lento |

Cortes de 1 e 3 são pontos de partida ajustáveis. Compare sempre dentro da mesma plataforma. Perfis gigantes com vídeo na média do perfil não entram como referência de formato.

## 3. Por que viralizou: gatilhos a verificar
Marque os presentes, com a evidência de onde aparecem (segundo do vídeo, texto, comentário):
- **Tensão no hook:** conflito, erro, alerta ou pergunta que exige resposta nos primeiros segundos.
- **Identificação:** situação específica que o público reconhece como sua; comentários do tipo "sou eu".
- **Novidade ou contraste:** informação que contradiz a crença comum ou nomeia um inimigo novo.
- **Polêmica:** comentários divididos, correções, discordância.
- **Utilidade salvável:** receita, lista, passo a passo, antes de fazer X.
- **Prova visual:** demonstração, resultado ou processo mostrado na tela.
- **Formato nativo:** cara de conteúdo da plataforma, não de anúncio.
- **Som ou tendência:** áudio, meme ou formato em alta no período.
- **Momento do assunto:** notícia, estação, lançamento ou pico no Google Trends.
- **Autoridade ou personagem:** especialista, figura pública ou persona forte.

Conclusão em uma frase: "Hipótese: alcançou [indicador] principalmente por [gatilho 1] e [gatilho 2], observável em [evidência]."

## 4. Criador ou formato
| Situação | Conclusão |
|---|---|
| Perfil grande, vídeo na média do perfil | Alcance é da audiência; não é referência de formato |
| Perfil grande, vídeo muito acima da mediana | Tema ou formato puxou; referência válida com ressalva |
| Perfil pequeno, vídeo muito acima da mediana e dos seguidores | Sinal forte de tema ou formato transferível |
| Mesmo formato fora da curva em vários perfis pequenos | PADRÃO IDENTIFICADO de formato |

## 5. Ponte para direct response
Para cada viral que entrar no plano, responda:
1. Qual problema ou desejo da persona da oferta o tema toca?
2. Qual crença do vídeo prepara o mecanismo da oferta?
3. Onde o anúncio sai do conteúdo e entra na oferta sem quebrar a promessa?
4. Qual prova a oferta tem para sustentar o que o vídeo sugere?
Sem resposta para 1 e 3, o viral fica como repertório e não vira linha na matriz.

## 6. Erros
Tratar views como venda · comparar perfis de tamanho diferente sem normalizar · creditar ao formato o alcance do criador · ignorar impulsionamento pago · concluir causa sem evidência na peça ou nos comentários · trazer viral sem ponte para a oferta.
