# Radar de temas em alta

Origem: regras de sinal de escala e de leitura da Trip Angle ("Mineração Avançada — Meta Ads", "Arsenal de Mineração — DR & Quiz-First", "Frameworks para Aplicação", seção 7). Os cortes numéricos abaixo são **regra operacional derivada**, não estão no Notion; o operador pode ajustá-los por nicho.

## O que conta como tema

Um tema é uma ideia de conteúdo que se repete em peças diferentes: mecanismo nomeado ("pâncreas hiperativo"), inimigo nomeado, promessa com prazo ("7 dias"), situação ou persona declarada ("mulher +40"), apelido de produto ("de pobre", "natural"), ativo concreto ("plano imprimível") ou formato recorrente (médico em talking head, receita em demonstração). Tema não é ângulo: o mesmo tema pode ser trabalhado por ângulo de mecanismo, de prova ou de objeção.

## Sinais observáveis

| Sinal | Como medir | O que indica |
|---|---|---|
| Difusão | Número de anunciantes independentes com o tema na mesma janela | Tema em circulação no mercado |
| Recência | Data de início dos cartões com o tema | Entrada recente de anunciantes |
| Concentração | Soma de "N anúncios usam esse criativo" dos cartões com o tema | Investimento observável de produção e veiculação |
| Persistência | Anúncios com o tema ativos há muito tempo | Continuidade |

Nenhum sinal mede resultado. "a heurística 'longa duração + impressões altas' é apenas sinal de possível durabilidade quando esses dados estiverem disponíveis." "Sofisticação e concorrência: não inferir estágio pelo volume."

## Classificação (cortes derivados, ajustáveis)

| Classe | Critério |
|---|---|
| **Emergente** | Pelo menos 2 anunciantes independentes, com a maioria dos cartões iniciados nos últimos 14 dias |
| **Em alta** | Pelo menos 3 anunciantes independentes, cartões iniciados nos últimos 30 dias e concentração acima da mediana da amostra |
| **Perene** | Pelo menos 2 anunciantes com cartões ativos há mais de 60 dias |
| **Isolado** | Um anunciante só; registrar como caso, não como tema |

Clones contam como um anunciante só para difusão: mesma copy em páginas diferentes é PADRÃO IDENTIFICADO, não prova de difusão independente.

## Registro por tema

| Tema | Tipo (mecanismo, inimigo, promessa, persona, prazo, formato) | Classe | Anunciantes | IDs | Início mais antigo e mais recente | Soma de contagem | Hook que mais o carrega | Formato dominante | Risco de compliance | Rótulo |

## Limites

A Biblioteca mostra só anúncios ativos e a amostra carregada na busca. Contagens e datas mudam; preserve a data da observação. O radar diz o que está em circulação, nunca o que performa.
