# TRM LAB CRIATIVOS: base e registro

Pasta pública do Google Drive "🔺TRM LAB CRIATIVOS 🧪", id `1zvNYizDu7PcgIrRgGm7RDsKP-N88-bBK`. É o banco de referências do operador. A skill consulta antes de pesquisar e entrega registros novos para ele.

## Acesso
- O conector do Google Drive pode não listar as pastas, porque a pasta é de outro dono.
- Listagem: `scripts/lab_listar.py <id>` lê `https://drive.google.com/embeddedfolderview?id=<id>` e devolve nome e id de cada item. Rode por subpasta quando precisar descer.
- Download de arquivo: `https://drive.google.com/uc?export=download&id=<id>`, só quando for transcrever ou revisar uma peça.

## Estrutura observada em 11/09/2026 (confirmar com a listagem)
- 87 pastas e 1.201 arquivos.
- 25 pastas de nicho.
- 10 pastas de "hooks" com 628 clipes de B-roll mudo de 3 a 12 s, em packs d, h, i, m, n e R. São aberturas visuais, não hooks verbais.
- "TRM FORMATOS" com 50 subpastas numeradas. O formato 1, Caixinha de perguntas, está na pasta sem nome "gr". Vários exemplos vêm dos anúncios do produto "50 formatos orgânicos".
- Expansão planejada em 11/09/2026: formatos novos numerados a partir do 51, ângulos e hooks novos, novos nichos e fontes.

## Convenção de nome
`PAIS__NICHO__ANGULO__HOOK__FORMATO__ANUNCIANTE__AAAAMMDD`
Use códigos curtos sem acento e sem espaço dentro de cada campo. Exemplo: `BR__EMAGRECIMENTO__MECANISMO__PERGUNTA__TALKINGHEAD__criadorx__20260912`.

## Classificação do achado frente ao laboratório
- **Novo:** formato, ângulo ou hook que não existe em nenhuma pasta. Formato novo recebe o próximo número livre da série.
- **Variação:** execução diferente de um formato ou ângulo que já existe. Aponte o número ou a pasta de origem.
- **Repetido:** já coberto. Registre só se trouxer alcance ou nicho novo.

## Esquema da planilha de registro (uma linha por referência)
id_registro · nome_padrao · classificacao (novo, variação, repetido) · pasta_destino_sugerida · numero_formato · plataforma · url · pais · idioma · nicho · oferta_relacionada · criador_ou_anunciante · seguidores · data_publicacao · data_captura · views · curtidas · comentarios · compartilhamentos · salvamentos · contagem_anuncios · inicio_anuncio · duracao · formato · hook_tipo · hook_texto_literal · angulo_familia · tema · classe_tema · copy_resumo · gatilhos_virais · multiplicador_audiencia · fora_da_curva · ponte_para_oferta · o_que_preservar · o_que_nao_reutilizar · risco_compliance · origem_transcricao · rotulo_evidencia · observacoes

Entregue em CSV ou XLSX. A skill não sobe nem move arquivos no Drive: o operador aprova a lista e faz a movimentação.
