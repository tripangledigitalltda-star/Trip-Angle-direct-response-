# Modelo de relatório do editor de criativos

Cabeçalho: nicho ou oferta · país e idioma · janela (ativos) · data e hora da coleta · entrada usada (oferta minerada, termo ou anúncios enviados) · tamanho da amostra (cartões lidos, Ads analisados, anunciantes).

## 1. Resumo do editor
Três a cinco frases: quantas ideias distintas existem (famílias, não vídeos), quais temas estão em circulação, qual formato e hook dominam, e qual é a primeira onda de teste recomendada. Aviso fixo: "Sinal de escala e circulação não é prova de CTR, venda ou ROAS."

## 2. Radar de temas
Tabela de `radar-de-temas.md`, ordenada por classe (em alta, emergente, perene) e depois por difusão.

## 2b. Top referências com alcance
| Plataforma | URL | Criador e seguidores | Data | Views | Multiplicador | Fora da curva | Gatilhos | Por que alcançou (hipótese) | Ponte para a oferta |
Só o que foi visto na página, com data da captura. Ver `analise-viral.md`.

## 3. Famílias e fichas de criativo
Para cada família: nome funcional · classificação (clone, variação, ângulo novo) · anunciantes e IDs · execuções. Dentro dela, uma ficha por Ad analisado (`analise-de-criativos.md`, seção 2), com observado e interpretação separados e as três comparações.

## 4. Padrões
| Dimensão | Padrão identificado | Anunciantes | IDs | Rótulo |
Hooks (tipos e aberturas recorrentes), ângulos (famílias recorrentes), formatos e durações, estruturas (ordem dos blocos e tempos), provas (nível da hierarquia mais usado). Só entra padrão visto em mais de um anunciante.

## 4b. Banco de hooks novos
| Hook próprio | Tipo | Persona | Crença pressuposta | Promessa implícita | Referência de origem | Novo no TRM LAB? |

## 5. Plano de expansão
Decisão por referência (preservar, substituir, não reutilizar) · matriz de conceitos · ordem de ondas · Creative Cards das linhas priorizadas · propostas bloqueadas por falta de prova.

## 6. Riscos de compliance
Claim, onde aparece (ID, tempo), tipo de risco, o que fazer na versão própria.

## 6b. Registro para o TRM LAB
Planilha no esquema de `laboratorio-trm.md`, com classificação novo, variação ou repetido e pasta de destino sugerida.

## 7. Limites da análise
Amostra não exaustiva · fontes que não puderam ser acessadas · métricas que exigem login · áudio não legendado e trechos não assistidos (NÃO MAPEADO) · transcrições geradas e sua confiança · destinos não abertos · contagens e datas mudam · nenhuma métrica de performance disponível.
