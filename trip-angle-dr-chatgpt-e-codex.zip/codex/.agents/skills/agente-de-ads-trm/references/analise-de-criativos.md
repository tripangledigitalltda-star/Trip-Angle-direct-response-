# Análise de criativos e referências (swipe diagnóstico)

Origem: "04 — Criativos e Biblioteca Visual" (seções 1.1, 2.2, 3.2, 3.3, 4.2, 4.3, 4.4), Conceitos Canônicos AD, HOOK, FORMATO, ÂNGULO e PROVA, e "Mineração Avançada — Meta Ads" da Trip Angle. Campos e listas são literais salvo indicação.

## 1. Unidade de análise

"Ad é a unidade de entrada que interrompe atenção, seleciona uma pessoa, estabelece uma tensão e conduz a um próximo passo do funil. É uma peça, não a campanha inteira." "Sua função é qualificar e iniciar a jornada, não provar sozinho a eficácia da oferta." Analise o Ad junto com o destino: "Se você analisou o Ad sem abrir o destino, faltou funil."

Cobertura: cinco Ads por oferta qualificada, escolhidos entre os de maior contagem e os que parecem ângulos diferentes. Pareie cada ficha ao ID; nunca por posição na lista.

## 2. Ficha de decomposição (uma por Ad)

| Campo | O que preencher |
|---|---|
| URL e data da coleta | URL do anúncio na Biblioteca, ID, data e hora |
| País, idioma e canal | Como exibido |
| Oferta e público aparente | A quem a peça fala e o que oferece, como aparece |
| Estágio de consciência | Não consciente / problema / solução / produto / muito consciente, com a evidência textual |
| Ângulo | Família (seção 4) e os elementos enfatizados e omitidos |
| Primeiro frame | O que aparece antes de qualquer fala |
| Hook verbal | Primeira frase, literal |
| Texto na tela | Literal |
| Formato e duração | Tipo (seção 5) e duração; se só houver "vídeo", não especificar mais sem suporte |
| Corpo do argumento | Sequência: contexto → problema → mecanismo → prova → oferta → CTA, ou a ordem observada |
| Mecanismo/prova | O que a copy alega como causa e o que apresenta como prova |
| Objeção tratada | Qual dúvida a peça responde |
| CTA | Ação pedida e destino |
| Elementos de produção | Pessoa, cenário, B-roll, legenda, ritmo, som |
| **O que é observável** | Somente o que está na peça e no destino, com rótulo OBSERVAÇÃO ou FATO CONFIRMADO |
| **O que é apenas interpretação** | Leituras do analista, com rótulo INTERPRETAÇÃO ESTRATÉGICA |
| Hipótese reutilizável | Função transferível, escrita como hipótese, não como frase para copiar |

Campos da auditoria da Mineração Avançada que complementam a ficha: fato observado · inferência · fonte · data de captura · confiança (A–D) · sinal de escala · **gap promessa/entrega** · risco de compliance · o que preservar · o que substituir · o que não reutilizar · próximo teste.

## 3. Hook

Tipos (04, 4.2): **Visual** (movimento, demonstração, objeto, contraste, tela) · **Verbal** (pergunta, observação, diagnóstico, declaração específica) · **Textual** (frase curta que contextualiza sem som) · **Narrativo** (tensão, erro, tentativa, descoberta, transformação) · **Prova imediata** (resultado ou processo verdadeiro já no início) · **Objeção** (começa pela dúvida que o público já tem).

Ficha do hook (conceito canônico): tipo · padrão de atenção · quebra de padrão · curiosidade · tensão · persona selecionada · crença pressuposta · promessa implícita · ângulo · lead · formato · consciência · próximo bloco. "Se você só classificou como 'curioso', faltaram persona, crença, promessa implícita e próximo bloco." "Curiosidade sem relação com o corpo cria ruptura e pode atrair clique sem fit." "Não reescreva nem aumente o claim; descreva atenção, tensão e promessa implícita."

## 4. Ângulo

Famílias (04, 3.2): Situação reconhecível · Problema ou custo · Mecanismo · Nova oportunidade · Demonstração · Prova · Objeção · Comparação · Identidade ou aspiração · História.

Elementos (conceito canônico, 11): tese · enquadramento · situação · desejo · inimigo · emoção · contraste · reframe · mecanismo · persona · nível de consciência. "Pergunte qual item foi enfatizado e qual foi omitido." "Em cada item, marque literal, padrão ou interpretação." "Um ângulo completo mostra seleção, omissão e ordem; uma lista de adjetivos não demonstra enquadramento." Não atribua inimigo que não aparece; não confunda tema com ângulo nem formato com ângulo.

## 5. Formato

Tipos (04, 4.3) com o risco comum de cada um: UGC/creator-led (fingir espontaneidade) · Talking head (monólogo sem apoio visual) · Demonstração (mostrar sem explicar) · Screen recording (texto pequeno) · Estático (excesso de texto) · Carrossel (primeiro cartão sem motivo para avançar) · Testimonial/case (resultado sem contexto ou permissão) · Animação/motion (estética que distrai). Conceito canônico acrescenta: unboxing, entrevista, VSL, live, página.

Elementos: tipo · abertura · primeira cena · arquitetura · edição · ritmo · duração · fala · B-roll · visual · autoridade · demonstração · prova · CTA · relação com o argumento · estágio do funil. "sem inferir performance apenas por duração, estilo ou aparência." Não chame canal de formato; não confunda VSL com funil.

## 6. Prova

Hierarquia visual (04, 3.3), do mais forte ao mais fraco: 1 produto ou processo em funcionamento · 2 demonstração comparável · 3 dado próprio com contexto e método · 4 caso verificável · 5 depoimento genuíno e autorizado · 6 credencial relevante · 7 explicação · 8 afirmação sem suporte.

Decomposição (conceito canônico): afirmação → prova apresentada → fonte → tipo → função → limite → objeção respondida. "'A copy mostra' é diferente de 'está comprovado'." "Depoimento, autoridade ou número podem ser prova alegada, não validação causal." "não somar fontes distintas como uma prova única." Prova não independente recebe ALEGAÇÃO DA COPY. Garantia não é evidência de resultado.

## 7. As três comparações que mais revelam

1. **Mecanismo narrado × mecanismo entregue.** O que o anúncio diz que causa o problema e resolve, contra o que a primeira dobra, o quiz ou a VSL realmente explicam e vendem. Diferença grande é gap promessa/entrega.
2. **Continuidade anúncio → destino.** Mesma promessa, mesma situação, mesmo nível de consciência? Hook que o corpo não entrega e página que muda de promessa são quebras.
3. **Prova × claim.** "A prova sustenta exatamente o claim, ou apenas parece impressionante?" Antes/depois não verificável, resultados extremos sem contexto, números escolhidos e depoimentos vagos não são prova suficiente.

## 8. Clone, variação ou ângulo novo

Agrupe os Ads de uma oferta por função do hook e problema declarado. Ângulo novo só com mudança substancial de desejo, problema, mecanismo, promessa, persona ou prova; troca de apresentador, cenário ou avatar é variação de execução. Copy ou vídeo idênticos em anunciantes diferentes é clone, registrado como família (ver `triagem-dr.md`, seção 6).

## 9. O que vira princípio e o que não se copia (04)

Pode reaproveitar como princípio: sequência narrativa · tipo de pergunta · categoria de hook · forma de demonstrar · lógica de prova · ritmo ou contraste · relação entre problema e CTA.

Não copie: texto integral · identidade, personagem ou rosto sem direito · cenas e composição reconhecíveis · depoimento ou resultado · logo, música, vídeo e propriedade intelectual · promessa que sua oferta não sustenta. Modelagem é sempre HIPÓTESE até o Test Card.

Compliance: "claims de renda rápida, saúde, before/after, autopercepção negativa, controle psicológico, urgência artificial e depoimentos não auditados devem ser marcados como risco, não copiados." Aprovação na plataforma não substitui conformidade legal.

## 10. Erros de leitura (literais)

AD: tratar CTR como conversão; ignorar destino; avaliar Ad fora do funil; copiar hook sem lead; chamar qualquer criativo de Ad. HOOK: considerar todo início como hook; confundir choque com relevância; avaliar só pela curiosidade; não apontar a crença pressuposta. FORMATO: copiar estética sem entender argumento; achar que duração explica resultado; avaliar somente a primeira cena. ÂNGULO: confundir tema com ângulo; tratar emoção como mecanismo. PROVA: confundir presença com qualidade; aceitar autoridade como prova causal; somar provas sem função; chamar garantia de evidência de resultado. Criativos: confundir imagem bonita com criativo estratégico; copiar anúncio sem entender o princípio; medir apenas CTR.
