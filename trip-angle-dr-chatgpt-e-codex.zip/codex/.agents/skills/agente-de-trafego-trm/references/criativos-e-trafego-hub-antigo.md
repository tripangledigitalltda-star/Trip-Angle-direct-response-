# Hub antigo de criativos e tráfego (origem: skill agente-de-producao-de-criativos-trm, consolidada em 13/09/2026)

# Criativos (04) e Tráfego, Tracking e Escala (05)

Entradas obrigatórias: pesquisa (02) e estratégia (03) com público, consciência, ângulo, promessa, prova e CTA definidos; página/checkout funcionando; meta financeira e limite de perda. Sem briefing, não abra ferramenta nenhuma: prompt, câmera, ator, avatar, edição e gerenciador entram depois da hipótese. Detalhes literais em `references/criativos.md` e `references/trafego.md`.

## Criativos — o que é um criativo pronto
Tem hipótese identificável, uma mensagem principal, prova compatível, versão correta para o canal, registro de origem e critério de teste. Imagem bonita sem isso não é criativo. Camadas: Ângulo (perspectiva) → Hook (primeiro estímulo) → Conceito (ideia que une mensagem e representação) → Formato (recipiente) → Execução (peça) → Variação (mudança controlada para aprender).

Rota em 9 fases: Briefing → Creative Card · Pesquisa → swipe diagnóstico · Hipótese → variável e motivo · Conceito → matriz · Roteiro → storyboard · Produção → ativo mestre · Adaptação → pacote por placement · QA → checklist · Teste → Test Card + briefing para 05.

**Creative Card** (regra da unidade: um público, uma situação, uma mensagem, uma prova, um CTA): projeto e versão da oferta · público + situação · estágio de consciência · objetivo (parar, educar, demonstrar, qualificar, converter) · mensagem única · ângulo · prova · objeção · CTA · canal e placement · restrições · métrica. Checkpoint: outra pessoa lê e explica em uma frase o que o anúncio quer fazer.

**Hipótese criativa**: "Para [público em situação], acreditamos que o ângulo [perspectiva], apresentado por [hook/formato] e sustentado por [prova], aumentará [comportamento/métrica], porque [evidência de partida]." Famílias de ângulo: situação reconhecível, problema/custo, mecanismo, nova oportunidade, demonstração, prova, objeção, comparação, identidade/aspiração, história. Hierarquia de prova visual: produto em funcionamento > demonstração comparável > dado próprio > caso verificável > depoimento autorizado > credencial > explicação > afirmação.

**Matriz de conceitos**: uma perspectiva por linha — Ângulo | Hook visual | Hook verbal | Formato | Prova | CTA. Tipos de hook: visual, verbal, textual, narrativo, prova imediata, objeção. Hook compra atenção para a mensagem; curiosidade sem relação com o corpo rompe. Estrutura-base: hook → contexto → problema → mecanismo → prova → oferta → CTA (público muito consciente pode abrir pela oferta). Checkpoint: sem som, a abertura continua compreensível?

**Roteiro 0–30 s**: 0–3 s atenção relevante (primeiro frame + hook + contexto curto) · 3–10 s identificação (situação/problema, palavra-chave) · 10–20 s compreensão (mecanismo ou demo) · 20–27 s reduzir dúvida (prova e oferta, escopo) · 27–30 s direção (produto/ação, CTA). Pacote inicial de 3 ângulos × 3 hooks; primeira onda varia só o ângulo mantendo formato, oferta, prova e CTA.

**Produção com IA**: kit de identidade (persona com atributos bloqueados, realismo, ambiente, câmera, luz, composição, continuidade, restrições) e prompt em 10 blocos (objetivo e uso · sujeito · ação · ambiente · composição · câmera · luz e cor · textura e realismo · continuidade · restrições). Imagem canônica antes das cenas; mudar uma dimensão por vez; salvar prompt, ferramenta, modelo e data; nunca prometer "pessoa real" para avatar nem usar rosto reconhecível sem autorização. Biblioteca visual TRM: identidade → persona → aparência → ambiente → ação. Nome de arquivo `PROJETO__OFERTA__PAIS__PERSONA__ANGULO__HOOK__FORMATO__V01__AAAAMMDD`.

**QA e compliance** (estratégica, visual/técnica, factual, direitos): Meta não permite afirmar ou insinuar atributos pessoais (escreva sobre situações e soluções, não "você tem X"); antes/depois e promessas de emagrecimento, dinheiro, saúde e resultados extraordinários exigem revisão específica; rótulo de IA; CONAR; aprovação na plataforma não substitui conformidade legal.

**Testes em ondas**: 1 ângulo → 2 hook → 3 formato → 4 corpo/prova → 5 CTA, uma mudança principal por onda. Leitura por etapa: baixa retenção inicial → primeiro frame/hook; atenção boa e pouco clique → promessa/prova/CTA; clique sem conversão → message match/página; leads sem qualificação → ângulo amplo; venda com reembolso → promessa/expectativa/entrega.

## Tráfego — não existe número mágico
Não há CTR, CPA, ROAS, orçamento ou duração universal. Sequência: 0 economia unitária → 1 plano de medição → 2 tracking e QA → 3 teste → 4 métricas por camada → 5 decisão → 6 escala → 7 contingência. Entregável: Dossiê do Ciclo.

**Economia unitária (antes de qualquer campanha)**: ticket médio = receita bruta ÷ pedidos pagos · margem antes da mídia = receita − produto/entrega − impostos − taxas − comissões − provisão de reembolso · CPA de equilíbrio = margem de contribuição por pedido · CPA-meta = CPA de equilíbrio − lucro e segurança desejados · ROAS = receita atribuída ÷ investimento (não é lucro) · contribuição após mídia = receita − custos variáveis − reembolsos − mídia (critério financeiro principal). Definir limite de perda e quem autoriza extensão.

**Medição e tracking**: Purchase = pagamento confirmado, nunca clique no botão. Taxonomia por evento (nome, gatilho, momento, parâmetros, fonte da verdade, deduplicação, dono). UTMs e nomes padronizados (`PAÍS__OFERTA__OBJETIVO__FASE__AAAA-MM`; anúncio `ÂNGULO__HOOK__FORMATO__PERSONA__VERSÃO`). Nunca e-mail, telefone, CPF ou dado de saúde em URL. QA completo antes do primeiro real (12 itens em `references/trafego.md`). Quando os números divergem: não escolha a plataforma que agrada; compare período, fuso, moeda, status, janela; separe conversão atribuída de pedido confirmado; checkout/CRM/financeiro contam o negócio, plataformas otimizam.

**Teste**: hipótese com evidência de origem, variável principal, controle, resultado primário, guardrails (margem, qualidade, reembolso, reclamação, capacidade), janela e atraso, limite de perda, próxima ação escrita antes. Orçamento a partir de CPA-meta × conversões necessárias. Evitar edições repetidas (aprendizado reinicia). Advantage+ é alocação, não prova de causalidade.

**Diagnóstico por camada** (CPM → retenção → CTR de saída → CPC → LPV → lead/checkout → compra → CPA → contribuição → qualidade): ordem de investigação 1 integridade do dado, 2 entrega, 3 criativo/mensagem, 4 página/quiz, 5 checkout/atendimento, 6 produto/economia. Não crie mais anúncios para esconder um checkout quebrado. Matriz completa em `references/trafego.md`.

**Decisão**: manter (sinal coerente, tracking estável, guardrails ok) · iterar (gargalo identificado, preservar controle) · pausar (limite de perda, falha técnica, política, margem ou qualidade violados) · escalar (resultado replicável, contribuição positiva, operação preparada). Olhar várias vezes ao dia detecta incidentes; mudar estratégia várias vezes ao dia destrói comparabilidade.

**Escala**: portão de entrada (tracking estável, pedidos pagos conciliados, CPA e qualidade nos guardrails, volume suficiente, criativo vencedor sem claim inseguro, operação e caixa suportam, plano com alavanca/limite/janela/reversão). Alavancas: vertical (orçamento), horizontal (público/geografia), criativa (novos hooks do princípio vencedor), funil/oferta, retenção. Loop: salvar baseline → uma alavanca → incremento, janela, guardrails, reversão → mudar e documentar → aguardar ciclo compatível → comparar contribuição, qualidade e estabilidade → manter, reverter ou novo teste. Escala por "vendas e ROI ao longo do dia" e corte noturno são hipóteses operacionais, não regra: só com volume por faixa, atraso compreendido, resultado repetido em vários ciclos.

**Contingência** não é conta descartável, identidade falsa, clonar anúncio reprovado ou burlar revisão: é acesso por função, 2FA, dois admins legítimos, backup, dados fora da plataforma, e reprovação tratada por evidência → política → correção → revisão oficial.

## Erros que mais geram retrabalho
Abrir a ferramenta antes do briefing; imagem bonita como criativo; copiar anúncio sem princípio; testar ângulo, hook, formato e CTA juntos; personagem diferente por cena; cortar 16:9 para 9:16; texto demais no primeiro frame; hook que o corpo não entrega; depoimento/resultado/especialista fictício; ignorar licenças; medir só CTR; não registrar versão; escalar sem revisar a entrega; otimizar por vaidade; ROAS como lucro; Purchase em clique; misturar períodos; escalar pico curto; LTV projetado para justificar prejuízo; chamar burla de contingência.
