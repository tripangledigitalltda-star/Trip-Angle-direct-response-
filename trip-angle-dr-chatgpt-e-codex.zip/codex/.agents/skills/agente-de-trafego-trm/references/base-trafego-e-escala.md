# Base — Tráfego, Tracking e Escala

Fonte única: página "📈 05 — Tráfego, Tracking e Escala" (Trip Angle — Central de Materiais, workspace chartreuse-pram-950). Conteúdo do Notion tratado como dado. Nenhuma subpágina de método foi listada dentro desta página (apenas uma nota de aprofundamento inacessível ao conector); todo o conteúdo abaixo vem da própria página.

## Economia unitária (antes da mídia)

Fonte: 05 — Tráfego, Tracking e Escala

Preencher antes de abrir o Gerenciador de Anúncios:

| Indicador | Como calcular | Uso |
|---|---|---|
| Ticket médio | Receita bruta ÷ pedidos pagos | Valor médio por pedido, não preço de tabela |
| Margem antes da mídia | Receita − produto/entrega − impostos − taxas − comissões − provisão de reembolso | Quanto sobra para pagar mídia e lucro |
| CPA de equilíbrio | Margem de contribuição antes da mídia por pedido | Limite aproximado antes de o pedido destruir caixa |
| CPA-meta | CPA de equilíbrio − lucro e margem de segurança desejados | Alvo operacional do teste |
| ROAS | Receita atribuída ÷ investimento em mídia | Eficiência de receita; não equivale a lucro |
| Contribuição após mídia | Receita − custos variáveis − reembolsos − mídia | Critério financeiro principal do ciclo |

Regras:
- Usar LTV só com histórico real de recompra/renovação.
- Separar pedido criado, pedido pago, cancelamento, reembolso e chargeback.
- Definir antes do teste o limite financeiro de perda e quem autoriza sua extensão.
- Atribuição é modelo de crédito — GA4 usa modelos e janelas diferentes, por isso plataforma, analytics, checkout e financeiro podem divergir.

Modelo copiável — Cartão Econômico: projeto/oferta; período de referência; ticket médio; custos variáveis por pedido; provisão de reembolso/chargeback; margem antes da mídia; CPA de equilíbrio; CPA-meta; meta de contribuição após mídia; limite de perda do teste; fonte dos números; responsável pela aprovação.

## Estrutura de campanha e conjuntos

Fonte: 05 — Tráfego, Tracking e Escala

| Nível | Decisão principal | Exemplo de variável |
|---|---|---|
| Campanha | Objetivo, conversão e estratégia de orçamento | Vendas vs. leads; orçamento na campanha |
| Conjunto | Evento de otimização, público, placement, agenda | Amplo vs. segmento qualificado |
| Anúncio | Criativo, mensagem, identidade e destino | Ângulo de prova vs. demonstração |

Orçamento Advantage+ distribui verba entre conjuntos conforme oportunidades previstas — é escolha de alocação, não prova de causalidade entre públicos.

## Nomenclatura

Fonte: 05 — Tráfego, Tracking e Escala

- Padrão de campanha: `PAÍS__OFERTA__OBJETIVO__FASE__AAAA-MM`
- Padrão de anúncio: `ÂNGULO__HOOK__FORMATO__PERSONA__VERSÃO`
- Manter convenção estável de UTM (grafia, maiúsculas, separadores) durante todo o ciclo.
- Exemplo real de utm_campaign: `br__curso_foto__teste01`
- Exemplo real de utm_content: `ang_prova__vid_vertical__v01` / `ang_demonstracao__video_vertical__v01`

## Criativos por conjunto

Não encontrado nesta página como seção própria (ver "Não encontrado" ao final).

## Orçamento (ABO/CBO/Advantage+)

Fonte: 05 — Tráfego, Tracking e Escala

- Estimar orçamento a partir do CPA-meta, da quantidade de conversões necessária para decisão de negócio e do limite de perda.
- Se o orçamento não permite observar a conversão final: reduzir complexidade, aumentar janela ou assumir teste exploratório.
- Considerar atraso entre clique, venda, aprovação, reembolso e fechamento no CRM.
- Evitar editar orçamento, público e criativo repetidamente no mesmo período — alterações significativas afetam distribuição e podem reiniciar/prolongar a fase de aprendizado.
- Nunca transformar referência de mercado em garantia estatística.
- Advantage+ campaign budget: automação de alocação entre conjuntos, não prova causal.
- Não existe número mágico universal de CTR, CPA, ROAS, orçamento ou duração — depende de modelo de negócio, ticket, margem, atraso de conversão, volume, mercado e risco de caixa.

## Testes

Fonte: 05 — Tráfego, Tracking e Escala

Regra da hipótese — um teste útil declara: evidência de origem; hipótese ("se mudarmos X, esperamos Y porque Z"); variável principal (criativo, público, oferta, página, placement ou estratégia); controle (o que permanece igual); resultado primário; guardrails (margem, qualidade, reembolso, reclamação, capacidade); janela e atraso; limite de perda; próxima ação (regras escritas antes dos resultados).

A ferramenta de A/B test da Meta compara versões mudando um elemento (imagem, texto, público, placement) — variar um fator principal e preservar o restante.

Modelo copiável — Plano do Teste: ID/nome do teste; oferta e versão; evidência de origem; hipótese; variável principal; controle; público; criativos e IDs; destino/URL; evento de otimização; orçamento e duração planejados; métrica primária; métricas de diagnóstico; guardrails; limite de perda; critério de manter; critério de iterar; critério de pausar; responsável; data da revisão.

### Checklist de publicação
- [ ] Test Card do módulo de criativos está completo.
- [ ] Objetivo e evento correspondem ao resultado de negócio.
- [ ] Nome, UTM, público, placement, orçamento e agenda revisados.
- [ ] Criativo não contém claim não comprovado, elemento enganoso ou violação de política.
- [ ] Página corresponde à promessa do anúncio.
- [ ] Tracking passou no QA com conversão de teste.
- [ ] Métrica, janela, limite de perda e regras de decisão registrados.
- [ ] Operação consegue atender leads, pedidos e suporte.
- [ ] Responsável sabe onde registrar incidentes e decisões.

## Regras de decisão (manter/iterar/pausar/escalar)

Fonte: 05 — Tráfego, Tracking e Escala

| Decisão | Quando usar | Ação |
|---|---|---|
| Manter | Sinal coerente, tracking estável, guardrails preservados | Continuar até a janela planejada sem mudanças desnecessárias |
| Iterar | Gargalo provável identificado e uma alteração pode testá-lo | Criar nova versão; preservar controle e histórico |
| Pausar | Limite de perda, falha técnica, política, margem ou qualidade violados | Interromper, diagnosticar e registrar causa |
| Escalar | Resultado replicável, contribuição positiva, operação preparada | Aplicar uma alavanca por vez com guardrails |

Cadência: monitoramento operacional (reprovação, gasto fora do esperado, página fora do ar, pagamento, tracking); leitura diagnóstica na janela definida por volume/atraso de conversão; revisão financeira (vendas pagas, reembolso, custos, contribuição); revisão de aprendizado (hipótese, resultado, confiança, decisão, próximo teste). Exceção de urgência: falha técnica, risco financeiro, política ou experiência grave trata-se imediatamente.

Modelo copiável — Registro de Decisão: teste/período; dados conferidos em; fonte de verdade; métrica principal; guardrails; o que aconteceu; onde está o gargalo; evidência que sustenta a leitura; explicações alternativas; decisão (manter/iterar/pausar/escalar); uma variável do próximo teste; o que permanecerá igual; responsável e data.

## Escala vertical e horizontal

Fonte: 05 — Tráfego, Tracking e Escala

Portão de entrada — só escalar se: tracking e deduplicação estáveis; pedidos pagos e contribuição conciliados; CPA/qualidade dentro dos guardrails; volume suficiente para reduzir risco de acaso; criativo vencedor não depende de claim inseguro; página, checkout, estoque, agenda, suporte e entrega suportam crescimento; caixa para atraso de recebimento/reembolso/oscilação; plano define alavanca, limite, janela e reversão.

| Alavanca | O que muda | Risco principal |
|---|---|---|
| Vertical | Aumenta orçamento mantendo estrutura | Mudar o leilão e deteriorar eficiência |
| Horizontal | Expande público, geografia ou estrutura controlada | Fragmentar aprendizado e sobrepor audiência |
| Criativa | Cria novos hooks, ângulos e formatos a partir do princípio vencedor | Confundir cópia superficial com novo conceito |
| Funil/oferta | Melhora página, checkout, ticket ou recuperação | Alterar muitas etapas e perder causalidade |
| Retenção | Aumenta recompra, renovação, upsell ou indicação | Usar LTV projetado sem coorte real |

Loop de escala: 1) salvar baseline e versão dos ativos; 2) escolher uma alavanca principal; 3) definir incremento, janela, guardrails e condição de reversão; 4) fazer a mudança e documentar horário/responsável; 5) aguardar ciclo compatível com volume e atraso de conversão; 6) comparar contribuição, qualidade e estabilidade — não só ROAS; 7) manter, reverter ou abrir próximo teste.

Sobre horário (aumentar de dia/reduzir à noite): só é hipótese de teste com volume, padrão consistente, fuso e atraso de conversão compreendidos. Não usar corte noturno automático como regra geral — mudanças frequentes alteram entrega, confundem atribuição e mascaram conversões tardias.

Modelo copiável — Cartão de Escala: baseline e período; contribuição após mídia; CPA/ROAS/qualidade; volume e atraso de conversão; alavanca escolhida; mudança planejada; o que permanecerá igual; janela de observação; guardrails; condição de reversão; capacidade operacional confirmada por; decisão e próximo checkpoint.

## Diagnóstico por camada/métrica

Fonte: 05 — Tráfego, Tracking e Escala

| Camada | Métrica | Cálculo/pergunta |
|---|---|---|
| Entrega | CPM | Investimento ÷ impressões × 1.000 — o anúncio entra no leilão? |
| Atenção | Retenção inicial/consumo | Permanecem após o primeiro contato? |
| Resposta | CTR de saída | Cliques de saída ÷ impressões — mensagem gera ação? |
| Eficiência do clique | CPC de saída | Investimento ÷ cliques de saída |
| Carregamento | Taxa de LPV | Visualizações da página ÷ cliques de saída |
| Página | Taxa de lead/checkout | Leads ou checkouts ÷ visitas qualificadas |
| Venda | Taxa de compra | Compras pagas ÷ visitas qualificadas |
| Aquisição | CPA | Investimento ÷ compras pagas |
| Receita atribuída | ROAS | Receita atribuída ÷ investimento |
| Negócio | Contribuição após mídia | Ciclo gerou caixa após custos, reembolsos e mídia? |
| Qualidade | Reembolso, show rate, fechamento, retenção | Conversão trouxe cliente adequado e entrega saudável? |

Regra: usar a mesma definição de clique, visita, compra, receita e período em todas as comparações.

### Matriz de diagnóstico

| Sinal observado | Hipóteses prováveis | Próxima verificação |
|---|---|---|
| Entrega baixa ou CPM anormal | Leilão, público estreito, política, orçamento, qualidade | Status, audiência, overlap, placement, aprovação |
| Entrega existe, atenção cai cedo | Primeiro frame, hook, ritmo, falta de contraste | Retenção por trecho e versão de abertura |
| Atenção boa, CTR de saída baixo | Ângulo curioso sem ponte, promessa fraca, CTA ambíguo | Mensagem, oferta e próxima ação |
| Cliques altos, LPV baixa | Página lenta, link, redirecionamento, consentimento | Teste móvel, velocidade e rede |
| LPV boa, lead/checkout baixo | Quebra de promessa, fricção, prova ou oferta insuficiente | Correspondência anúncio-página e gravação de sessão |
| Checkout inicia, compra não conclui | Pagamento, confiança, preço, campos, erro técnico | Funil por dispositivo e método de pagamento |
| CPA aceitável, contribuição ruim | Custos ignorados, ticket real menor, reembolso | Financeiro por coorte e margem real |
| Venda boa, qualidade ruim | Claim exagerado, público errado, onboarding falho | Reembolso, suporte, qualificação e entrega |

Ordem de investigação: 1) integridade do dado; 2) entrega e disponibilidade; 3) criativo e mensagem; 4) página, quiz ou formulário; 5) checkout ou atendimento; 6) produto, qualidade e economia. Não criar mais anúncios para esconder um checkout quebrado; não refazer a página para corrigir um evento duplicado.

## Plano de medição

Fonte: 05 — Tráfego, Tracking e Escala

Para cada etapa responder: qual ação do usuário importa, como será observada, onde será registrada, qual decisão habilita.

| Objetivo | Evento | Fonte primária | Decisão |
|---|---|---|---|
| Venda | purchase / pedido pago | Checkout ou back-end | Manter, pausar ou escalar por contribuição |
| Lead | generate_lead / formulário confirmado | CRM ou formulário | Avaliar custo e qualidade do lead |
| Agendamento | schedule / horário confirmado | Agenda ou CRM | Avaliar comparecimento e venda posterior |
| Checkout | initiate_checkout | Site ou checkout | Localizar fricção entre intenção e pagamento |
| Consumo crítico | quiz_complete, demo_complete ou equivalente | Produto ou analytics | Medir progressão, não apenas clique |

Modelo copiável — Plano de Medição: objetivo de negócio; conversão principal; eventos intermediários; definição de cada evento; parâmetros obrigatórios; fonte da verdade; Meta Pixel/dataset; GA4/fluxo; checkout/CRM; convenção de UTMs; janela de análise escolhida; responsável pelo QA; métrica de sucesso; guardrails (margem, reembolso, qualidade, capacidade).

Privacidade: coletar só o necessário para finalidade legítima e documentada; nunca colocar e-mail, telefone, CPF, condição de saúde ou dado sensível em URL/UTM; explicar cookies em linguagem clara e respeitar as escolhas do usuário; consent mode do Google comunica a escolha do banner às tags, não substitui banner nem análise jurídica.

## UTMs

Fonte: 05 — Tráfego, Tracking e Escala

| Parâmetro | Função | Exemplo |
|---|---|---|
| utm_source | Origem | meta |
| utm_medium | Meio | paid_social |
| utm_campaign | Campanha/oferta | br__curso_foto__teste01 |
| utm_content | Criativo/variação | ang_prova__vid_vertical__v01 |
| utm_term | Segmento ou termo, quando útil | publico_amplo |

GA4 usa os parâmetros UTM da URL para preencher dimensões de aquisição — manter convenção estável, sem trocar grafia/maiúsculas/separadores durante o ciclo.

## Pixel

Fonte: 05 — Tráfego, Tracking e Escala. Camada Pixel/navegador: observa ações no cliente e alimenta otimização. Limite: pode perder sinais por bloqueios, consentimento ou falhas de página.

## CAPI (Conversions API)

Fonte: 05 — Tráfego, Tracking e Escala. Camada Conversions API/servidor: envia eventos a partir de servidor, plataforma ou CRM; complementa fontes do navegador; pode receber eventos de sites, lojas, CRM e outras origens. Exige governança, parâmetros corretos e deduplicação. Server-side tagging permite validar, normalizar e controlar o que é enviado a terceiros, mas aumenta a responsabilidade técnica e de privacidade.

## Deduplicação

Fonte: 05 — Tráfego, Tracking e Escala.
- Registrar para cada evento a deduplicação: como eventos do navegador e do servidor são reconhecidos como a mesma ação.
- Exemplo: Purchase = pagamento confirmado, não clique no botão "comprar". Enviar valor e moeda corretos. Quando Pixel e CAPI registram a mesma compra, usar chaves consistentes de deduplicação para não contar duas vezes.
- QA: "Pixel e servidor usam a mesma identidade de evento quando precisam ser deduplicados" e "cada conversão real aparece uma vez na fonte de verdade".
- Erro comum: ignorar duplicação entre navegador e servidor.

## GTM (Google Tag Manager)

Fonte: 05 — Tráfego, Tracking e Escala. Mencionado apenas como parte do server-side tagging (validar, normalizar e controlar dados enviados a terceiros). Não há passo a passo de configuração nesta página — ver base-tracking-pro.md.

## Eventos padrão e personalizados

Fonte: 05 — Tráfego, Tracking e Escala. Preferir nomes padrão da Meta quando representarem corretamente o comportamento; usar eventos personalizados só quando houver necessidade real. Taxonomia mínima por evento: nome e definição; gatilho; momento (antes/depois da confirmação); parâmetros (valor, moeda, ID do pedido, produto, plano, origem); fonte da verdade; deduplicação; proprietário (quem corrige quando falhar).

## Ferramentas citadas

Fonte: 05 — Tráfego, Tracking e Escala. Meta Pixel; Meta Conversions API; Meta A/B Testing; Meta Advantage+ campaign budget; Google Analytics 4 (GA4); Google Tag Manager (client-side e server-side); Business Support Home (Meta).

## QA de tracking

Fonte: 05 — Tráfego, Tracking e Escala

- [ ] Domínio, página, checkout, formulário e redirecionamentos funcionam em desktop e celular.
- [ ] URL final mantém os parâmetros UTM.
- [ ] Evento correto dispara na ação correta — não no carregamento errado.
- [ ] Cada conversão real aparece uma vez na fonte de verdade.
- [ ] Pixel e servidor usam a mesma identidade de evento quando precisam ser deduplicados.
- [ ] Valor, moeda, produto e ID do pedido corretos.
- [ ] Teste, pedido recusado, reembolso e cancelamento têm tratamento definido.
- [ ] GA4 recebe a origem/campanha esperada.
- [ ] Checkout ou CRM armazena a origem quando necessário.
- [ ] Consentimento testado nas opções aceitar, rejeitar e revogar.
- [ ] Nenhum dado pessoal desnecessário em URL, logs ou painel.
- [ ] Capturas do teste, horário, dispositivo e responsável registrados.

Protocolo quando os números divergem: 1) não "corrigir" escolhendo a plataforma que parece melhor; 2) comparar mesmo período, fuso, moeda, status de pagamento e janela; 3) conferir UTMs, redirecionamento, atraso de processamento e duplicação; 4) separar conversão atribuída de pedido confirmado; 5) usar checkout/CRM/financeiro para contagem de negócio e plataformas para otimização/leitura de canal; 6) registrar a diferença e a causa provável antes de decidir.

## Checklists antes de publicar

Fonte: 05 — Tráfego, Tracking e Escala. Ver "Checklist de publicação" (seção Testes) e "QA de tracking" acima.

## Erros comuns

Fonte: 05 — Tráfego, Tracking e Escala

- Otimizar por vaidade (curtida, impressão, CTR) sem conectar ao negócio.
- Tratar ROAS da plataforma como lucro contábil.
- Usar Purchase em clique ou página de agradecimento acessível sem pagamento.
- Ignorar duplicação entre navegador e servidor.
- Misturar períodos, fusos, moedas, janelas e status de pedido.
- Alterar público, criativo, orçamento e página ao mesmo tempo.
- Escalar um pico curto sem volume, margem ou capacidade.
- Usar LTV projetado para justificar prejuízo atual.
- Reduzir orçamento por horário sem teste e sem compreender atraso de conversão.
- Chamar tentativa de burlar política de "contingência".

## Não encontrado nas páginas

- Criativos por conjunto (quantidade/variação recomendada por conjunto) — não detalhado nesta página.
- ABO vs. CBO como comparação explícita — só Advantage+ é citado; ABO/CBO não são nomeados.
- Passo a passo de configuração de GTM (variáveis, acionadores, tags) — não está nesta página.
- Lista de eventos padrão da Meta com nomes técnicos completos (ex.: Purchase, Lead, InitiateCheckout como identificadores de API) — a página cita os conceitos em português, não a lista técnica de nomes de evento.
