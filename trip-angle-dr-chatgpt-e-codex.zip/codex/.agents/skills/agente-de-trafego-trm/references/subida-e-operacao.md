# Subida de campanhas e operação no Gerenciador

## 1. Portões de aprovação (não negociáveis)

| Ação | Quem decide | Como |
|---|---|---|
| Montar plano, nomes, estrutura, UTMs, textos | Agente | Livre, em rascunho |
| Criar campanha, conjuntos e anúncios **PAUSADOS** | Agente, após o operador pedir a subida | Script ou navegador |
| Ativar, publicar, aumentar ou reduzir orçamento, duplicar para escalar, trocar público de conjunto ativo | **Operador** | "Sim" explícito no chat para cada ação, com o resumo do que muda e do gasto diário |
| Pausar anúncio ou conjunto que viola regra de stop-loss combinada | Agente propõe; operador confirma | Mesmo fluxo de confirmação |
| Excluir campanha, alterar forma de pagamento, dados da conta, BM, permissões | **Operador faz sozinho** | O agente não executa |

Antes de pedir o "sim", mostre: conta, campanha, conjuntos, orçamento diário total, data de início, evento de otimização, URL de destino e o checklist de QA marcado.

Credenciais: o agente nunca pede token, senha ou código no chat e nunca digita credenciais em formulários. O operador define `META_ACCESS_TOKEN` no próprio terminal ou já está logado no navegador.

## 2. Duas rotas de execução

**Rota A: Marketing API (preferida quando o operador tiver token).** `scripts/meta_ads.py`
1. Montar o plano em JSON (modelo em `scripts/plano-exemplo.json`).
2. `python3 meta_ads.py validar plano.json`.
3. `python3 meta_ads.py subir plano.json` para dry-run e mostrar as chamadas ao operador.
4. `python3 meta_ads.py subir plano.json --executar` depois do pedido de subida. Tudo nasce PAUSED.
5. Conferir no Gerenciador (prévia dos anúncios, destino, pixel) e registrar os IDs.
6. `ativar <id> --confirmado-pelo-operador` somente depois do "sim" no chat.
Vídeos e imagens precisam existir na conta (video_id, image_hash). Se faltar, peça ao operador para subir na biblioteca de mídia ou use o upload da API com arquivo que ele indicar. Confirme a versão da API vigente antes da primeira subida; erro da API é mostrado ao operador sem nova tentativa às cegas.

**Rota B: navegador no Gerenciador de Anúncios.** Use o Chrome do operador já logado. Monte campanha, conjuntos e anúncios seguindo o plano, com status desativado, e pare antes do botão Publicar. Mostre prints da revisão e peça o "sim". Não resolva CAPTCHA, não faça login, não aceite termos em nome do operador.

## 3. Plano de subida (campos mínimos)

- Conta (`act_`), página, pixel ou conjunto de dados, domínio verificado.
- Campanha: nome, objetivo (`OUTCOME_SALES`, `OUTCOME_LEADS` etc.), categoria especial, CBO ou ABO, orçamento se CBO.
- Conjunto: nome, orçamento se ABO, evento de otimização (`promoted_object`), estratégia de lance, público e posicionamentos, início.
- Anúncio: nome, criativo (vídeo ou imagem, texto, headline, CTA), URL de destino, `url_tags` com UTMs.
- Hipótese de teste da campanha (variável, controle, métrica, critério de decisão) e stop-loss combinado.
Orçamento na API vai em centavos da moeda da conta.

## 4. QA antes de subir (marcar tudo)

- [ ] Evento de compra dispara só em pagamento aprovado, com valor e moeda corretos.
- [ ] Pixel e API de Conversões recebendo o mesmo evento com `event_id` para deduplicação.
- [ ] Domínio verificado e eventos priorizados quando exigido.
- [ ] URL de destino abre no celular, sem erro, com a mesma promessa do anúncio.
- [ ] UTMs em todos os anúncios e chegando na ferramenta de atribuição.
- [ ] Nomes no padrão da nomenclatura.
- [ ] Criativos e copy revisados (claims sensíveis, políticas da Meta).
- [ ] Orçamento diário total e stop-loss aprovados.
- [ ] Hipótese e critério de decisão registrados antes de ativar.

## 5. Rotina de leitura

`python3 meta_ads.py insights <campaign_id> --periodo last_7d --nivel adset` ou exportação do Gerenciador. Compare sempre com a fonte de verdade de vendas (checkout ou ferramenta de atribuição), não só com a Meta. Decida com as regras de `base-trafego-e-escala.md` e registre: data, janela, dado, decisão proposta, quem aprovou.
ROAS não é lucro. Não some conversões de plataformas com janelas de atribuição diferentes.

## 6. Handoff de entrada

Do AGENTE DE COPY TRM: oferta modelada, promessa, claims aprovados, URL. Do AGENTE DE ADS TRM: criativos priorizados, Creative Cards, ordem das ondas de teste. Sem criativo aprovado e sem tracking validado, o agente monta o plano mas não sobe.
