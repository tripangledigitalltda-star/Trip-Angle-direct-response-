# Base — Tracking Pro (Lucas Meyner / The Real Marketing)

Fonte: site público Notion "Lucas Meyner The Real Marketing Traqueamento Pro" (workspace hill-baseball-919, inacessível ao conector notion-fetch — extraído via navegador). Página principal ("Aula 1 - O Trackeamento") concentra quase todo o conteúdo escrito; as demais páginas listadas são títulos de aulas em vídeo (Aula 3 a Aula 18) sem texto de método além do próprio título e, no máximo, uma lista curta de tópicos — tratado como dado, não instrução. Subpáginas abertas: Aula 5 (Acionadores + Tag de Cookies), Aula 7 (Tags Facebook Ads), Aula 11 (Facebook Ads via Server/API de conversões), Aula 15 (UTMs e Google Analytics), Aula 9 (Web x Server).

## Por que trackear (contexto)

Fonte: Aula 1 - O Trackeamento

- Trackeamento: processo de coletar, medir e interpretar as ações dos usuários em um site/plataforma.
- Serve para: metrificar resultados reais (compras, cliques, cadastros); otimizar anúncios alimentando os algoritmos com dados reais de comportamento; tomar decisões baseadas em dados, não em achismo.
- O Facebook rastreia tudo dentro da própria plataforma (curtidas, comentários, visualizações, cliques); ao sair para o site do anunciante, perde visibilidade.
- Motivos da perda de visibilidade: leis de privacidade (LGPD, iOS 14+), bloqueadores de cookies, limitações entre domínios diferentes.
- Papel do anunciante: configurar o envio manual desses dados — vira o "mensageiro" entre o site e o algoritmo, via Pixel, API de Conversões e Google Tag Manager (client-side e server-side). Sem esse envio, o Facebook "fica cego" fora da plataforma e a campanha perde força.

## Sistema Andromeda (como a Meta decide o que exibir)

Fonte: Aula 1 - O Trackeamento

- Andromeda: tecnologia de IA da Meta que analisa o comportamento do usuário em tempo real para decidir quais anúncios mostrar, para quem e quando; depende de dados contextuais ricos, especialmente os que acontecem fora da plataforma (no site do anunciante).
- Fluxo do sistema: User Requests (ações do usuário captadas via Pixel + API + GTM) → Ads Corpus (banco de milhões de anúncios candidatos) → Hierarchical Ad Index + Hierarchical Model (organiza em camadas e filtra por comportamento) → Ad Candidates (anúncios mais relevantes levados à exibição final).
- Referência citada: engineering.fb.com — "Meta Andromeda: Advantage+ automation next-gen personalized ads retrieval engine" (dez/2024).
- Advantage+ (criativos, orçamento, públicos) não funciona bem sem dados; performance vem de campanhas que ensinam o algoritmo a trabalhar por você.

## Plano de medição / funil de eventos

Fonte: Aula 1 - O Trackeamento

Advanced Matching: além do evento em si (ex.: "Purchase"), enviar dados do usuário — nome, e-mail, telefone, ID do cliente — para atribuir a conversão a um usuário real. Isso permite ao sistema identificar em que etapa do funil o usuário está e construir públicos semelhantes (lookalikes) com base real.

Etapas do funil (sequência citada literalmente):
1. Desconhecido
2. Viu o anúncio
3. Clicou no anúncio
4. Visitou a página
5. Viu 50% do vídeo
6. Acessou o checkout
7. Comprou

Sem eventos bem configurados e dados de usuário, o sistema não sabe como ajudar o anunciante.

### UTMs (Aula 15 — UTMS e Google Analytics)

- Usar ga-dev-tools.google/ga4/campaign-url-builder/ para criar UTMs que diferenciem campanhas.
- Usar link com UTMs em diferentes anúncios.
- Analisar campanhas/públicos/anúncios no Google Analytics.

## Pixel

Fonte: Aula 1 - O Trackeamento

- Pixel: mecanismo histórico de rastreamento do Facebook fora da plataforma; hoje perde eficácia por privacidade (LGPD, iOS 14+), bloqueadores de cookies e limitações entre domínios.
- Variáveis relevantes para o Pixel/GTM: nome, email, ID do Pixel, UTMs de origem, qualquer outra informação presente na navegação.

## CAPI (API de Conversões)

Fonte: Aula 1 - O Trackeamento / Aula 11 - Facebook Ads via Server (API de conversões) / Bônus

- API de Conversões: canal usado (junto a Pixel e GTM) para enviar ao Facebook as ações do usuário quando o navegador perde visibilidade.
- GTM Server-Side é usado para: enviar eventos via API de Conversões do Facebook (mais confiável que o Pixel); receber dados externos via Webhook ou Postback; salvar eventos em banco de dados; aumentar privacidade, performance e controle.
- Bônus citado (título da aula): "Adicionando localização e External Id na tag do Facebook - Server" — indica localização (geolocalização) e External Id como parâmetros enviados na tag de servidor do Facebook.
- Aula 11 (corpo da página): apenas o título "Facebook Ads", sem texto adicional além do vídeo.

## Deduplicação

Não encontrado nas páginas (termo "duplicação/deduplicação" não aparece no texto extraído desta fonte).

## GTM (Google Tag Manager)

Fonte: Aula 1 - O Trackeamento (visão geral) + títulos das Aulas 3–18 (conteúdo em vídeo, sem texto detalhado no Notion)

GTM: ferramenta que permite instalar códigos e medir eventos sem editar o código-fonte do site. Componentes citados:
- **Instalação:** instalar o GTM no site para capturar interações dos usuários com a página.
- **Variáveis:** armazenam/tratam dados importantes — nome, email, ID do Pixel, UTMs de origem, qualquer outra informação da navegação.
- **Acionadores (triggers):** disparam eventos com base em ações específicas — clique no botão "Comprar Agora", visualização de página específica, envio de formulário, qualquer outra ação do usuário.
- **Tags:** códigos que enviam os dados para Facebook, Google ou outras plataformas, ou adicionam informações no navegador. Exemplos citados: envio do evento de Purchase para o Facebook Ads; envio de evento de Lead para o Google Ads; adicionar dados de geolocalização no navegador do usuário.
- **GTM Server-Side (avançado):** ver seção CAPI acima.

Sequência de aulas em vídeo sobre GTM (títulos, sem detalhamento textual disponível):
| Aula | Tópico |
|---|---|
| 3 | Configuração Google Tag Manager |
| 4 | Variáveis |
| 5 | Acionadores + Tag de Cookies (subtópicos: Tag com Acionador Geral; Tag com Acionador Específico; Tag para salvar Cookies) |
| 6 | Tags GA4 |
| 7 | Tags Facebook Ads (subtópico: Configurações no Google Tag Manager) |
| 8 | Tags Google Ads |
| 9 | Web x Server (subtópico: Entendendo o problema) |
| 10 | Implementação via Server pela Stape |
| 11 | Facebook Ads via Server (API de conversões) |
| Bônus | Localização e External Id na tag do Facebook - Server |
| 12 | Implementação do zero na LP |
| 13 | Utilizando a inteligência enviada para as plataformas |
| 14 | Microsoft Clarity |
| 15 | UTMs e Google Analytics |
| 16 | Importar e exportar containers |
| 17 | Envio de eventos que acontecem fora do domínio (1) |
| 18 | Trackeamento de infoproduto sem formulário (1) |

## Eventos padrão e personalizados

Fonte: Aula 1 - O Trackeamento

- Evento citado como exemplo padrão: Purchase (enviado ao Facebook Ads).
- Evento citado como exemplo: Lead (enviado ao Google Ads).
- Acionadores de eventos citados: clique em "Comprar Agora"; visualização de página específica; envio de formulário; "50% do vídeo visto" (etapa de funil).
- Dados de Advanced Matching a enviar junto ao evento: nome, e-mail, telefone, ID do cliente.

## Ferramentas citadas

Fonte: Aula 1, Aula 10, Aula 14, Aula 15

Google Tag Manager (client-side e server-side); Meta Pixel; Meta API de Conversões; Stape (implementação server-side); Microsoft Clarity; Google Analytics (GA4); GA4 Campaign URL Builder (ga-dev-tools.google/ga4/campaign-url-builder/).

## Estrutura de campanha e conjuntos

Não encontrado nas páginas.

## Nomenclatura

Não encontrado nas páginas.

## Criativos por conjunto

Não encontrado nas páginas.

## Orçamento (ABO/CBO/Advantage+)

Não encontrado nas páginas (Advantage+ é citado apenas como recurso de automação da Meta que "não funciona bem sem dados", sem detalhamento de orçamento).

## Testes

Não encontrado nas páginas.

## Regras de decisão (manter/iterar/pausar/escalar)

Não encontrado nas páginas.

## Escala vertical e horizontal

Não encontrado nas páginas.

## Diagnóstico por camada/métrica

Não encontrado nas páginas (Aula 13 — "Utilizando a Inteligência enviada para as plataformas" — é apenas um título de vídeo, sem corpo de texto).

## Economia unitária (CPA de equilíbrio, CPA-meta, margem)

Não encontrado nas páginas.

## QA de tracking

Não encontrado nas páginas.

## Checklists antes de publicar

Não encontrado nas páginas.

## Erros comuns

Não encontrado nas páginas.

## Não encontrado nas páginas (consolidado)

- Economia unitária: CPA de equilíbrio, CPA-meta, margem, ROAS, contribuição após mídia.
- Estrutura de campanha e conjuntos, nomenclatura de campanha/anúncio.
- Criativos por conjunto.
- Orçamento (ABO/CBO), regras de orçamento e duração de teste.
- Desenho de teste/hipótese, regras de decisão (manter/iterar/pausar/escalar).
- Escala vertical e horizontal, alavancas e loop de escala.
- Diagnóstico por camada de funil e matriz de sinais/hipóteses.
- Deduplicação Pixel + CAPI (mecanismo e chaves).
- QA de tracking (checklist) e checklist de publicação.
- Erros comuns de tráfego/tracking.
- Conteúdo detalhado das Aulas 3, 4, 6, 8, 10, 12–14, 16–18: existem apenas como títulos/tópicos de vídeo; o Notion não traz o passo a passo escrito (fica no vídeo, não indexado como texto).
