#!/usr/bin/env python3
"""Vazamentos do funil (AGENTE DE CRO TRM).
Uso: python3 vazamentos.py etapas.csv
CSV com colunas: etapa,quantidade[,meta_taxa]
Cada linha é uma etapa em ordem (ex.: cliques, lpv, inicio_vsl, chegou_pitch, clique_cta, inicio_checkout, compra).
meta_taxa (opcional, decimal) é a taxa de passagem desejada DA ETAPA ANTERIOR PARA ESTA, declarada pelo operador.
Saída: taxa de cada passagem, queda, taxa acumulada e vendas adicionais se cada passagem atingisse a meta
(mantendo as demais iguais), ordenado por impacto.
"""
import csv, sys

def main():
    if len(sys.argv) < 2: print(__doc__); sys.exit(1)
    rows = [r for r in csv.DictReader(open(sys.argv[1], encoding="utf-8"))]
    q = [float(r["quantidade"]) for r in rows]; nomes = [r["etapa"] for r in rows]
    if len(q) < 2: sys.exit("Informe pelo menos duas etapas.")
    taxas = [q[i] / q[i-1] if q[i-1] else 0 for i in range(1, len(q))]
    final = q[-1]
    print("| Passagem | De | Para | Taxa | Queda | Acumulada | Meta | Vendas adicionais na meta |\n|---|---|---|---|---|---|---|---|")
    imp = []
    for i, t in enumerate(taxas, 1):
        meta = rows[i].get("meta_taxa", "").strip()
        extra = ""
        if meta:
            m = float(meta)
            if m > t and t > 0:
                ganho = final * (m / t) - final; extra = f"{ganho:.1f}"; imp.append((ganho, f"{nomes[i-1]} → {nomes[i]}"))
            else: extra = "meta já atingida"
        acum = q[i] / q[0] if q[0] else 0
        print(f"| {nomes[i-1]} → {nomes[i]} | {q[i-1]:.0f} | {q[i]:.0f} | {t:.1%} | {1-t:.1%} | {acum:.2%} | {meta and f'{float(meta):.1%}' or '-'} | {extra or '-'} |")
    if imp:
        imp.sort(reverse=True)
        print("\nPrioridade por impacto (vendas adicionais mantendo o resto igual):")
        for g, n in imp: print(f"- {n}: +{g:.1f}")
    else:
        pior = min(range(len(taxas)), key=lambda i: taxas[i])
        print(f"\nSem metas declaradas. Menor taxa de passagem: {nomes[pior]} → {nomes[pior+1]} ({taxas[pior]:.1%}). Declare metas por etapa para priorizar por impacto.")
    print("Queda alta nem sempre é o maior problema: compare com a meta da etapa e confirme a integridade dos dados antes.")

if __name__ == "__main__": main()
