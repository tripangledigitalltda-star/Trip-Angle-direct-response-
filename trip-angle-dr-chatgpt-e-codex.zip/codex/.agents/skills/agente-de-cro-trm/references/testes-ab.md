# Testes A/B de funil

Origem: Test Card da casa (`../../agente-central-trm/references/vocabulario/test-card.md`) e Test Card do módulo 03. A priorização e a checagem estatística são **regra operacional derivada**, somadas ao critério da casa, nunca no lugar dele.

## Test Card (campos da casa)
Nome (`<OFERTA>-TC0n — <o que compara>`) · oferta e versão · hipótese ("Se eu mudar X mantendo Y, espero Z porque…") · evidência que originou · variável única · variação A (controle) e B · o que não pode mudar · canal, audiência e destino iguais nos braços · orçamento e limite de perda · amostra planejada · janela · métrica principal · métricas secundárias · critério de vitória · critério de descarte · risco e claim revisado · confiabilidade (Nível D até haver dados) · status · resultado observado · interpretação · decisão · aprendizado · próximo teste.

## Critérios da casa
- Amostra mínima: 100 cliques por braço, com distribuição equivalente.
- Janela: 7 dias de tráfego simultâneo, ou até os dois braços atingirem a amostra mínima, o que ocorrer por último.
- Vitória: variação supera o controle em pelo menos 20% na métrica principal predefinida, sem piora superior a 10% nas secundárias e sem novo risco de compliance.
- Descarte só por falha de rastreamento, violação de integridade da fonte, erro de entrega ou desequilíbrio de amostra.

## Checagem estatística (derivada)
100 cliques por braço é o mínimo da casa para começar a ler, não garantia de conclusão. Para métrica de conversão com taxa baixa, calcule a amostra com `scripts/teste_ab.py amostra`. Só adote a variante quando **as duas condições** forem atendidas: critério da casa e significância (padrão: confiança de 95%, poder de 80%). Se o critério da casa foi atingido sem significância, o resultado é **promissor, não conclusivo**: estender a janela ou retestar.

## Priorização (derivada)
| Critério | Pergunta | Nota 1–5 |
|---|---|---|
| Impacto | Quantas vendas a mais se a etapa melhorar (saída do `vazamentos.py`)? | |
| Evidência | Quão forte é o dado que aponta a causa (curva, gravação, segmento)? | |
| Facilidade | Quanto trabalho e risco para implementar? | |
| Volume | A etapa tem tráfego suficiente para testar na janela? | |
Ordene pela soma; empate decide pelo impacto.

## Como dividir o tráfego
- Página ou VSL: ferramenta de split da própria página, construtor ou player com teste A/B; mesma fonte e mesmo período nos dois braços.
- Checkout: recursos de teste da plataforma quando existirem; senão, alternância por período é evidência mais fraca e deve ser marcada assim.
- Criativo: experimento A/B da Meta, conduzido pelo AGENTE DE TRÁFEGO.

## Erros que invalidam o teste (casa)
Mudar muitas coisas · parar cedo · ignorar amostra · escolher métrica depois · tratar correlação como causalidade · declarar vitória por um resultado · esconder inconclusividade · chamar backlog de experimento executado ou hipótese de aprendizado.
