# Diagnóstico do funil

Origem: métricas por camada e leitura correta do módulo 03 e do Test Card da casa; matriz de diagnóstico de `../../agente-de-trafego-trm/references/base-trafego-e-escala.md`. Leituras de VSL, quiz e checkout abaixo são **regra operacional derivada**.

## Métricas por camada (casa)
Atenção: retenção inicial, hook rate · Clique: CTR e CPC · Ativo: avanço por seção, lead, formulário, conversão, abandono · Checkout: início, abandono, compra · Economia: CPA, receita líquida, margem, ticket, reembolso · Entrega: ativação, uso, conclusão, suporte, retenção.
"CTR baixo não prova produto ruim; conversão baixa não prova falta de urgência." Localize a etapa, colete evidência, formule a próxima hipótese.

## Ordem de investigação (base de tráfego)
1 Integridade do dado · 2 Entrega e disponibilidade · 3 Criativo e mensagem · 4 Página, quiz ou formulário · 5 Checkout ou atendimento · 6 Produto, qualidade e economia.

## Etapas e taxas a calcular
| Passagem | Taxa |
|---|---|
| Clique no link → visualização da página | LPV ÷ cliques |
| Página → início da VSL ou do quiz | inícios ÷ LPV |
| VSL → chegada ao momento da oferta | retenção no segundo do pitch |
| Oferta vista → clique no CTA | cliques no CTA ÷ chegadas ao pitch (ou ÷ LPV em página sem VSL) |
| Quiz → conclusão | conclusões ÷ inícios; abandono por tela |
| CTA → início de checkout | IC ÷ cliques no CTA |
| Início de checkout → compra aprovada | compras ÷ IC; por meio de pagamento |
| Compra → upsell | aceitações ÷ compras |
| Compra → reembolso | reembolsos ÷ compras |

## Sintoma → onde olhar
| Sintoma | Primeiras hipóteses | Onde verificar |
|---|---|---|
| Cliques altos, poucas visualizações de página | Página lenta no celular, redirecionamento, link quebrado, bloqueio de consentimento, pixel sem disparar | Velocidade móvel, rede, redirecionamentos, evento PageView |
| Página carrega, VSL ou quiz pouco iniciado | Primeira dobra sem continuidade com o anúncio, player fora da tela, autoplay bloqueado, headline fraca | Print da primeira dobra no celular, mapa de clique |
| Retenção da VSL cai forte num trecho | Bloco do roteiro naquele minuto: lead longo, história sem tensão, mecanismo confuso, promessa adiada demais | Curva de retenção sobreposta ao roteiro com tempos |
| Muitos chegam ao pitch, poucos clicam | Oferta, preço, ancoragem, garantia, CTA pouco visível ou atrasado | Tempo de exibição do botão, clique no CTA, texto do bloco de oferta |
| Quiz com abandono numa tela | Pergunta invasiva, longa, sem efeito aparente, tela de captura antes do valor | Abandono por tela; ordem das perguntas |
| CTA clicado, checkout pouco iniciado | Redirecionamento lento, preço diferente do mostrado, checkout que abre em outra aba ou falha | Teste do link com UTMs, tempo de carregamento do checkout |
| Checkout iniciado, compra não conclui | Campos demais, meio de pagamento, cartão recusado, custo total inesperado, falta de confiança | Funil da plataforma por meio de pagamento e dispositivo; Pix e boleto gerados e pagos |
| Compra boa, upsell baixo | Upsell desconectado do front, página longa, recusa difícil de achar | Taxa de aceitação e gravação da página de upsell |
| Compra boa, reembolso alto | Promessa desalinhada com a entrega, acesso difícil, público errado | Motivos de reembolso, acesso em 48 h, anúncio usado |
| Um segmento muito pior (ex.: iOS, Android antigo, um navegador) | Problema técnico | Teste no dispositivo e navegador do segmento |

## Leitura da curva de retenção da VSL
1. Alinhe a curva ao roteiro com tempos (bloco por bloco).
2. Queda nos primeiros 30 segundos: hook e lead.
3. Queda gradual e contínua é esperada; degrau abrupto indica um bloco específico.
4. Compare a porcentagem que chega ao pitch com a taxa de clique no CTA: se muitos chegam e poucos clicam, o problema é a oferta; se poucos chegam, é o roteiro antes dela.
5. Teste uma mudança por vez no trecho do degrau (encurtar, reordenar, trocar a entrada do bloco).

## Checklist rápido de página no celular
- [ ] Carrega rápido em rede móvel
- [ ] Primeira dobra repete a promessa do anúncio
- [ ] Player ou primeira pergunta visível sem rolar
- [ ] CTA principal visível e com texto de ação
- [ ] Preço e condições iguais no checkout
- [ ] Nenhum pop-up que impede avançar
- [ ] Links e UTMs funcionando até o checkout
