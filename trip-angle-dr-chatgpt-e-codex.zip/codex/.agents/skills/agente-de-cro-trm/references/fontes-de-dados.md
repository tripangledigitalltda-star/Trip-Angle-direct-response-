# Fontes de dados do CRO

| Número | Fonte principal | Validação |
|---|---|---|
| Cliques no link, LPV | Gerenciador de Anúncios | LPV próximo de sessões da página no mesmo período |
| Sessões, rolagem, cliques em elementos | Analytics da página (ex.: GA4) e mapas de calor e gravações (ex.: Microsoft Clarity, Hotjar) | Mesma janela e fuso; filtro de tráfego interno |
| Início e retenção da VSL | Painel do player (ex.: Vturb, Panda, YouTube) | Plays próximos de LPV × taxa de início |
| Telas do quiz | Eventos personalizados do quiz ou analytics | Soma de abandonos bate com inícios − conclusões |
| Clique no CTA | Evento personalizado ou analytics | Próximo de inícios de checkout |
| Início de checkout, compra aprovada, meio de pagamento, Pix e boleto | Plataforma de checkout (fonte de verdade de venda) | Compras aprovadas batem com o financeiro |
| Upsell e reembolso | Plataforma de checkout | Idem |
| Atribuição por campanha e anúncio | Ferramenta de atribuição com UTMs | Soma próxima das vendas da plataforma |

Regras:
- Venda é o que a plataforma aprovou, não o que a Meta atribuiu.
- Não somar conversões de fontes com janelas de atribuição diferentes.
- Registre a data de extração e o fuso de cada fonte.
- Gravações de sessão e mapas de calor precisam constar na política de privacidade e respeitar consentimento.
- Divergência acima do que o operador aceita entre fontes vira hipótese de tracking antes de qualquer teste.
