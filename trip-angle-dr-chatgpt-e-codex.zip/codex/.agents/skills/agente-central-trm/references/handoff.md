# Handoff entre agentes

## 1. Bloco obrigatório (template da Biblioteca Operacional Trip Angle)

```
HANDOFF DO PROJETO
Projeto:
Etapa concluída:
Agente:
Versão e data:
Objetivo:
Entradas utilizadas:
Evidências confirmadas:
Hipóteses abertas:
Decisões aprovadas:
Artefatos produzidos:
Claims e provas pendentes:
Riscos e restrições:
Métrica principal:
Portão de aprovação:
Próximo agente:
Próxima ação única:
```
"Portão de aprovação" é `aprovado por <nome> em <data>` ou `pendente: <o que precisa ser aprovado>`. "Artefatos produzidos" lista caminhos de arquivo.

## 2. Regras
- Toda etapa termina com o bloco. Sem ele a etapa fica "em andamento" no estado.
- O agente seguinte abre pedindo o bloco da etapa anterior e só os artefatos listados nele.
- Hipótese aberta não vira fato na etapa seguinte. Claim pendente continua pendente até alguém anexar a prova.
- Etapa pulada é registrada como "pulada" com o motivo.

## 3. Pacote de entrada por agente

| Agente | Precisa do projeto | Precisa do operador |
|---|---|---|
| ESPIONAGEM | Nicho, país, termos, tipo de oferta-alvo | Recorte e prioridade |
| ADS | Handoff da ESPIONAGEM (oferta, anunciantes, IDs, destino) ou oferta e assunto | Objetivo da pesquisa, países |
| COPY | Handoffs de ESPIONAGEM e ADS (oferta de referência, funil, hooks, temas) | Produto real, entregáveis, preço, provas próprias, país de destino |
| FUNIL | Handoff do COPY (oferta modelada, copy aprovada, claims) | Plataforma de página e checkout, domínio |
| PRODUÇÃO DE CRIATIVOS | Handoffs de ADS (Creative Cards, ondas) e COPY (hooks, roteiros curtos, claims) | Ferramentas de produção, identidade visual, direitos de imagem |
| COMPLIANCE | Peças de COPY, FUNIL e PRODUÇÃO | País e categoria do produto |
| TRÁFEGO | Handoffs de COPY (URL, claims), PRODUÇÃO ou ADS (criativos), FUNIL (checkout, eventos) | Custos, orçamento, limite de perda, conta, pixel, rota de subida |
| PRODUTO | Handoff do COPY (promessa, stack, bônus, claims) e do BACKEND (motivos de reembolso) | Formato, plataforma de membros, identidade visual, conteúdo existente, especialista |
| BACKEND e CRO | Handoffs de FUNIL e TRÁFEGO (dados por etapa) | Ferramentas de e-mail e WhatsApp, acesso a dados |

## 4. Saídas esperadas por agente (para "Artefatos produzidos")
- ESPIONAGEM: relatório da rodada, tabela de triagem, Mapa de Oportunidades.
- ADS: relatório do editor, radar de temas, banco de hooks, matriz de conceitos, Creative Cards, planilha TRM LAB.
- COPY: mapa da oferta, diagnóstico, card da oferta modelada, VSL, página, leads, banco de headlines, roteiros de anúncio, tabela de claims, hipóteses de teste.
- PRODUTO: arquitetura, matriz promessa × produto, conteúdo em Markdown, PDF, roteiros de aula, estrutura da área de membros.
- TRÁFEGO: economia unitária, plano de medição, QA de tracking, plano de campanha, IDs subidos, registro de decisão.
