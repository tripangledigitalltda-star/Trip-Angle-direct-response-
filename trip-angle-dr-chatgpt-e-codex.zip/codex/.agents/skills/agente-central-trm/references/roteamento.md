# Roteamento de pedidos

## Por artefato desejado

| O operador quer receber | Agente | Frases típicas |
|---|---|---|
| Ofertas que estão rodando, funis, anunciantes, sinais de escala | `agente-de-espionagem-trm` | "minera", "espiona", "o que está escalando em", "acha ofertas de", "tria esses cartões" |
| Referências de vídeo, hooks usados, temas virais, formatos em alta, ideias de criativo, registro no TRM LAB | `agente-de-ads-trm` | "traz referências de criativos", "hooks virais de", "o que viraliza no TikTok sobre", "formatos em alta", "alimenta o lab" |
| Mapa de uma oferta, diagnóstico de copy, oferta modelada, VSL, página, leads, headlines, stack, garantia | `agente-de-copy-trm` | "modela essa oferta", "escreve a VSL", "copy da página", "novos ângulos para a oferta", "mapeia personas e dores" |
| Economia da oferta, plano de medição, pixel, CAPI, UTMs, campanha, subida, leitura de métricas, escala | `agente-de-trafego-trm` | "sobe a campanha", "configura o tracking", "qual CPA máximo", "analisa os números", "escalo ou pauso" |
| Página, quiz, pré-lander, checkout, order bump, upsell construídos | `agente-de-funil-trm` (AGENTE DE FUNIL TRM) | "monta a página", "cria o quiz", "estrutura o checkout" |
| Peça final de criativo, roteiro final, prompts de IA de imagem ou vídeo | `agente-de-producao-de-criativos-trm` | "roteiriza", "gera os prompts", "faz as variações" |
| Revisão de política e claims antes de publicar | `agente-de-compliance-trm` | "isso passa na Meta?", "revisa os claims" |
| Recuperação, e-mails, WhatsApp, upsell pós-compra, reembolso | `agente-de-backend-trm` (AGENTE DE BACKEND TRM) | "sequência de recuperação", "pós-venda" |
| Gargalo de página ou checkout, teste A/B de página | `agente-de-cro-trm` (AGENTE DE CRO TRM) | "a página não converte", "onde o funil vaza" |
| Entregável do produto: ebook, protocolo, cardápio, receitas, aulas, bônus, área de membros | `agente-de-produto-trm` | "cria o ebook", "monta o protocolo", "estrutura a área de membros", "faz os bônus" |
| Estado do projeto, próximo passo, o que falta | `agente-central-trm` | "em que pé está", "próximo passo", "abre um projeto" |

## Casos de fronteira

| Pedido | Vai para | Motivo |
|---|---|---|
| "Analisa esse anúncio concorrente" | ADS se o foco é o criativo; ESPIONAGEM se o foco é a oferta e o funil | Decidir pelo artefato |
| "Quero hooks para a minha oferta" | COPY | Hooks escritos para a oferta própria |
| "Quais hooks estão sendo usados em mounjaro" | ADS | Pesquisa de referências |
| "Essa oferta gringa funciona no Brasil?" | ESPIONAGEM para sinais; COPY para localização | Sequência de duas etapas |
| "O CPA subiu" | TRÁFEGO | Diagnóstico por camada começa na mídia e no tracking |
| "A VSL não converte" | TRÁFEGO para confirmar dados; depois COPY | Primeiro descartar tracking e tráfego |

## Skills antigas consolidadas (13/09/2026)

As skills `ta-*` foram incorporadas: vocabulário e Test Card em `../../agente-central-trm/references/vocabulario/`; leitura, modelagem sem cópia e criação do zero no AGENTE DE COPY; templates de criativos no AGENTE DE PRODUÇÃO; fases de tráfego no AGENTE DE TRÁFEGO; mineração virou AGENTE DE ESPIONAGEM (`agente-de-espionagem-trm`). Cópias originais em `~/Desktop/trip-angle-dr/arquivo-skills-antigas/`.
