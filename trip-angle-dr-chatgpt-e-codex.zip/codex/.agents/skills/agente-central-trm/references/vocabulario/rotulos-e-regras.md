# Rótulos de evidência, controle de certeza e regras de risco

## Tabela de rótulos (Como Ler uma Oferta do Zero)
| Exemplo | Significado | Etiqueta |
|---|---|---|
| A página informa preço de R$ 97 | Aparece literalmente na fonte | ORIGINAL OBSERVADO |
| "Transformação em sete dias" | A peça afirma, não validado | ALEGAÇÃO DA COPY |
| O anúncio começa com uma pergunta | Descrição verificável da estrutura | OBSERVAÇÃO |
| A pergunta parece reduzir culpa | Leitura fundamentada do analista | INTERPRETAÇÃO ESTRATÉGICA |
| Três ofertas usam diagnóstico antes da promessa | Relação repetida em fontes independentes | PADRÃO IDENTIFICADO |
| O reframe pode aumentar avanço para a VSL | Aplicação ainda não testada | HIPÓTESE |
| Margem ou taxa de conversão ausentes | A fonte não permite responder | NÃO MAPEADO |

Cadeia: ORIGINAL → OBSERVAÇÃO → INTERPRETAÇÃO → DNA → PRINCÍPIO → HIPÓTESE → TEST CARD → RESULTADO.

## Controle de certeza (Como Criar do Zero)
| Status | Significado | Uso permitido |
|---|---|---|
| Observado | Aparece diretamente na fonte | Descrever com referência |
| Inferido | Conclusão razoável a partir de sinais | Apresentar como interpretação |
| Hipótese | Explicação ainda não testada | Levar a Test Card |
| Alegação/claim | Afirmação comercial que exige sustentação | Revisar prova e risco |
| Comprovado para esta oferta | Evidência direta, adequada e documentada | Comunicar dentro do alcance da prova |

Regra de síntese (voz do cliente): uma fala isolada é sinal; repetição entre fontes vira padrão; padrão testado pode virar aprendizado.

## Claim → Prova → Limite
| Claim | Prova apresentada | O que a prova sustenta | Limite / risco |
|---|---|---|---|
| Resultado | Depoimento ou caso | Experiência daquela fonte | Representatividade, autorização, contexto |
| Mecanismo | Demonstração ou explicação | Compreensão ou funcionamento observado | Não prova causalidade universal |
| Velocidade | Prazo declarado | Condição apresentada | Variação individual, base factual |
| Autoridade | Credencial | Qualificação no domínio | Autenticidade, pertinência |
| Escassez | Prazo ou quantidade | Limite comercial verificável | Falsa urgência, omissão |

Claims implícitos contam: o anunciante responde também por mensagens razoavelmente sugeridas.

## Compliance mínimo
- CDC (Lei 8.078/1990) arts. 36–38: identificação da publicidade, manutenção dos dados que sustentam a mensagem, vedação a publicidade enganosa ou abusiva; ônus da veracidade é do anunciante.
- CONAR — Código Brasileiro de Autorregulamentação Publicitária.
- Meta — Padrões de Publicidade: atributos pessoais, práticas enganosas, saúde (antes/depois, promessas de emagrecimento, nomes de medicamentos).
- Direitos autorais (Lei 9.610/1998): ideias e métodos não são protegidos; expressão concreta (texto, imagem, vídeo, voz, design) é.

Checklist antes de publicar: resultado anunciado dentro do que o produto entrega · evidência arquivada para números e declarações · exceção não tratada como típica · depoimentos com autorização e contexto · limitações não omitidas · garantia, preço, prazo e escassez verdadeiros · regras do canal, país e categoria · claims sensíveis revisados.

## Regras de estudo (Portal)
Original ≠ Observação ≠ Interpretação ≠ Modelagem ≠ Teste. Alegação de copy não é automaticamente fato. Modelagem não é cópia. Se algo não aparece nos materiais, registre NÃO MAPEADO NOS MATERIAIS. Não altere várias partes do projeto ao mesmo tempo sem registrar a variável. Não comece um novo projeto para fugir do desconforto de testar o atual.
