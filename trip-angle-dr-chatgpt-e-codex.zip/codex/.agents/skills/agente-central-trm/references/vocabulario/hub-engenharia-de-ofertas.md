# Hub de engenharia de ofertas (origem: skill agente-central-trm (vocabulário), consolidada em 13/09/2026)

# Engenharia de Ofertas — Trip Angle (hub)

Esta é a camada de regras e navegação. As etapas têm skills próprias:

| Fase | Pergunta | Skill a abrir | Entregável |
|---|---|---|---|
| 02 Inteligência | O que está rodando no mercado e com que sinal? | `agente-de-espionagem-trm` | Registro de evidências + Mapa de Oportunidades |
| 02→03 Leitura | Como essa oferta funciona por dentro? | `../../../agente-de-copy-trm/references/leitura-de-oferta.md` | Ficha de Fonte, Mapa Estratégico, Matriz Claim→Prova→Limite, DNA |
| 03 Modelagem | O que é transferível sem copiar? | `../../../agente-de-copy-trm/references/modelagem-sem-copia.md` | DNA funcional, matriz verde/amarelo/vermelho, hipótese, nova configuração, auditoria |
| 03 Criação | Como fica a nossa oferta? | `../../../agente-de-copy-trm/references/criacao-de-oferta-do-zero.md` | Dossiê, tese, Offer Card, Card Final, briefings para 04 Criativos e 05 Tráfego |
| 03→05 Teste | O que aprendemos primeiro? | `references/test-card.md` (aqui) | Test Card com variável, controle, métrica, janela, critério |
| 04 Criativos / 05 Tráfego | Como virar peça, campanha e decisão? | `agente-de-producao-de-criativos-trm` | Creative Card, matriz, roteiro, QA; economia unitária, tracking, diagnóstico, escala |

Fluxo por categoria do workspace: 02 Inteligência → 03 Engenharia → 04 Criativos → 05 Tráfego → registrar aprendizado e decisão em 07 Governança. Nada pula etapa: hooks só depois de situação, problema, desejo, crenças e mecanismo registrados.

## Por que a metodologia é assim

O workspace foi construído para que qualquer pessoa consiga auditar uma análise voltando da interpretação até o trecho original. Por isso o sistema separa observação de interpretação, alegação de prova, modelagem de cópia e hipótese de resultado. Uma análise que mistura essas camadas parece completa, mas não permite decidir nem aprender. Trate cada afirmação como algo que outra pessoa vai conferir.

## Rótulos de evidência (obrigatórios em toda análise)

Marque cada afirmação antes de interpretá-la:

- **ORIGINAL OBSERVADO** — aparece literalmente na fonte (preço, texto, estrutura).
- **ALEGAÇÃO DA COPY** — a peça afirma; não foi validado (todo claim de resultado, mecanismo, saúde, dinheiro).
- **OBSERVAÇÃO** — descrição verificável da estrutura (o anúncio abre com pergunta).
- **INTERPRETAÇÃO ESTRATÉGICA** — leitura fundamentada do analista.
- **PADRÃO IDENTIFICADO** — relação repetida em fontes independentes.
- **HIPÓTESE** — explicação ou aplicação ainda não testada.
- **NÃO MAPEADO NOS MATERIAIS** — a fonte não permite responder. Nunca preencher lacuna por inferência.
- Para Big Idea: CONFIRMADA / PROVÁVEL / NÃO CONFIRMADA (como tese comunicada, nunca como performance).

Anúncio ativo, contagem "N anúncios usam esse criativo", data de início e repetição de mecanismo são **sinal de escala**: mostram investimento e continuidade observáveis, não comprovam vendas, lucro, ROAS ou eficácia. Escreva "sinal de escala", nunca "está escalando" ou "domina".

## Sequência canônica (resumo)

Mercado → Persona → Situação → Problema → Dor → Desejo → Crenças → Soluções tentadas → Mecanismo do problema → Mecanismo da solução → Mecanismo único → Nova oportunidade → Big Idea → Ângulo → Promessa → Hook → Lead → Formato → Ad → Prova → Objeção → VSL → Produto → Oferta → Componentes → Funil → DNA → Engenharia reversa → Modelagem → Nova oferta → Test Card → Teste → Aprendizado.

Régua pedagógica em cada conceito: Entender → Identificar → Ver no Original → Decompor → Comparar → Modelar → Testar. Detalhes, portões P1–P8 e 47 dimensões em `references/sequencia-canonica.md`.

## Regras da casa que não se negociam

1. Modelagem não é cópia. Transfere-se função (verde), adapta-se padrão contextual com prova própria (amarelo), nunca se reutiliza expressão, nome, personagem, prova, número, preço, escassez ou identidade (vermelho).
2. Não inventar prova, depoimento, dado, escassez, credencial ou resultado. Se não existe, é HIPÓTESE ou NÃO MAPEADO.
3. Mecanismo é a lógica que sobra quando se remove o nome proprietário. Se não sobra lógica, é skin.
4. Uma variável por teste. Critério de decisão antes do resultado. Resultado inconclusivo não é vitória.
5. Claims de saúde, emagrecimento, dinheiro, comparação absoluta e garantia de retorno exigem revisão (CDC arts. 36–38, CONAR, Padrões de Publicidade da Meta). Registrar em 12 — Claims e Risco antes de qualquer teste.
6. Registrar fonte, data, ID, anunciante, país e versão em tudo. Sem linhagem, a análise não vale.
7. IA organiza, compara e gera variações; não substitui briefing, evidência nem decisão.

## Vocabulário

Use os termos do glossário (`references/glossario.md`): Hook ≠ Lead ≠ Headline; Ângulo ≠ Promessa ≠ Claim; Produto ≠ Oferta ≠ Funil ≠ VSL; Mecanismo do problema / da solução / único / skin; Stack, Bump, Upsell, Downsell só quando observados.

## Onde cada registro entra (19 bases técnicas)

Ordem de consulta: diagnóstico (01 Fontes, 02 Personas, 19 Mapa de Oportunidades) → mensagem (03 Hooks, 04 Ângulos, 05 Mecanismos, 15 Promessas, 16 Objeções) → criativos/percurso (06 Formatos, 08 Ads, 09 VSLs, 10 Funis) → oferta/risco (07 Ofertas, 11 Provas, 12 Claims e Risco, 17 Produtos, 18 Componentes) → modelagem/aprendizagem (13 Swipe File, 14 Test Cards). Esquemas de colunas em `references/bases-tecnicas.md`. Toda entrega deve dizer em qual base cada registro seria gravado.

## Formato de entrega

Comece por "Resumo de uma linha": "Para [pessoa em situação], a oferta apresenta [produto] como meio de alcançar [progresso], porque [mecanismo], sustentado por [prova observada], mediante [condições]." Depois, tabelas com a coluna de rótulo de evidência. Termine com: limites da leitura, claims pendentes de revisão, próxima hipótese e Test Card proposto. Tom da marca: direto, analítico, sem motivação vazia, sem promessa mágica.
