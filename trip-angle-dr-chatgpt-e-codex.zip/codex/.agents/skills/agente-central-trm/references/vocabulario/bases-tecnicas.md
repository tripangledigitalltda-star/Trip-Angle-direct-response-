# As 19 bases técnicas (Arsenal Técnico) — esquemas e uso

Ordem de consulta: diagnóstico → mensagem → criativos/percurso → oferta/risco → modelagem/teste. Cada registro carrega: Nicho/Mercado, Confiabilidade (Nível A–D; D = hipótese), fonte/linhagem e rótulo de evidência. Convenção de IDs por oferta: `<OFERTA>-AD01`, `-VSL01`, `-HK01`, `-ANG01`, `-MEC01`, `-TC01`, `-OP01`.

## Diagnóstico e oportunidade
- **01 — Fontes e Evidências**: Fonte URL, Origem (Meta Ad Library, Google Ads Transparency, página, checkout, review), Grupo, Nicho/Mercado, Status, Confiabilidade, Limitações, Observações. Regra: registrar data, ID do anúncio, anunciante, país e etapa realmente acessada.
- **02 — Personas**: Contexto, Idade provável, Dor visível, Dor invisível, Dor emocional, Frustrações, Desejo emocional, Linguagem e frases (literal).
- **19 — Mapa de Oportunidades**: Oportunidade, Lacuna, Tipo (Teste/Pesquisa/Produto), Prioridade, Base observada (IDs e linhas), Persona, Dor, Desejo, Mecanismo, Ângulo, Funil sugerido, Produto sugerido, Prova necessária, Risco, Confiabilidade, Status (Hipótese). Regra: oportunidade derivada de lacuna observada, não de desejo importado de livros.

## Mensagem e persuasão
- **03 — Hooks**: Formato, Ângulo, Mecanismo, Curiosidade, Desejo, Risco, Ofertas relacionadas.
- **04 — Ângulos**: Definição, Problema, Variações, Hooks compatíveis, Criativos compatíveis, VSLs compatíveis, Confiabilidade.
- **05 — Mecanismos**: Tipo (problema/solução/único), Novidade percebida, Facilidade de explicação, Curiosidade, Capacidade de criativos, Saturação interna, Risco científico, Ofertas que utilizam.
- **15 — Promessas e Desejos**: Promessa original (literal), Tipo, Ângulo, Prova necessária, Risco, Status.
- **16 — Objeções e Crenças**: Crença ou dúvida, Trecho original, Resposta usada, Etapa, Persona, Oferta, Risco.

## Criativos e percurso
- **06 — Formatos de Criativos**: Duração, Cenas, Variações, Exemplos, Hooks e Mecanismos compatíveis, Facilidade de escala, Saturação interna.
- **08 — Ads e Criativos**: Texto original, Estrutura abstrata (função por bloco), Problema, Mecanismo, CTA, Formato, Status de linhagem.
- **09 — VSLs**: Lead, Mecanismo do problema, Transição para produto, Preço e ancoragem, Bônus, Depoimentos, Confiabilidade.
- **10 — Funis**: Entrada observada, Sequência observada, VSL, Retenção, Oferta relacionada, Hipóteses, Inconsistências, Confiabilidade. Só etapas observadas.

## Oferta, entrega e risco
- **07 — Ofertas**: Big Idea, Dor, Desejo, Mecanismo da solução, Provas, Urgência, Pontos fortes, Produto relacionado.
- **11 — Provas**: Tipo, Texto ou descrição original, O que pretende provar, Fonte, Risco, Status, Confiabilidade.
- **12 — Claims e Risco**: Original, O que a copy apresenta como prova, Evidência real disponível, Risco, Reformulação segura, Princípio de aprendizado, Confiabilidade.
- **17 — Produtos e Entregáveis**: Problema resolvido, Transformação proposta, Bônus, Order bump, Upsell, Risco.
- **18 — Componentes de Oferta**: Descrição, Função na oferta, Problema que resolve, Prova necessária.

## Modelagem e aprendizagem
- **13 — Swipe File**: Texto original, Fonte, Etapa do funil, Consciência, Emoção, Ângulo, Mecanismo, Confiabilidade. Estudo, não cópia; consultar só depois de entender o problema.
- **14 — Test Cards**: Nome, Hipótese, O que estamos testando, Tipo de variável, Variação A/B/C, Controle, O que não pode mudar, Persona, Audiência, Canal, Destino, Formato, Hook, Ângulo, Mecanismo, Promessa, CTA, Script, Métrica principal, Métrica secundária, Amostra planejada, Janela, Critério de vitória, Critério de descarte, Prova necessária, Confiabilidade, Status, Resultado, Aprendizado.

## Bases por fonte de registro na mineração
Uma rodada de mineração alimenta, nesta ordem: 01 (fonte) → 08/09/10 (peças e funil observados) → 02/15/16 (persona, promessa, objeções literais) → 05/04/03 (mecanismo, ângulo, hook por função) → 07/17/18/11/12 (oferta, produto, componentes, provas, claims) → 19 (oportunidade) → 13 (swipe) → 14 (test card).
