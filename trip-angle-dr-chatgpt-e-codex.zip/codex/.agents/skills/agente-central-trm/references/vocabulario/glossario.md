# Glossário de Engenharia de Ofertas (dicionário operacional)

Cada termo: o que é · com o que não confundir · exemplo · onde estudar (base técnica).

1. **Hook** — dispositivo inicial que interrompe a atenção e cria relevância. Não é o lead. Ex.: pergunta, descoberta, segredo ou identificação nos Ads. Base 03.
2. **Lead** — desenvolvimento inicial que confirma relevância e conduz à próxima leitura. Não é headline nem hook isolado. Ex.: abertura e primeiros blocos de uma VSL. Base 09. Famílias de lead (Great Leads): oferta, promessa, solução de problema, grande segredo, revelação, história; abertura direta ou indireta.
3. **Ângulo** — enquadramento escolhido para apresentar problema, desejo ou oportunidade. Não é a promessa. Ex.: bloqueio invisível, conhecimento reservado, ciclo herdado. Base 04.
4. **Promessa** — benefício ou resultado que a copy associa à oferta. Não é claim validado nem garantia. Base 15.
5. **Claim** — afirmação que pode exigir prova, validação ou qualificação de risco. Não é evidência independente. Ex.: alegações financeiras, médicas, científicas, de resultado. Base 12.
6. **Mecanismo** — explicação causal apresentada pela copy para o problema ou para a solução. Não é o produto nem o nome proprietário. Camadas: mecanismo do problema, mecanismo da solução, mecanismo único (diferenciação percebida), skin (nome/ritual/personagem/superfície). Teste: remova o nome; se não sobra lógica, é skin. Base 05.
7. **Big Idea** — tese central que organiza a interpretação da oferta. Não é frase de anúncio nem slogan. Teste: resuma a tese sem headline, nome, personagem ou bordão; se o resumo desaparece, você capturou superfície. Matriz Mestre / Base 07.
8. **Nova oportunidade** — caminho que surge quando a copy reenquadra o problema ("talvez o caminho não seja X, mas Y"). Não é mercado novo nem demanda comprovada. Permanece hipótese até produto e teste. Base 19.
9. **Formato** — recipiente de produção e distribuição (Ad, VSL, página, quiz, UGC, unboxing, live). Não é argumento, ângulo ou mecanismo. Base 06.
10. **Ad** — unidade de entrada e teste de atenção/qualificação. Desmontar por função: interrupção, seleção, tensão, reframe, prova, ponte, CTA. Base 08.
11. **VSL** — roteiro e progressão de crença. Não é o funil inteiro. Blocos: situação → agitação → explicação antiga falha → mecanismo do problema → nova oportunidade → mecanismo da solução → promessa → prova → produto → objeções → condições/risco/CTA. Base 09.
12. **Prova** — elemento usado pela copy para sustentar uma afirmação (depoimento, autoridade, demonstração, história, referência). Não é validação independente. Hierarquia: demonstração > dados próprios com método > caso verificável semelhante > depoimento específico autorizado > credencial > explicação plausível > opinião. Base 11.
13. **Objeção** — resistência, dúvida ou risco percebido que a copy responde. Não é a crença central. Base 16.
14. **Crença** — explicação ou pressuposto que a copy precisa manter, tensionar ou substituir. Não é fato sobre o mercado. Base 16.
15. **Persona** — pessoa ou grupo descrito pela situação e linguagem da oferta (circunstância, comportamento, tensão, evento de mudança). Não é público estatístico. Base 02.
16. **Desejo** — estado ou mudança desejada pela persona na narrativa. Não é promessa validada nem demanda comprovada. Base 15. **Dor** — tensão vivida ou narrada (custo emocional, funcional, social, financeiro).
17. **Produto** — bem, serviço ou entregável recebido. Não é a oferta completa. Base 17.
18. **Oferta** — produto + promessa + mecanismo + prova + preço + redução de risco + condições + CTA (quando observados). Não é produto isolado. Base 07.
19. **Funil** — sequência de páginas, eventos e transições da entrada à ação (Ad → página/quiz/VSL → checkout → acesso → pós-compra). Não é VSL isolada. Só registrar etapas observadas. Base 10.
20. **Modelagem** — reconstrução funcional de princípios transferíveis em outro contexto. Não é copiar frases, identidade, prova ou claim. Manual de Modelagem.
21. **Hipótese** — previsão operacional ainda não confirmada, escrita para ser testada. Não é resultado. Bases 14 e 19.
22. **Test Card** — registro estruturado de uma hipótese e de como será testada (variável, controle, métrica, janela, critério, risco). Não é lista de ideias. Base 14.
23. **Stack** — conjunto de itens apresentados como pacote de valor. Não é prova. Base 18. **Bump** — oferta adicional no checkout. **Upsell** — oferta superior após a decisão principal. **Downsell** — alternativa menor após recusa. Registrar só quando observados.
24. **DNA da oferta** — relação entre as decisões que organizam a venda (persona → problema → mecanismo → nova oportunidade → Big Idea → promessa → prova → produto → oferta → funil), separada da superfície proprietária.
25. **Princípio transferível** — função que permanece quando se remove nome, headline, personagem, autoridade, números, preço, garantia e visual (ex.: reduzir culpa, tornar problema visível, demonstrar antes de afirmar, simplificar decisão).
26. **Sinal de escala** — repetição de anúncios, longevidade e arquitetura do funil observáveis na Biblioteca. Não comprova faturamento.
27. **Skin** — nome, ritual, personagem ou superfície que torna o sistema memorável. Sem lógica por trás, é só skin.
28. **Estágio de consciência** (Schwartz): inconsciente → consciente do problema → consciente da solução → consciente do produto → muito consciente. Registrar como leitura da comunicação, não rótulo permanente. **Sofisticação**: quais promessas e explicações concorrentes o mercado já viu.
