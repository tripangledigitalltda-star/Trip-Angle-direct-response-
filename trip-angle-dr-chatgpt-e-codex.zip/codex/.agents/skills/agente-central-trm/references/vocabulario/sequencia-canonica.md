# Sequência canônica, portões e checkpoints (Trip Angle)

Fonte: Jornada de Engenharia de Ofertas, Jornada Mestre, Portal Geral do Aluno, Agenda Oficial de Calls (Notion Trip Angle, set/2026).

## 1. As 29 etapas da Jornada de Engenharia de Ofertas

01 Como Ler uma Oferta · 02 Inteligência de Mercado · 03 Persona, Situação e Contexto · 04 Dor, Desejo e Crenças · 05 Soluções Tentadas · 06 Mecanismo do Problema · 07 Mecanismo da Solução · 08 Mecanismo Único · 09 Nova Oportunidade · 10 Big Idea · 11 Ângulo · 12 Promessa · 13 Hook · 14 Lead · 15 Formato · 16 Engenharia do Ad · 17 Prova · 18 Objeções · 19 Engenharia da VSL · 20 Produto · 21 Engenharia da Oferta · 22 Componentes · 23 Engenharia do Funil · 24 DNA da Oferta · 25 Engenharia Reversa · 26 Modelagem · 27 Criação de Nova Oferta · 28 Test Cards · 29 Teste e Aprendizado.

Regra: cada etapa leva a uma definição, uma base técnica, um exemplo real e uma ação. Se faltar informação, NÃO MAPEADO NOS MATERIAIS.

Ações por etapa (rota operacional clicável):
- 02 → 01 Fontes e Evidências + 19 Mapa de Oportunidades → separar fonte, observação e hipótese.
- 03 → 02 Personas → descrever somente a situação apresentada pela copy.
- 04 → 15 Promessas e Desejos + 16 Objeções e Crenças → separar dor observada, desejo declarado e crença pressuposta.
- 05 → 16 → registrar somente tentativas explicitadas.
- 06/07 → 05 Mecanismos → marcar como alegação da copy quando não validado; diferenciar mecanismo alegado de produto.
- 08 → Matriz Mestre → registrar como não confirmado quando for apenas diferenciação percebida.
- 09 → 19 Mapa de Oportunidades → formular o reenquadramento sem inventar mercado.
- 10 → resumir a tese central, não uma frase isolada.
- 11 → 04 Ângulos → distinguir enquadramento de promessa.
- 12 → 15 → qualificar resultados como alegação quando necessário.
- 13 → 03 Hooks → identificar função, não copiar frase.
- 14 → 09 VSLs → separar entrada de desenvolvimento da tese.
- 15 → 06 Formatos → distinguir formato, argumento e canal.
- 16 → 08 Ads → seguir o link do anúncio original e registrar a linhagem.
- 17 → 11 Provas → separar prova alegada de validação independente.
- 18 → 16 → registrar resposta da copy sem assumir eficácia.
- 19 → 09 → separar roteiro de sequência de funil.
- 20 → 17 Produtos → identificar entregável sem confundir com promessa.
- 21 → 07 Ofertas → separar produto, condições, stack, CTA e risco.
- 22 → 18 Componentes → diferenciar componente, bônus, bump, upsell e downsell quando observados.
- 23 → 10 Funis → desenhar somente etapas observadas.
- 24 → Matriz Mestre + Estudo de Caso → preencher o DNA e marcar lacunas.
- 25 → Como Modelar sem Copiar → extrair princípio antes da superfície.
- 26 → escolher uma variável e escrever nova hipótese.
- 27 → Como Criar do Zero → começar por mercado e persona, não por volume de hooks.
- 28 → 14 Test Cards → registrar variável, controle, métrica, janela, critério e risco.
- 29 → registrar resultado real e aprendizado; sem dados, manter como hipótese.

## 2. Jornada Mestre — 6 fases e 47 dimensões

- FASE 01 Inteligência de Mercado: 1 Mercado · 2 Persona · 3 Situação e Contexto · 4 Problema · 5 Dor · 6 Desejo · 7 Crenças · 8 Soluções Tentadas.
- FASE 02 Engenharia da Oportunidade: 9 Mecanismo do Problema · 10 Mecanismo da Solução · 11 Mecanismo Único · 12 Nova Oportunidade · 13 Big Idea.
- FASE 03 Engenharia da Mensagem: 14 Ângulo · 15 Promessa · 16 Hook · 17 Lead · 18 Formato · 19 Engenharia do Ad · 20 Prova · 21 Objeção.
- FASE 04 Engenharia da Venda: 22 Engenharia da VSL · 23 Progressão de Crença · 24 Produto · 25 Engenharia da Oferta · 26 Componentes · 27 Stack · 28 Garantia · 29 Condições.
- FASE 05 Engenharia do Funil: 30 Jornada · 31 Presell/Advertorial/Quiz · 32 VSL/Página · 33 Checkout · 34 Bump · 35 Upsell · 36 Downsell · 37 Pós-compra.
- FASE 06 Modelagem, Teste e Aprendizado: 38 DNA · 39 Engenharia Reversa · 40 Modelagem · 41 Nova Hipótese · 42 Test Cards · 43 Teste · 44 Leitura dos Resultados · 45 Iteração · 46 Aprendizado.

Checkpoints mestre (critério de passagem):
1. ENTENDER — define o conceito, diz com o que não confundir, aponta anterior e seguinte. Saída: definição + distinção + link ao conceito.
2. IDENTIFICAR — encontra o conceito em peça real e registra trecho, fonte, formato, função com classificação de evidência.
3. VER NO ORIGINAL — abre o Ad/VSL/página; se a fonte não existir, registra lacuna, não cria abertura plausível.
4. DECOMPOR — separa pessoa, situação, dor, desejo, crença, problema, solução, mecanismo único, skin, prova, produto, oferta, funil.
5. COMPARAR — compara duas ofertas por função, não por vocabulário: tese comum, tese específica, skin que não se copia, classificação da Big Idea, limite de evidência.
6. MODELAR — referência → DNA → princípio → variável → hipótese → reconstrução, com persona, história, mecanismo, prova, produto e oferta próprios.
7. TESTAR — Test Card com variável isolada, controle, métrica, amostra, janela e critério antes da execução.

Porta de retorno: falhou em Entender → volta ao conceito; em Identificar/Ver no Original → Estudo de Caso; em Decompor/Comparar → Matriz Mestre; em Modelar → Laboratório; em Testar → Test Card antes de nova variação.

## 3. Rota do projeto (Portal Geral do Aluno) — 7 etapas e checkpoints

| Etapa | Objetivo | Entregável | Checkpoint para avançar |
|---|---|---|---|
| 01 Fundamento e direção | definir o projeto único | Briefing do Projeto + um modelo de negócio | explica o que vende, para quem, qual problema, qual resultado |
| 02 Mercado, oportunidade e público | substituir achismo por leitura | mapa com mercado, público, dores, desejos, concorrentes, ofertas, oportunidade escolhida | existe evidência de demanda e justificativa para testar |
| 03 Oferta e proposta de valor | razão clara para comprar | Card da Oferta (público, problema, resultado, promessa, mecanismo, produto, entregáveis, bônus, preço, garantia, provas, objeções) | oferta específica, compreensível, defensável, sem frases genéricas |
| 04 Copy, ângulos e criativos | comunicação que gera atenção e ação | 3 ângulos, 3 hooks por ângulo, ≥3 criativos | cada criativo comunica público, dor/desejo, mecanismo e próxima ação |
| 05 Funil e conversão | caminho entre atenção e compra | mapa do funil: anúncio, página/quiz, checkout, oferta adicional, pós-compra | links, páginas, preços, pixels e ações conferidos de ponta a ponta |
| 06 Tráfego e lançamento | hipótese diante do mercado com teste controlado | Plano do Teste: hipótese, público, criativos, orçamento, duração, métricas, limite de perda, critério manter/alterar/encerrar | campanha publicada, rastreamento conferido, critérios registrados antes do resultado |
| 07 Tracking, análise e refinamento | dados viram decisão | Test Card concluído: hipótese, variável, período, investimento, dados, interpretação, decisão, próximo teste | sabe o que manter, alterar e qual nova hipótese testar |

Plano de 30 dias: dias 1–7 briefing/mercado/público; 8–14 oferta; 15–21 copy, criativos, funil, tracking; 22–30 lançamento, dados, refinamento.

Rota por situação: começando do zero → Etapa 01; tem ideia sem oferta → 02; tem oferta e não vende → 03 + diagnóstico; vende e quer conversão → 04–05; vende e quer escalar → 06–07.

## 4. Portões do programa (Agenda de Calls) — P1 a P8

| Portão | Calls | Saída obrigatória | Não avança quando |
|---|---|---|---|
| P1 Direção | 01 | Briefing e projeto único | tenta executar vários projetos |
| P2 Mercado | 02–03 | Dossiê de mercado e pessoa em situação | opinião sem fonte ou persona genérica |
| P3 Leitura | 04–05 | DNA da oferta e tese estratégica | observação, interpretação e hipótese misturadas |
| P4 Modelagem e oferta | 06–07 | Nova hipótese, Offer Card, produto e prova | cópia, claim sem prova ou produto incompatível |
| P5 Mensagem e venda | 08–09 | Matriz de mensagem, ativo e funil | copy não conduz à mesma promessa e entrega |
| P6 Criativo | 10 | Creative Card, roteiro, QA e Test Card | peça bonita sem hipótese |
| P7 Teste e escala | 11–12 | Tracking, plano de teste e decisão | sem economia, medição ou limite de perda |
| P8 Aprendizado | 13 | Dossiê final e próximo ciclo | resultado não convertido em aprendizado |

Status padronizados: AVANÇA / REVISA / RETORNA / BLOQUEADO (claim, originalidade, tracking, economia ou entrega impedem) / CONCLUÍDO.

Antes de pedir ajuda (hot seat): projeto e versão, etapa atual, entregável produzido, evidência observada, decisão a tomar, pergunta específica.

## 5. Sprint de 14 dias (módulo 03 Engenharia)

1–2 Resumo estratégico + padrões · 3 Estágio de consciência + ponte · 4–5 Offer Card + provas + riscos · 6–7 Briefing + estrutura de copy · 8–9 Roteiro de página/VSL/conversa · 10 Mapa do funil + QA · 11–12 Scripts, matriz de objeções, follow-up · 13 Claims, limites e correções · 14 Test Card + briefings 04/05.
