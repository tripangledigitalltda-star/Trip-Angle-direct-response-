# Test Card — modelo e regras da casa

Teste transforma hipótese em comparação executável. Exige variável isolada, controle, canal, audiência, destino, janela, amostra, métrica primária/secundária, critério de vitória, critério de descarte, resultado e aprendizado separados. Sem janela ou métrica há intenção de teste, não teste.

## Template (preencher antes de publicar)

- Nome do teste (ID: `<OFERTA>-TC0n — <o que compara>`)
- Oferta e versão
- Hipótese: "Se eu mudar X mantendo Y, espero Z porque…" (específica, rastreável à observação, limitada ao contexto, falsificável, compatível com o produto, proporcional à prova, separada de promessa pública)
- Evidência que originou a hipótese (fonte, ID, linhas)
- O que estamos testando (uma variável): segmento · situação · promessa · mecanismo · ângulo · hook · lead · prova · preço · garantia · formato · página/destino · criativo · CTA · sequência
- Variação A / Variação B / (C somente se definida)
- Controle: versão original observada, mantendo oferta, formato, CTA, destino e condições constantes. Sem controle real, registrar a limitação antes do teste.
- O que não pode mudar: oferta, público, destino, condições, período, critério de medição
- Persona · Audiência · Canal (mesmo canal e posicionamento nos braços) · Destino (idêntico nos braços)
- Orçamento · Limite de perda
- Amostra planejada: dois braços A/B; mínimo de 100 cliques por braço e distribuição equivalente de tráfego. Não iniciar se a amostra ficar desequilibrada.
- Janela: 7 dias de tráfego simultâneo, ou até ambos os braços atingirem a amostra mínima, o que ocorrer por último.
- Métrica principal (definir antes: CTR qualificado, retenção, avanço, conversão, CPA)
- Métricas secundárias: retenção inicial, CPC, avanço para a próxima etapa, conversão observada, sinais de reclamação/compliance
- Critério de vitória: declarar vencedor somente se uma variação superar o controle em pelo menos 20% na métrica principal predefinida, sem piora superior a 10% nas secundárias e sem novo risco de compliance. Sem dados, não há vencedor.
- Critério de descarte: descartar somente por falha de rastreamento, violação de integridade da fonte, erro de entrega ou desequilíbrio de amostra; não por impressão subjetiva.
- Critério para manter / alterar / encerrar
- Risco / claim revisado (12 — Claims e Risco)
- Prova necessária
- Confiabilidade: Nível D — Hipótese (até haver dados)
- Status: Rascunho / Pronto / Em execução / Concluído
- Resultado (observado) · Interpretação (separada) · Decisão · Aprendizado · Próximo teste

## Métricas por camada (leitura correta)
- Atenção: retenção inicial, hook rate, impressão qualificada.
- Clique: CTR e CPC, sempre com o objetivo.
- Ativo: avanço por seção, lead, formulário, conversão, abandono.
- Checkout: início, abandono, compra.
- Venda (consultivo): comparecimento, qualificação, avanço, fechamento, ciclo.
- Economia: CPA/CAC, receita líquida, margem, ticket, reembolso.
- Entrega: ativação, uso, conclusão, satisfação, suporte, retenção.

CTR baixo não prova produto ruim; conversão baixa não prova falta de urgência; fechamento baixo não prova vendedor fraco. Localize a etapa, colete evidência, formule a próxima hipótese. "A versão B vendeu mais nesta janela" é observação; "vendeu mais por causa do mecanismo" é interpretação que pode exigir novo teste.

## Escada de evidência (o que cada sinal indica)
0 opinião/elogio → 1 atenção e clique → 2 lead ou resposta → 3 início de checkout/aplicação → 4 pagamento → 5 uso e conclusão → 6 recompra, retenção ou indicação. Uma venda isolada não prova escala, margem ou retenção.

## Erros que invalidam o teste
Mudar muitas coisas; parar cedo; ignorar amostra; escolher métrica depois; tratar correlação como causalidade; declarar vitória por um resultado; esconder inconclusividade; chamar backlog de experimento executado ou hipótese de aprendizado.
