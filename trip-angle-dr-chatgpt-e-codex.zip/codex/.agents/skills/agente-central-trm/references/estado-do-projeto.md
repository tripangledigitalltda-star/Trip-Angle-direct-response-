# Estado do projeto

## Estrutura de pastas
```
projetos/<projeto>/
├── estado.json          controle das etapas (gerado pelo script)
├── ESTADO.md            resumo legível (gerado pelo script)
├── 01-espionagem/
├── 02-ads/
├── 03-copy/
├── 04-funil/
├── 05-producao-criativos/
├── 06-compliance/
├── 07-trafego/
├── 08-backend-cro/
├── 09-produto/
└── handoffs/            um arquivo por handoff: AAAAMMDD-HHMM__<etapa>.md
```
Nome do projeto: `pais-oferta` em minúsculas e hífens, por exemplo `br-mounjaro-natural`.

## Campos do estado
Projeto · oferta · país · nicho · criado em · atualizado em · etapas (status: pendente, em andamento, concluída, pulada, manual; data; agente; último handoff; portão de aprovação) · aprovações pendentes · bloqueios · próxima ação única · histórico de decisões.

## Regras
- Só o AGENTE CENTRAL altera `estado.json`, via script.
- Uma etapa só vira "concluída" com handoff registrado e portão de aprovação preenchido.
- Aprovação pendente de publicar, gastar, precificar ou prometer aparece no topo do status até ser resolvida.
