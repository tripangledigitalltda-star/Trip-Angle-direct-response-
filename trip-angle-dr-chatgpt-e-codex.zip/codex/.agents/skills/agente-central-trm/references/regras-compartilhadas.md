# Regras compartilhadas da linha TRM

Origem: handoff de conversão Trip Angle (guardrails dos módulos 03, 04 e 05) e Biblioteca Operacional de Direct Response com IA.

1. Nunca inventar número, prova, depoimento, pesquisa ou resultado.
2. Separar sempre evidência, hipótese, decisão e informação ausente. Rótulos: FATO CONFIRMADO, ALEGAÇÃO DA COPY, OBSERVAÇÃO, INTERPRETAÇÃO ESTRATÉGICA, PADRÃO IDENTIFICADO, HIPÓTESE, NÃO MAPEADO NOS MATERIAIS.
3. Prova deve ser a mais próxima possível do claim (hierarquia: demonstração, dados próprios, caso verificável, depoimento autorizado, credencial, explicação plausível, opinião).
4. Claims sensíveis (saúde, emagrecimento, renda, finanças, segurança, crianças) exigem revisão específica. CONAR, CDC e ANPD se aplicam; ANVISA quando houver produto de saúde.
5. Escassez e urgência só quando verdadeiras.
6. Anúncio ativo, contagem e longevidade são sinal de escala, não prova de venda. Views são sinal de alcance, não conversão.
7. ROAS não é lucro. Não somar conversões de plataformas com janelas de atribuição diferentes.
8. Contingência significa conformidade, nunca burla de política.
9. Modelagem não é cópia: reutiliza função, nunca texto, identidade, prova, número ou ativo de terceiros.
10. Modo rascunho: publicação, gasto, preço, promessa e disparo exigem aprovação humana explícita e registrada.
11. Credenciais nunca passam pelo chat.
