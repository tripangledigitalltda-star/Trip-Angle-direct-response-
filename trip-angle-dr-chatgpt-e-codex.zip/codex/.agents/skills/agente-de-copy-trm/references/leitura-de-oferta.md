# Leitura de oferta do zero (origem: skill agente-de-copy-trm (leitura-de-oferta.md), consolidada em 13/09/2026)

# Como ler uma oferta do zero (Modo 02 — Analisar)

Leitura de oferta é engenharia reversa, não opinião. O objetivo é reconstruir o sistema que conecta uma pessoa em uma situação, uma explicação do problema, uma oportunidade, uma promessa, uma prova, um produto, condições comerciais e um caminho de compra. Você procura relações, funções, limites e hipóteses, não frases para copiar. O entregável é uma Ficha de Leitura que outra pessoa consiga auditar voltando da interpretação até o trecho original.

Entradas obrigatórias: peça original (anúncio, página, quiz, VSL, checkout), URL, anunciante, país e data da captura, transcrição e capturas. Saídas: Ficha de Fonte e Linhagem · Mapa Estratégico · Matriz Claim → Prova → Limite · Mapa de Ads, VSL, Oferta e Funil · DNA, princípio transferível e próxima hipótese. Templates em `leitura-fichas.md`.

## Leitura rápida em dois minutos (antes de tudo)
O que é vendido? Quem é chamado? Que situação abre a conversa? Que problema e desejo aparecem? Que resultado é prometido? Que mecanismo é apresentado? Que prova? Que ação? Para onde o anúncio leva? Resumo de uma linha: "Para [pessoa em situação], a oferta apresenta [produto] como meio de alcançar [progresso], porque [mecanismo], sustentado por [prova observada], mediante [condições]." Se não dá para preencher sem inventar, a captura está incompleta.

## As cinco passagens (uma camada por vez, nunca tudo na primeira visualização)

**1 — Fonte.** Consuma a peça inteira sem pausar; na segunda vez transcreva e marque blocos; capture os pontos decisivos; desenhe a sequência sem nomear frameworks; registre lacunas como NÃO MAPEADO. Entrega: linhagem, transcrição, lacunas.

**2 — Demanda.** Persona situada (circunstância, comportamento, tensão, evento de mudança; o que tentou; o que empurra e o que atrai; que ansiedade impede; que hábito mantém; comprador = usuário?). Separe situação / problema / dor / desejo / crença / solução tentada. Classifique o estágio de consciência que a peça pressupõe (inconsciente → problema → solução → produto → mais consciente) como leitura da comunicação.

**3 — Tese.** Mecanismo do problema: "A copy afirma que o problema persiste não apenas por [explicação comum], mas porque [causa proposta]." Mecanismo da solução: "A solução produziria progresso porque [processo] atua sobre [causa] por meio de [entrega]." Separe mecanismo, método, produto e nome proprietário: se retirar o nome elegante e não restar lógica, é só skin. Nova oportunidade: "Talvez o caminho não seja [velha solução], mas [nova categoria/abordagem]." Big Idea: resuma a tese sem headline, nome, personagem ou bordão; se o resumo desaparece, você capturou superfície. Depois ângulo, promessa, hook (que pergunta o próximo bloco responde?) e lead (que crença é trabalhada?).

**4 — Persuasão.** Engenharia do anúncio por função: interrupção → seleção → tensão → reframe → prova → ponte → CTA (registre também imagem, ritmo, personagem, áudio, legenda, placement, duração, destino). Formato não é argumento. Progressão da VSL/página em blocos (situação, agitação, explicação antiga, mecanismo do problema, nova oportunidade, mecanismo da solução, promessa, prova, produto, objeções, condições/risco/CTA); para cada bloco: que crença estabelece e por que o próximo se torna necessário. Matriz Claim → Prova → Limite, incluindo claims implícitos.

**5 — Negócio.** Produto ≠ transformação ≠ oferta ≠ copy ≠ funil. Registre só o que aparece: produto principal, entregáveis, bônus e função de cada um, preço/parcelas/total, ancoragem, garantia e condições, urgência/escassez, CTA, bump/upsell/downsell, suporte, reembolso. Um bônus só fortalece a oferta quando remove obstáculo, reduz tempo/esforço, aumenta confiança ou amplia etapa coerente. Funil: para cada transição (anúncio → quiz/página/VSL → checkout → pós-compra) a ação solicitada, a expectativa criada e o dado necessário. Teste de congruência: anúncio, destino, checkout e produto sustentam a mesma promessa e condições.

## DNA e princípio transferível
Remova nome e marca, headline e frases, personagem e história, autoridade e depoimentos, números/preço/garantia, mecanismo proprietário e visual. O que permanece é a função (reduzir culpa, tornar problema visível, demonstrar antes de afirmar, simplificar decisão, aumentar confiança, diminuir esforço percebido). Pode inspirar hipótese: função psicológica e ordem dos argumentos, tipo de demonstração, relação problema-mecanismo-solução, pergunta de teste, função de uma etapa do funil. Não deve ser copiado: frases, scripts, nomes, bordões, prova de terceiros, claim sem base, identidade, preço/escassez/garantia não verdadeiros. Feche com uma hipótese própria e uma variável para Test Card.

## Roteiro operacional (A–E)
A Fonte e contexto · B Demanda · C Tese · D Persuasão · E Oferta e extração — lista completa em `leitura-fichas.md`. Cadeia: ORIGINAL → OBSERVAÇÃO → INTERPRETAÇÃO → DNA → PRINCÍPIO → HIPÓTESE → TEST CARD → RESULTADO.

## Rubrica de qualidade (0 ausente, 1 parcial, 2 completo)
Fonte e linhagem · Persona e situação · Problema, dor, desejo, crenças · Mecanismos · Big Idea, ângulo, promessa · Hook, lead, formato, progressão · Prova, objeções, claims, limites · Produto, oferta, condições · Funil e congruência · DNA, princípio, hipótese. Pronto para modelar: 16/20 sem zero em Fonte, Claims, Produto/Oferta ou Princípio.

## Erros que invalidam a leitura
Começar pelo hook e ignorar a situação de compra; confundir anúncio ativo com oferta lucrativa; preencher lacunas com estruturas de livros; chamar nome proprietário de mecanismo; confundir Big Idea, ângulo, promessa e headline; tratar depoimento como prova universal; ignorar claims implícitos; confundir produto, oferta, copy, VSL e funil; copiar frase, personagem, prova, preço, escassez ou identidade; modelar antes de concluir a observação; mudar várias dimensões na hipótese; não registrar versão, fonte e data.

## Formato de entrega
Ficha de Leitura em tabelas (Elemento | Leitura auditada | Rótulo de evidência | Trecho/fonte), seguida de Equação estratégica, Progressão de crença em 7 passos, Claim → Prova → Limite, Mapa do funil, DNA/princípio/não transferível, hipótese e variável de Test Card, lacunas e riscos. Indique a base técnica de destino de cada registro.
