# Base de Desejos, Segmentação e Swipes — Referência Operacional

Destilado de três fontes para uso em copy e modelagem de oferta: Drew Eric Whitman
(*Cashvertising*), Ryan Levesque (*Ask*) e Dan Kennedy (*Swipe Titans*). Escrito com as
próprias palavras do operador; citações literais são raras e sinalizadas.

## 1. Cashvertising — desejos e gatilhos psicológicos

### 1.1 Life-Force 8 (LF8) — desejos primários (biológicos, não aprendidos)

| # | Desejo | Aplicação em uma linha |
|---|---|---|
| 1 | Sobrevivência, prazer e prolongamento da vida | Use como base de qualquer promessa de saúde, segurança ou longevidade — é o desejo mais forte, ancore nele antes de qualquer secundário. |
| 2 | Prazer com comida e bebida | Em ofertas de alimentação/emagrecimento, venda o prazer sensorial do alimento, não só a restrição. |
| 3 | Liberdade do medo, dor e perigo | Nomeie o medo específico do nicho e prometa a remoção dele, não uma vaga "tranquilidade". |
| 4 | Companhia sexual / atração | Use em ofertas de estética, relacionamento e autoestima como benefício final, não como gancho vulgar. |
| 5 | Condições de vida confortáveis | Venda a redução de fricção e desconforto do dia a dia (tempo, dinheiro, esforço). |
| 6 | Ser superior, vencer, superar os vizinhos | Funciona em ofertas de status, dinheiro e performance — comparação social implícita vende. |
| 7 | Cuidado e proteção de quem se ama | Muito forte em ofertas de saúde e finanças familiares — o comprador age para proteger terceiros. |
| 8 | Aprovação social | Use prova social e transformação visível para quem "os outros vão notar". |

### 1.2 Desejos secundários (aprendidos) — reforçam, não substituem o LF8

Estar informado; curiosidade; higiene do corpo e do ambiente; eficiência; conveniência;
confiabilidade/qualidade; expressão de beleza e estilo; economia/vantagem; pechincha.
**[aplicação]** use-os em bullets e objeções, nunca como promessa central — eles não têm
tração biológica.

### 1.3 Princípios e técnicas de copy (seleção com aplicação)

- **Fator medo** — nomeie o pior cenário antes de oferecer a saída. [aplicação]
- **Transformação de ego** — deixe o leitor se identificar com quem ele quer ser, não quem é hoje.
- **Transferência (credibilidade por associação)** — empreste autoridade de uma fonte já confiável (especialista, mídia, instituição).
- **Efeito carona (bandwagon)** — mostre volume de gente já comprando/agindo para reduzir o risco percebido de ser o primeiro.
- **Cadeia meios-fins** — conecte o atributo do produto ao benefício final que o LF8 realmente quer, em 2-3 passos explícitos.
- **6 armas de influência (Cialdini)** — reciprocidade, compromisso, prova social, autoridade, afeição, escassez: escolha 2 por peça, não as seis juntas.
- **Exemplos vs. estatística** — histórias específicas convencem mais que números frios; use números para sustentar a história, não substituí-la.
- **Perguntas retóricas** — force concordância silenciosa antes do pedido de ação.
- **Repetição e redundância** — repita a promessa central em 3+ pontos da peça com palavras diferentes.
- **Heurísticas (atalhos mentais)** — preço "ancorado", "mais vendido", "recomendado por" poupam o leitor de pensar — use com honestidade.
- **Bombardeio de benefícios** — liste benefícios em profusão antes de qualquer detalhe técnico.
- **Maior benefício no título** — nunca enterre a melhor promessa no meio do texto.
- **Aumento de escassez** — escassez real (unidades, vagas, prazo) supera qualquer adjetivo de urgência.
- **Especificidade extrema** — números exatos ("37 dias", "R$ 214,90") são mais cridos que "rápido" ou "barato".
- **Prova social** — depoimento com nome, contexto e resultado específico vale mais que nota genérica de estrelas.
- **PVA (linguagem visual positiva)** — escreva para instalar um "filme mental" do uso do produto, com verbos de ação e detalhes sensoriais.
- **Direção de filmes mentais** — descreva a cena do resultado (onde, o quê, como se sente) em vez de afirmar o benefício de forma abstrata.
- **Combater a inércia** — dê um primeiro passo tão pequeno que recusar pareça mais custoso que aceitar.
- **USP (proposta única de venda)** — defina o que só a sua oferta entrega e repita como coluna vertebral da peça.
- **Psicologia do preço** — preço quebrado, parcelamento e comparação com alternativa mais cara mudam a percepção de valor.
- **"Cleverectomia"** — corte qualquer trocadilho ou criatividade que atrapalhe o entendimento imediato da oferta.

Fonte: Drew Eric Whitman, *Cashvertising* (ed. espanhola), cap. 1 "Lo que la gente
realmente quiere" (LF8 e desejos secundários, p. 20-23), cap. 2 "17 principios
fundamentales" (p. 29+), cap. 3 "41 técnicas" (p. 79+) e cap. 4 "101 maneiras" (p. 187+).
Citação literal: "Los llamo Life-Force 8 (LF8 para abreviar)" (Whitman, *Cashvertising*, p. 21).

## 2. Ask (Ryan Levesque) — pesquisa de público e segmentação

Framework do livro (cap. 12, "The Process"): **Prepare → Persuade → Segment → Prescribe
→ Profit → Pivot**, apoiado em quatro pesquisas sequenciais (a "Survey Funnel Strategy"):

1. **Deep Dive Survey** (Prepare) — pesquisa aberta enviada à lista ou captada em landing
   page de tráfego frio. Uma única pergunta central: *"What's your #1 single biggest
   marketing challenge right now?"* (Levesque, *Ask*, cap. 13, p. 80) — adaptar para "qual
   é o seu maior desafio/frustração com [tema]" sempre em formato aberto. Não ofereça
   incentivo genérico (sorteio, brinde caro): isso atrai respondente errado e polui a
   linguagem coletada. O objetivo é capturar a linguagem natural do cliente, não validar uma hipótese.
2. **Prospect Self-Discovery Landing Page** (Persuade) — página simples com a pergunta
   aberta como isca, sem formulário longo; a promessa é ajudar o próprio respondente a
   entender seu problema (o "ethical bribe" pode ser um relatório/kit gratuito ligado ao tema).
3. **Micro-Commitment Bucket Survey** (Segment) — depois da Deep Dive, monta-se um quiz de
   múltipla escolha que começa com uma pergunta binária de baixíssimo atrito (A/B, não
   ameaçadora) antes de pedir e-mail ou dados sensíveis — a lógica é criar "momentum de
   compromisso" com decisões pequenas e sucessivas. As respostas classificam o respondente
   em "buckets" (segmentos), que passam a receber mensagem, oferta e produto diferentes.
4. **"Do You Hate Me?" Survey** — enviada a quem não comprou, pergunta direta pelo maior
   motivo de não ter comprado; usada para corrigir objeções na copy e na oferta.
5. **Pivot** — sequência de e-mail de acompanhamento que realimenta o ciclo com o
   comportamento observado.

**Como transformar respostas em copy e segmentação de oferta:**
- As frases literais mais repetidas na Deep Dive viram manchete, subtítulos e bullets — é a
  linguagem do próprio cliente, não a do redator. [aplicação]
- Os motivos mais frequentes de "maior desafio" definem os buckets; cada bucket recebe uma
  landing page, e-mail ou oferta de upsell prescrita para ele (etapa "Prescribe"). [aplicação]
- Perguntas de "personalização" (idade, tipo de negócio, estágio) alimentam campos de
  mesclagem (merge fields) para e-mail e VSL personalizados por segmento.
- O "Do You Hate Me" survey vira checklist de objeções a antecipar na página de vendas e no
  script de criativo. [aplicação]

Fonte: Ryan Levesque, *Ask* (Dunham Books, 2015), Parte II — cap. 12 "The Process", cap.
13 "Prepare: The Deep Dive Survey", cap. 14 "Persuade: The Prospect Self-Discovery
Landing Page", cap. 15 "Segment: The Micro-Commitment Bucket Survey" (PDF sem texto
extraível; lido via renderização de página, cap. 12-15).

## 3. Swipe Titans (Dan Kennedy) — padrões estruturais recorrentes

Amostragem de cartas e anúncios comentados no arquivo (não reproduzidos, apenas
estrutura descrita):

| Elemento | Padrão observado | Aplicação em uma linha |
|---|---|---|
| Abertura por dor nomeada | Carta do "Giorgio" (jantar romântico): título com imagem, endereçada diretamente ao marido, problema do casamento nomeado na 1ª linha. | Nomeie a dor do leitor específico na primeira frase, antes de qualquer credencial. |
| Abertura por metáfora estendida | Promoção de evento usa metáfora de "circo" (picadeiro, atrações) para organizar toda a oferta. | Uma metáfora única sustentada do início ao fim organiza ofertas com muitos componentes. |
| Abertura por alerta/ameaça | Carta B2B a CFOs de hospital abre com "WARNING" e metáfora de tempestade/maré. | Em B2B ou temas de risco, o alerta direto supera a curiosidade suave como gancho. |
| Uso de história | Carta de confirmação de evento usa a história pessoal do fundador como diferenciação, evitando o clichê "do zero ao topo" quando não é verdade. | Conte a história real, mesmo que não seja de superação — autenticidade pesa mais que arquétipo. |
| Prova | Caso de sucesso nomeado (nome, cidade, investimento e retorno exatos: "US$74,12 geraram US$4.812"). | Prova forte é nominal e numérica, nunca genérica ("muita gente aprovou"). |
| Oferta | Segunda carta de reativação ao mesmo prospect soma um novo incentivo (limusine) sem tirar o anterior. | Ao reabordar quem não comprou, acrescente valor à oferta original em vez de só descontar o preço. |
| Garantia | Garantia de até o triplo do valor de volta, condicionada a "abertura de mente", não a resultado místico. | Garantias fortes reduzem risco percebido sem prometer o impossível — condicione ao esforço mínimo do comprador. |
| Prazo | Desconto por data-limite explícita + tabela de vagas limitadas justificada (capacidade real do evento). | Combine prazo de preço com limite de vagas apenas quando ambos forem reais — a dupla urgência funciona porque é verdadeira. |
| P.S. em camadas | Carta de inscrição de seminário usa P.S. #1, #2 e #3, cada um somando um motivo novo (palestrante extra, garantia, objeção). | Use múltiplos P.S. para empilhar razões independentes de agir, não para repetir a mesma. |
| "Reason why" | Preço e prazo do bônus sempre justificados ("por isso o desconto expira em tal data"). | Toda condição especial de oferta precisa de uma razão explícita — nunca "porque sim". |
| Sequência de concordância | Comentário do autor: mapear, de trás para frente, cada concordância que o leitor precisa dar antes da compra, e escrever nessa ordem. | Antes de redigir, liste as objeções/crenças que precisam cair uma a uma até a venda, e siga essa ordem no texto. |
| Extremos emocionais e autoidentificação | Comentário do autor: boa copy de resposta direta usa extremos (porque é preciso força para vencer hábito) e manchetes de autoidentificação ("se você é..."). | Escreva manchetes que filtrem o leitor certo por identidade/papel, não só por interesse no tema. |

Citação literal: "Great direct-response copy takes people into dark (emotional) places
then provides relief by purchase." (Dan Kennedy, *Swipe Titans*, p. 44).

Fonte: Dan Kennedy, *Swipe Titans* (GKIC/Kennedy Inner Circle, resource book), cartas
"Giorgio's Italian Grotto" (cap. 12 do *Ultimate Sales Letter*, p. 138-141), "The SECRET
Psychology of Direct-Response" (p. 44), carta de confirmação Phill Grove (p. 206-207),
carta CFO hospitalar (p. 111-112), carta de inscrição de seminário (p. 263-266).

## 4. Mapa desejo → dor → promessa → prova **[aplicação]**

Síntese própria, cruzando LF8 (Cashvertising), linguagem de pesquisa (Ask) e prova
nominal (Swipe Titans). Use como template ao construir persona de oferta:

| Desejo (LF8/secundário) | Dor / tensão (o que a falta dele produz) | Promessa (transformação vendida) | Prova exigida |
|---|---|---|---|
| Condições de vida confortáveis | Cansaço, falta de tempo, sobrecarga diária | "Resolva X em [tempo curto] sem mudar sua rotina" | Depoimento nominal com contexto de rotina real |
| Ser superior / aprovação social | Comparação com pares, medo de ficar para trás | "Alcance [resultado visível] antes de [prazo/evento]" | Antes/depois verificável, nome e contexto |
| Liberdade do medo/dor | Ansiedade com um risco específico (saúde, dinheiro) | "Elimine [risco nomeado] com [mecanismo]" | Fonte de autoridade + mecanismo explicado, não só afirmado |
| Cuidado com quem se ama | Culpa por não proteger terceiros | "Proteja [pessoa/família] de [ameaça]" | Caso real de terceiro protegido, nunca hipotético |

Preencha as colunas com a linguagem literal coletada na Deep Dive Survey (seção 2), não
com adjetivos do redator — é o que garante que a promessa bate no desejo certo.

Fonte: síntese do operador a partir das seções 1-3 deste documento.

## 5. Checklist para intensificar desejo sem inventar prova **[aplicação]**

1. Ancore a promessa central em um LF8 explícito, não apenas em desejo secundário.
2. Escreva com linguagem visual específica (PVA) para instalar o "filme mental" do resultado.
3. Nomeie a dor com as palavras exatas do cliente, coletadas em pesquisa (Deep Dive/comentários), não em jargão de nicho.
4. Coloque o maior benefício no título ou nos primeiros segundos, nunca enterrado no meio.
5. Reduza a distância entre desejo e ação com um próximo passo de baixíssimo atrito (micro-compromisso).
6. Use perguntas retóricas para gerar concordância silenciosa antes de pedir a ação.
7. Mapeie a sequência de concordâncias necessárias e escreva a copy nessa ordem, de trás para frente.
8. Intensifique com contraste antes/depois real (o que muda na rotina), sem inflar números.
9. Use manchetes de autoidentificação ("se você é...") para qualificar o leitor certo.
10. Explique sempre o motivo ("reason why") do preço, do prazo e do bônus.
11. Reforce com prova social nominal já existente — nunca fabrique depoimento ou estatística.
12. Feche com P.S. que reforce o maior desejo e uma urgência real, nunca escassez falsa.
