# Base de Oferta e Mecanismo — Hormozi, Carneiro e Kennedy

Referência operacional para modelar oferta, mecanismo e carta de vendas. Use junto com a metodologia Trip Angle (mineração → leitura → modelagem → criação).

> **Aviso de fonte:** o arquivo `hormozi-100m-offers.txt` fornecido está corrompido (texto embaralhado, sem nenhuma ocorrência real dos termos "value equation", "grand slam", "dream outcome", "guarantee", "scarcity" etc. — é lixo de OCR/anti-pirataria, não o livro). A seção 1 foi escrita com conhecimento consolidado do conteúdo público do livro $100M Offers, sem citação literal e sem número de página verificável. Trate como paráfrase de alta confiança, não como transcrição.

## 1. Hormozi — $100M Offers

### 1.1 Equação de Valor (4 variáveis)

| Variável | O que é | Como mexer para cima |
|---|---|---|
| Resultado dos sonhos | O estado final que o cliente quer (não a feature) | Aumente a ambição da promessa; venda o resultado, não o processo |
| Probabilidade percebida de sucesso | Quanto o lead acredita que VAI dar certo pra ele | Prova (depoimento, case, número), garantia, autoridade, demonstração |
| Tempo até o resultado | Distância entre comprar e sentir o benefício | Quick wins, resultado parcial rápido, entrega imediata de uma parte |
| Esforço e sacrifício percebidos | Trabalho, dinheiro, dor, mudança de hábito exigidos | Simplifique passos, remova decisões, entregue "feito para você" |

Regra prática: valor sobe quando o numerador (resultado × probabilidade) cresce e o denominador (tempo × esforço) encolhe. Toda melhoria de oferta é, no fundo, mexer em uma dessas quatro alavancas. [aplicação: ao auditar uma oferta minerada, classifique cada elemento novo do concorrente em qual das 4 variáveis ele ataca]

### 1.2 Grand Slam Offer — passo a passo

1. **Liste os problemas** que o cliente enfrenta no caminho até o resultado dos sonhos (sequência cronológica, do primeiro obstáculo ao último).
2. **Transforme cada problema em solução** (uma frase de solução para cada problema listado).
3. **Defina o veículo de entrega de cada solução** — o "como" você entrega: cursos, templates, chamadas, software, feito-para-você, comunidade, etc. Para cada veículo, pergunte três coisas: como entregar mais resultado, como entregar mais rápido, como entregar com menos esforço do cliente.
4. **Corte e empacote (trim & stack):** elimine os itens de alto custo/baixo valor percebido para você e mantenha os de alto valor percebido/baixo custo de entrega. O que sobra vira o stack final da oferta.

### 1.3 Mercado e precificação

Critérios de um mercado bom: dor forte e urgente (não capricho), público com poder de compra, fácil de alcançar/segmentar, mercado em crescimento (não encolhendo). Oferta boa em mercado ruim perde para oferta mediana em mercado bom.

Precificação: cobrar mais, não menos, costuma aumentar o resultado do negócio — preço alto financia melhor entrega, atrai cliente mais comprometido e permite garantias mais fortes. O preço deve refletir o valor percebido (equação acima), não o custo de produção. [aplicação: ao modelar, teste preço acima do concorrente principal se a oferta ataca melhor as 4 variáveis]

### 1.4 Melhoria da oferta: escassez, urgência, bônus, garantias, nome

- **Escassez:** limitar quantidade (vagas, unidades, atendimentos). Só vale se a limitação for real — escassez falsa mina a confiança e a garantia (variável 2 da equação) no médio prazo.
- **Urgência:** limitar tempo (prazo de inscrição, turma, preço promocional, bônus por tempo). Mesma regra: só use prazo que você vai cumprir.
- **Bônus:** empacote bônus que resolvem objeções específicas (uma por bônus), nomeie cada um, e apresente o valor somado antes do preço final — o stack de bônus pode valer mais que o produto principal aos olhos do lead.
- **Garantias:** incondicional (devolve por qualquer motivo), condicional (devolve se cumprir X e não funcionar), anti-garantia (declara que não há devolução e explica por quê, usado para qualificar), garantia implícita/de performance (só paga se o resultado acontecer). Escolha a garantia pela variável que mais precisa reforçar: probabilidade percebida.
- **Nomeação da oferta:** nome forte junta avatar + resultado específico + prazo + palavra-recipiente (sistema, método, protocolo, desafio) + gancho de mecanismo. Nome genérico perde no leilão de atenção contra nome específico.

**Fonte:** Alex Hormozi, *$100M Offers* — capítulos "A Equação de Valor", "Como Criar sua Oferta Grand Slam" e "Aumente o Valor Percebido" (conteúdo consolidado; página não verificável — arquivo-fonte corrompido, ver aviso acima).

## 2. Carneiro — Copy e Mecanismo

**O que é mecanismo:** a explicação lógica/técnica que faz a promessa parecer inevitável, não apenas desejável. Carneiro divide o mecanismo em três camadas:

- **Mecanismo do problema:** a causa raiz da dor (não o sintoma). Ex.: não é "estar gordo", é o corpo não produzir hormônio de saciedade.
- **Mecanismo da função:** a ponte lógica — o que precisa acontecer fisiologicamente ou logicamente para resolver a causa raiz.
- **Mecanismo da solução:** o produto/método específico que executa essa função.

**Como construir:** não é invenção, é descoberta e associação. Três caminhos: (1) mineração de hypes atuais — pegar o mecanismo de ação de algo em alta (ex.: hormônios GLP-1/GIP do Ozempic) e associar a um produto próprio; (2) mineração histórica — resgatar mecanismo antigo e esquecido, que soa novo para a audiência atual; (3) pesquisa em ferramentas de tendência (Google Trends, comentários virais de YouTube/TikTok) para achar o ingrediente/termo que vira o mecanismo da solução.

**Erros:** tratar o mecanismo como precisando ser 100% original (trava a criação); usar o mesmo nome de mecanismo que um concorrente que investe mais em mídia — "se for genérico ou igual ao da concorrência, a performance cai" (Carneiro, p.4); construir mecanismo sem prender a um problema validado (que já convertia antes).

**Ligação com promessa e copy:** o mecanismo só funciona colado a uma Big Idea formada por **pergunta paradoxal** (explora uma crença ou preconceito social — ex.: "por que japonesas comem arroz e são magras?") + **nome chiclete** (nome que gruda, usando associações que a audiência já tem). Na estrutura da carta/VSL, o mecanismo é o que resolve o paradoxo e sustenta a promessa contra ceticismo. Na entrega (VSL → CSL), o mecanismo precisa ser vestido de conteúdo que a audiência já consome voluntariamente (vlog, entrevista, podcast), não de discurso de vendas explícito.

**Fonte:** Derick Carneiro, *Copy e Mecanismo* (texto curto, lido integralmente), páginas 1–4.

## 3. Kennedy — The Ultimate Sales Letter

Passos do sistema (lista curta, com aplicação):

1. **Entre na cabeça do cliente** — mapeie o que ele já sabe, teme e quer antes de escrever uma linha.
2. **Entre na oferta** — reformule o produto pelo benefício oculto mais forte, não pela característica óbvia. [aplicação: reescreva o benefício principal da oferta minerada pelo ângulo que o concorrente não usou]
3. **Admissão danosa** — reconheça um defeito real da oferta/nicho antes que o lead pense nisso; isso destrava a credibilidade do resto da carta.
4. **Garanta que a carta seja entregue/aberta** — trate envelope/assunto/thumbnail como parte da copy, não como embalagem.
5. **Prenda a atenção logo no topo** — headline e primeiras linhas decidem se o resto é lido.
6. **Use fórmulas de headline testadas** — "Quem mais quer ___?", "Como ___ me fez ___", "Você é ___?", "Como eu ___", "Como ___" (todas com exemplos no livro, p.43–44).
7. **Vença a objeção de preço** — empacote em partes (cada parte com valor individual somando mais que o preço total) ou oculte o preço fracionando em parcelas pequenas (p.55–56).
8. **Responda objeções abertamente** — liste as razões reais para não comprar e rebata cada uma com resposta direta + prova + reforço da garantia (p.101).
9. **Provoque ação imediata** — combine gatilhos reais: disponibilidade limitada, bônus por tempo, sorteio/concurso com prazo, e facilite ao máximo o ato de responder (telefone grátis, link direto) (p.103–110).
10. **Escreva um P.S. de peso** — o P.S. funciona como uma segunda headline para quem pula direto ao fim da carta; resuma oferta + urgência ali (p.111).

**Oferta irresistível:** empilhar partes com valor individual declarado até a soma superar visivelmente o preço pedido (exemplo do livro: pacote de seminários + kit de marketing + clube de conteúdo mensal somando "valor duro" declarado, vendido por fração disso).

**Garantia:** usada no livro como resposta-padrão dentro do bloco de objeções — sempre que o lead hesita, a carta reafirma a garantia/teste grátis como redutor de risco.

**P.S.:** nunca finalize uma carta sem P.S.; ele existe porque muita gente pula direto para o fim — cite a citação do próprio Kennedy: "The P.S. can make or break your letter!" (Kennedy, p.111).

**Urgência:** "Your letter's job is to get the reader to respond right now." (Kennedy, p.104) — os gatilhos citados no livro incluem disponibilidade limitada, prêmios/bônus, sorteios com prazo e facilidade de resposta (telefone 24h, formulário simples).

**Fonte:** Dan Kennedy, *The Ultimate Sales Letter* (2ª edição), Seção II "The System", passos 2, 6, 7, 12, 13 e 14 — páginas 21–22, 43–44, 55–56, 101, 103–110, 111.

## 4. Tabela-síntese — auditoria da oferta modelada

| Elemento | Pergunta de diagnóstico | Como intensificar sem mentir |
|---|---|---|
| Promessa | Qual variável da equação de valor ela ataca primeiro? | Deixe o resultado mais específico e mensurável, não mais exagerado |
| Mecanismo | O paradoxo/crença que ele resolve é real para o meu avatar? | Troque o "hype" de referência por um que o seu público reconheça mais |
| Stack | Cada item resolve uma objeção diferente ou está redundante? | Some valor individual declarado a cada item antes de mostrar o preço |
| Bônus | Existe um bônus específico para a maior objeção de compra? | Nomeie o bônus e ligue-o explicitamente à objeção que ele mata |
| Garantia | A garantia reforça a probabilidade percebida ou só existe por padrão? | Suba o nível (de condicional para incondicional) só se a entrega aguentar |
| Preço | O preço reflete o valor da equação ou o custo de produção? | Ancore com a soma do stack antes de revelar o preço final |
| Urgência | O prazo/estoque é real e verificável pelo lead? | Torne o motivo do prazo explícito (turma, lote, data) em vez de genérico |
| Nome | O nome é específico o bastante para vencer o leilão de atenção? | Adicione avatar + resultado + prazo + palavra-recipiente ao nome |
| CTA | O próximo passo está claro e sem fricção extra? | Reduza para uma única ação e reafirme a garantia ao lado do botão |

**Fonte:** síntese própria a partir das seções 1–3 acima.

## 5. Checklist — de oferta que já vende para versão modelada mais forte

1. Reescreva a promessa em uma frase que mira só uma das 4 variáveis da equação de valor, a mais fraca hoje.
2. Liste os problemas do avatar em ordem cronológica até o resultado — confirme que o stack cobre do primeiro ao último.
3. Escreva o mecanismo em três frases: problema, função, solução.
4. Teste se o mecanismo resolve uma pergunta paradoxal real do seu nicho (não inventada).
5. Troque o nome do mecanismo se ele for igual ao de um concorrente maior.
6. Corte um item do stack que custa caro para você e vale pouco para o lead; substitua por algo barato e de alto valor percebido.
7. Nomeie cada bônus pela objeção que ele resolve, não pelo conteúdo que ele contém.
8. Confirme que a soma declarada do stack aparece antes do preço final.
9. Escolha o tipo de garantia pela objeção mais forte do avatar, não por hábito do nicho.
10. Verifique se toda escassez/urgência declarada é 100% real e sustentável na operação.
11. Reescreva a headline testando ao menos duas fórmulas da lista de Kennedy.
12. Adicione um bloco de objeções respondidas (pergunta real + resposta + prova + garantia).
13. Escreva um P.S. que resuma oferta + urgência + prova em três linhas.
14. Confirme que o nome final da oferta carrega avatar, resultado, prazo e palavra-recipiente.
15. Releia o CTA e reduza para uma única ação possível.

**Fonte:** síntese própria a partir das seções 1–3 acima.
