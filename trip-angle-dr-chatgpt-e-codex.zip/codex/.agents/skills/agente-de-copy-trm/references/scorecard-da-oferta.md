# Scorecard da oferta e comparação de conceitos

## Como usar

Pontue cada um dos três conceitos de 1 a 5 em cada critério. Ao lado de toda nota, escreva em uma linha a evidência que a sustenta (ou "hipótese" se não houver). Nota baixa não pode ser escondida por copy: vira **pendência** (o que precisa existir) ou **hipótese de teste** (o que será verificado na Etapa 08).

A origem não fixa o que é "nota baixa". Até o operador definir um corte, trate 1 e 2 como baixa e registre o critério adotado no arquivo.

## Critérios

| Critério | Pergunta de apoio | 1 | 5 |
|---|---|---|---|
| Clareza | A oferta se entende em uma leitura, sem adjetivo vago? | Precisa de explicação | Entendida na primeira leitura |
| Relevância para o avatar | Fala da situação e do desejo registrados no avatar? | Genérica | Usa a situação e a linguagem do avatar |
| Diferenciação | O mecanismo se distingue das alternativas mapeadas na inteligência e na modelagem? | Igual ao mercado | Mecanismo próprio e reconhecível |
| Credibilidade | A promessa é proporcional ao que o produto entrega? | Promete além da entrega | Promessa dentro do escopo |
| Força da prova | A prova disponível está no topo da hierarquia para o claim principal? | Só opinião ou nenhuma | Demonstração ou dados próprios |
| Viabilidade de entrega | A operação entrega com a capacidade informada? | Não comprovada | Confirmada pelo operador |
| Margem | Preço cobre custos e preço mínimo informados? | Ausente ou negativa | Confirmada com números do operador |
| Reversão de risco | A garantia cobre o risco percebido e a operação suporta? | Nenhuma ou insustentável | Clara, com procedimento e exclusões |
| Simplicidade da decisão | Há uma próxima ação e uma condição de compra? | Várias decisões ou condições ocultas | Uma ação, condições visíveis |
| Compliance | Há claim sensível sem revisão ou política de plataforma em risco? | Claims sem revisão | Sem claim sensível pendente |

## Tabela comparativa

| Critério | Conceito A | Conceito B | Conceito C |
|---|---|---|---|
| Clareza | | | |
| Relevância para o avatar | | | |
| Diferenciação | | | |
| Credibilidade | | | |
| Força da prova | | | |
| Viabilidade de entrega | | | |
| Margem | | | |
| Reversão de risco | | | |
| Simplicidade da decisão | | | |
| Compliance | | | |
| **Total (máx. 50)** | | | |
| Notas baixas → pendência ou hipótese | | | |

## Recomendação

A recomendação do vencedor é justificada por **evidência, clareza, desejo, credibilidade e viabilidade**, citando as notas acima e os arquivos de origem (00 a 03). Registre também o que os conceitos descartados perdem e se algum elemento deles migra para o vencedor.
