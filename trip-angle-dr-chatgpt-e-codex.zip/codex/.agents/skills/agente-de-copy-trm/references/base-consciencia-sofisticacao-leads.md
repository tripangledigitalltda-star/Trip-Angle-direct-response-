# Base: consciência, sofisticação e leads (Schwartz + Masterson & Forde)

Destilado operacional de "Breakthrough Advertising" (Eugene Schwartz) e "Great Leads"
(Michael Masterson & John Forde). Use para diagnosticar em que ponto o mercado está
e escolher headline, lead e mecanismo. Não é teoria — é checklist de decisão.

## 1. Desejo de massa

O desejo de massa é "a difusão pública de uma necessidade privada" (Schwartz, cap. 1,
p18): um desejo que já
existe, sozinho, na cabeça de milhões de pessoas, e que a copy não cria — só canaliza.
A copy nunca gera desejo do zero; ela pega esperança, medo ou vontade que já circula
no mercado e aponta essa energia para um produto específico. Tentar remar contra um
desejo de massa (vender o que o mercado não quer, do jeito que ele não quer) sempre
perde para quem segue a maré, não importa o orçamento.

O desejo de massa tem duas origens:
- **Forças permanentes** — instintos que não mudam (atração, virilidade, saúde,
  status) ou problemas técnicos não resolvidos (dor que volta, produto que falha).
  Aqui a tarefa não é descobrir o desejo — ele é óbvio — é diferenciar seu produto
  dos concorrentes que já exploram o mesmo instinto.
- **Forças de mudança** — tendências em início, ápice ou reversão (moda, medo
  econômico, nova tecnologia). Aqui a tarefa é sentir a maré cedo e migrar o ângulo
  antes da concorrência.

Todo desejo de massa tem três dimensões que você mede para escolher qual explorar:
**urgência** (quão forte é a dor agora), **poder persistente** (quão repetitivo,
insaciável) e **escopo** (quantas pessoas compartilham esse desejo). Um produto
sempre toca vários desejos de massa possíveis — a escolha de qual vai para a
headline é a decisão mais importante da copy.

Sequência de trabalho do redator: (1) escolher o desejo de massa mais forte que o
produto pode capturar; (2) declarar, reforçar ou apontar a solução desse desejo na
headline, no ponto de consciência exato em que o cliente já está; (3) mostrar que o
desempenho do produto satisfaz esse desejo.

[aplicação] Na mineração Trip Angle, use isto para separar "ângulo" (recorte de um
desejo de massa já existente) de "mecanismo" (a explicação de como o produto entrega
esse desejo) — são camadas diferentes do mesmo anúncio.

(Schwartz, cap. 1, p18)

## 2. Cinco níveis de consciência

Cada headline responde a uma pergunta: quanto esse mercado já sabe sobre o desejo e
sobre o seu produto? Quanto mais consciente, menos a copy precisa dizer.

| Nível | O cliente já sabe | O que a headline/lead deve fazer |
|---|---|---|
| 1. Mais consciente | Conhece o produto, sabe que funciona, só falta comprar | Ir direto ao nome do produto e ao preço/oferta. Zero criatividade exigida — é vitrine de loja. |
| 2. Consciente do produto | Conhece o produto, mas não está convencido ou não sabe de tudo que ele faz | Reforçar o desejo, ampliar a prova, estender onde/quando o produto entrega, apresentar novidade. |
| 3. Consciente da solução | Sabe que quer o resultado, não sabe que existe um produto que entrega | Nomear o desejo/solução na headline, provar que é alcançável, mostrar que o mecanismo está no seu produto. |
| 4. Consciente do problema | Sente a dor ou a necessidade, mas não liga isso a nenhuma solução | Nomear o problema (ou a solução) na headline, dramatizar a necessidade, depois apresentar o produto como solução inevitável. |
| 5. Totalmente inconsciente | Não percebe que tem o problema, ou não admite, ou o desejo é vago demais para virar frase | Não pode abrir com produto nem com problema direto — precisa de história, identificação ou choque de imagem para trazer o leitor até o desejo antes de nomeá-lo. |

Regra prática: comece a copy exatamente no ponto de consciência em que o leitor já
está. Abrir "abaixo" do nível dele soa condescendente e o perde; abrir "acima" (falando
do produto para quem nem sabe que tem o problema) soa sem contexto e ele não conecta.

(Schwartz, cap. 2, p29)

## 3. Estágios de sofisticação do mercado

Sofisticação mede quantas ofertas parecidas o mercado já viu — não o que ele sabe do
desejo (isso é consciência), mas o quanto ele já está cansado das promessas.

| Estágio | Sinal no mercado | Estratégia de promessa/mecanismo |
|---|---|---|
| 1. Primeiro no mercado | Ninguém fez essa promessa antes para esse público | Declaração direta e simples do desejo/benefício. Nada de mecanismo, nada de ângulo complexo — a novidade da promessa já vende. |
| 2. Segundo a chegar | A promessa direta já rodou, mas ainda é crível | Copie a promessa vencedora e amplie até o limite (mais forte, mais rápido, mais quilos, mais alcance). Funciona até estourar a credibilidade. |
| 3. Mercado saturado de promessa | Toda promessa já foi feita e ampliada ao extremo; ceticismo alto | Pare de brigar pela promessa, mude a arma: entre com um mecanismo novo ("como" funciona) que torna a mesma promessa antiga crível de novo. O mecanismo domina a headline. |
| 4. Mecanismo virou o novo campo de batalha | Concorrentes já lançaram mecanismos concorrentes | Amplie e refine o mecanismo (mais fácil, mais rápido, mais seguro, resolve mais) — mesma lógica de ampliação do estágio 2, agora aplicada ao "como". |
| 5. Mercado exausto | Ninguém mais acredita em promessa nem em mecanismo novo; concorrentes saindo do mercado | A ênfase sai da promessa/mecanismo e vai para identificação com o leitor (quem ele é, não o que ele ganha) — é o mesmo problema do nível 5 de consciência, resolvido pela técnica de Identificação. |

[aplicação] Na prática Trip Angle: estágio de sofisticação é o motivo pelo qual um
"copiar oferta vencedora" que funcionou há 1 ano pode falhar hoje — o mercado avançou
de estágio 2/3 para 4/5 e a mesma promessa nua não fecha mais.

(Schwartz, cap. 3, p54)

## 4. Sete técnicas de Schwartz para construir o corpo

| Técnica | Definição em uma linha | Como aplicar |
|---|---|---|
| Intensificação | Ampliar o desejo já despertado, multiplicando cenas concretas de realização | Depois de nomear o desejo, mostre-o de vários ângulos: prove a alegação, coloque em ação, traga testemunhos, compare com a concorrência, mostre o lado negativo de não ter, sele com garantia. |
| Identificação | Vender o papel/personalidade que o produto permite ao cliente assumir, não só a função física | Construa uma imagem de quem o comprador se torna (o papel, o status, a tribo) e ligue essa imagem ao produto — essencial quando o desejo funcional já está saturado. |
| Gradualização | Fazer o leitor crer na alegação antes de ela ser dita, para fundir desejo + crença em convicção | Construa a crença por etapas — fatos pequenos e aceitáveis primeiro, depois a conclusão maior — em vez de afirmar o benefício grande logo de cara. |
| Redefinição | Dar nova definição a uma desvantagem do produto (complicado, pouco importante, caro) para virar vantagem | Ataque a objeção antes que o leitor a levante: reframe defeito em prova de força (ex.: cheiro forte = prova de que o sabonete é potente). |
| Mecanização | Provar verbalmente que o produto faz o que promete, explicando o "como" | Siga três estágios: nomeie o mecanismo, descreva-o, dramatize-o em ação — responde à pergunta implícita do leitor "como isso funciona?". |
| Concentração | Atacar diretamente os outros caminhos que o leitor tem para satisfazer o mesmo desejo | Use quando dominar o mercado exigir eliminar alternativas — mostre por que os outros métodos falham, não apenas por que o seu funciona. |
| Camuflagem | Pedir emprestada a credibilidade de um veículo/formato em que o leitor já confia | Escreva a copy imitando o formato, o tom e o vocabulário do meio (editorial, notícia, carta pessoal) para herdar a confiança que o leitor já deposita nesse formato. |

(Schwartz, caps. 7–13, p90)

## 5. Great Leads: os seis tipos de lead

Masterson & Forde organizam os leads em uma escala de mais direto a mais indireto,
alinhada à escala de consciência de Schwartz: quanto mais consciente o leitor, mais
direto o lead pode ser; quanto menos consciente, mais indireto precisa ser.

| Tipo de lead | Definição | Quando usar (consciência) |
|---|---|---|
| Oferta | Vai direto à oferta — produto, preço, desconto, prêmio, garantia — já na headline ou nas primeiras linhas | Nível 1 (mais consciente): cliente já confia e já quer o produto, só falta o gatilho comercial. |
| Promessa | Abre com o maior benefício do produto, sem necessariamente citar o produto de cara | Nível 2: cliente conhece o produto/categoria, falta reforçar por que este é a melhor entrega do desejo. |
| Problema-solução | Adia o produto e abre com a questão emocional ("hot button") do leitor, depois liga à solução | Nível 3–4: cliente sente o problema ou já busca a solução, mas ainda não liga ao seu produto. |
| Grande segredo | Abre prometendo conhecimento exclusivo (fórmula, sistema, informação escondida), revelado ao comprar | Nível 3–4, quando a categoria já está cética e precisa de um motivo novo para acreditar. |
| Proclamação/revelação | Abre desarmando o leitor com um fato chocante, previsão ousada ou afirmação inesperada, propositalmente indireto | Nível 4–5: leitor não liga o problema à solução ou nem admite o problema — precisa ser abalado antes de ouvir a oferta. |
| História | Abre contando uma história (depoimento, trajetória, prova histórica) que conduz até a promessa | Nível 5 (inconsciente) ou qualquer nível quando o leitor desconfia de abordagem direta — a história rende engajamento sem pedir crença antecipada. |

Regras de ouro de um lead forte:
- **Regra do Um**: um lead vencedor carrega uma única Grande Ideia. Misturar duas
  ou três ideias centrais dilui a força de todas.
- Todo lead forte, direto ou indireto, contém cinco elementos: uma boa ideia, uma
  emoção essencial, uma história (ou gancho) cativante, um benefício desejável e
  uma reação inevitável (o que o leitor faz a seguir).
- Todo lead — por mais indireto que seja — precisa chegar ao benefício do produto e
  à oferta o mais cedo que o nível de consciência permitir. Indireto não é sinônimo
  de vago.
- A escolha direto vs. indireto não é de gosto: é function do quanto o leitor já
  confia em você, já aceita que o problema existe e já aceita que existe solução.

(Masterson & Forde, cap. 3)

## 6. Tabela-síntese: consciência × sofisticação → lead

| Consciência | Sofisticação típica | Tipo de lead recomendado | Foco da headline | Papel do mecanismo |
|---|---|---|---|---|
| 1. Mais consciente | Qualquer | Oferta | Nome do produto + preço/condição | Irrelevante — já aceito |
| 2. Consciente do produto | Estágio 1–2 | Promessa | Benefício mais forte do produto | Ausente ou coadjuvante |
| 3. Consciente da solução | Estágio 2–3 | Promessa ampliada / grande segredo | Solução nomeada, ampliada ao limite crível | Começa a aparecer como diferenciação |
| 4. Consciente do problema | Estágio 3–4 | Problema-solução / grande segredo | Problema dramatizado, depois mecanismo novo | Domina a headline — é o que renova a credibilidade |
| 5. Inconsciente / mercado exausto | Estágio 4–5 | Proclamação, revelação ou história | Choque, identificação ou narrativa — nunca o produto de cara | Secundário — a identificação com o leitor substitui a lógica do mecanismo |

[aplicação] Esta tabela cruza os dois eixos (Schwartz) com a escolha de lead
(Masterson & Forde); a combinação exata célula a célula é inferência minha — os
livros tratam consciência e sofisticação como eixos correlacionados, não idênticos, e
o operador deve checar os dois separadamente antes de travar o lead.

## 7. Checklist de diagnóstico de oferta

1. Qual desejo de massa específico este produto está canalizando — e ele é
   permanente ou uma tendência de mudança que pode virar amanhã?
2. Esse desejo, medido nas três dimensões (urgência, poder persistente, escopo),
   é forte o suficiente para sustentar a campanha, ou é secundário?
3. Em qual dos cinco níveis de consciência está o público que este anúncio/copy
   está tentando atingir — e a headline atual fala nesse nível ou em outro?
4. A headline exige que o leitor já saiba algo que ele ainda não sabe?
5. Em qual estágio de sofisticação este nicho está — quantas promessas parecidas
   o público já viu, e o mercado ainda acredita em promessa nua ou já exige
   mecanismo?
6. Se o estágio for 3+, existe um mecanismo nomeado e dramatizado, ou a copy só
   repete a promessa antiga com adjetivos mais fortes?
7. A copy usa alguma das sete técnicas (intensificação, identificação,
   gradualização, redefinição, mecanização, concentração, camuflagem) de forma
   deliberada, ou só empilha alegações soltas?
8. Existe uma desvantagem óbvia do produto (caro, complicado, nicho) que precisa
   de redefinição e ainda não foi endereçada?
9. Qual tipo de lead (dos seis) está sendo usado — e ele é compatível com o nível
   de consciência mapeado na pergunta 3?
10. O lead obedece à Regra do Um, ou está tentando vender duas ou três ideias
    centrais ao mesmo tempo?
11. O lead entrega os cinco elementos (ideia, emoção, história/gancho, benefício,
    reação inevitável) ou falta algum?
12. Se o mercado estiver no estágio 5 de sofisticação/consciência, a copy está
    usando identificação e história em vez de insistir em promessa e mecanismo?
13. O mecanismo, se existe, seria aceito como verossímil por este público
    específico, ou soa reciclado de outra oferta já vista?
14. Existe evidência (nos próprios anúncios/páginas coletados) de que o mercado já
    rejeitou esse ângulo — sinal de estágio de sofisticação mais avançado do que
    o suposto?
15. Se fosse necessário reabrir este mercado do zero (estágio 5), qual seria a
    nova promessa, o novo mecanismo ou a nova identificação a testar?
