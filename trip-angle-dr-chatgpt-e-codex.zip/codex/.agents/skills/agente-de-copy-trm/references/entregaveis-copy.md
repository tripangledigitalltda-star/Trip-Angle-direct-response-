# Entregáveis de copy

Escreva cada peça depois do card da oferta modelada. Use moldes de headline e padrões de lead das bases de inteligência. Não copie frases da referência.

## 1. Roteiro de VSL (padrão, ajustável)
| # | Bloco | Função | Duração sugerida |
|---|---|---|---|
| 1 | Hook | Parar e selecionar a persona pela situação ou pela promessa | 0–30 s |
| 2 | Lead | Promessa ou lacuna central, conforme o tipo de lead | 30 s–2 min |
| 3 | Qualificação | Para quem é e para quem não é | curto |
| 4 | História ou descoberta | Tornar o mecanismo crível e humano | 2–5 min |
| 5 | Mecanismo do problema | Por que tudo o que a pessoa tentou falhou, sem culpá-la | 2–4 min |
| 6 | Mecanismo da solução | Como a nova abordagem resolve a causa | 2–4 min |
| 7 | Prova | Demonstração, dados próprios, casos autorizados | 1–3 min |
| 8 | Produto | O que é e como funciona na prática | 1–2 min |
| 9 | Stack | Entregáveis e bônus, cada um ligado a um obstáculo | 1–2 min |
| 10 | Preço e ancoragem | Comparação honesta com alternativas e custo de não agir | 1 min |
| 11 | Garantia | Remove o risco da decisão | 30 s |
| 12 | Urgência | Motivo real para agir agora | 30 s |
| 13 | CTA | Ação única e o que acontece depois | 30 s |
| 14 | FAQ e objeções | Últimas travas | 1–3 min |
Durações são ponto de partida. Formato do roteiro: bloco · fala · texto na tela · visual · função.

## 2. Carta ou página de vendas em blocos
Headline · subheadline · lead · identificação do problema · agitação com custo de continuar · mecanismo · apresentação do produto · benefícios em bullets · prova · stack · preço e ancoragem · garantia · urgência · CTA · FAQ · P.S. Cada bullet: benefício específico, curiosidade ou prova, nunca uma característica solta.

## 3. Leads alternativos
Três leads do mesmo produto em tipos diferentes adequados à consciência (por exemplo promessa, segredo, história). Cada um com 150 a 300 palavras e a indicação do nível de consciência para o qual foi escrito.

## 4. Banco de headlines e hooks
| Texto | Molde de origem | Desejo acionado | Consciência | Ângulo | Formato sugerido para anúncio |
Mínimo de 30, com pelo menos cinco ângulos diferentes.

## 5. Roteiros de anúncio curtos (para o AGENTE DE ADS TRM)
| Tempo | Fala | Texto na tela | Visual | Função |
Estrutura: hook 0–3 s · situação ou problema · mecanismo ou virada · prova · promessa e CTA. Um ângulo por roteiro. Mínimo de 5 roteiros.

## 6. FAQ de objeções
| Objeção | Resposta | Prova ou garantia que sustenta |

## 7. Tabela de claims (obrigatória)
| Claim | Onde aparece | Prova própria | Sensível? | Risco | Versão segura se faltar prova |

## 8. Hipóteses de teste
| Variável (promessa, mecanismo, lead, stack, preço, garantia) | Controle | Variante | Métrica principal | Critério de decisão |
Uma variável por teste.
