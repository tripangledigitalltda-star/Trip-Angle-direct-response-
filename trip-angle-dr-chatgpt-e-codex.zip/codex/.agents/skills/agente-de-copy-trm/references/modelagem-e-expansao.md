# Modelagem e expansão

## 1. DNA funcional
Converta cada elemento do mapa em verbo de função: hook chama a persona pela situação; lead aumenta relevância e abre lacuna; mecanismo torna a solução compreensível e diferente; prova derruba uma dúvida específica; stack reduz risco, tempo e esforço percebidos; urgência justifica agir agora. O nome, a história e a frase são superfície. A função é o que se modela.

## 2. Semáforo (método Trip Angle)
| Cor | O que é | Uso |
|---|---|---|
| Verde | Função abstrata: autorreconhecimento, contraste, progressão de crença, demonstração, redução de risco, sequência de blocos | Modelar livremente |
| Amarelo | Padrão contextual: tipo de mecanismo, tipo de lead, arquitetura de funil, categoria de prova, modelo de garantia, estrutura de stack | Adaptar à persona, ao produto e à prova própria |
| Vermelho | Expressão e ativos: frases, nomes, histórias, personagens, especialistas, depoimentos, números, imagens, voz, design, promessa específica | Não reutilizar |
Teste rápido: se a copy nova depende de palavras, personagens, provas ou ativos da referência para funcionar, ainda não foi modelada. Auditoria completa em `../../agente-de-copy-trm/references/modelagem-sem-copia.md`.

## 3. Onde a expansão nasce
Cada ponto fraco do diagnóstico vira uma frente de expansão:
| Ponto fraco encontrado | Frente de expansão |
|---|---|
| Mercado sofisticado, promessa gasta | Mecanismo novo ou reposicionado; promessa pelo mecanismo |
| Consciência baixa tratada com oferta direta | Lead de história, segredo ou problema-solução |
| Prova fraca para o claim | Promessa um degrau abaixo, prova própria, demonstração |
| Stack com bônus de volume | Bônus que removem obstáculos reais do caminho |
| Objeção principal sem resposta | Bloco dedicado, garantia específica, FAQ |
| Uma única persona | Segmentação por situação, com lead e hook próprios |
| Urgência fraca ou falsa | Motivo real: lote, turma, bônus com prazo, custo de esperar |

## 4. Ângulo novo: ficha
Tese · inimigo · desejo de massa · persona e situação · nível de consciência · tipo de lead · mecanismo que sustenta · prova necessária · hook de exemplo · risco.

## 5. Mecanismo próprio: ficha
Nome candidato · causa que ele explica · por que as alternativas falharam · como a solução age · o que o produto entrega de fato para isso · prova disponível · prova necessária · teste do nome removido (a lógica se sustenta sem o nome?).

## 6. Escada de intensidade da promessa
Suba degrau a degrau e pare no último que a prova própria sustenta:
1. Benefício genérico.
2. Benefício específico com resultado concreto.
3. Resultado específico com prazo ou condição.
4. Resultado com mecanismo nomeado.
5. Resultado com mecanismo, prazo e contraste com o que falhou.
6. Resultado com mecanismo, prazo, contraste e prova visual ou demonstração.
Intensifique também sem subir o claim: mais desejo (cena, identidade, perda evitada), mais especificidade (números da própria oferta, passos, detalhes), mais contraste (antes e depois da situação, inimigo), mais facilidade (esforço e tempo menores percebidos).

## 7. Localização de oferta global
1. Traduza a função, nunca a frase.
2. Troque referências culturais, unidades, preços, datas comemorativas e exemplos.
3. Ajuste o nível de consciência e de sofisticação ao mercado local, que pode estar em estágio diferente.
4. Refaça provas com fontes locais ou próprias.
5. Revise regulação local: CDC, CONAR, ANVISA, LGPD e políticas da Meta no Brasil.
6. Reescreva a voz do cliente com frases do público local (comentários, fóruns, AGENTE DE ADS).

## 8. Oferta modelada (card)
Nome da oferta · persona principal · desejo de massa · consciência e sofisticação · Big Idea · mecanismo do problema · mecanismo da solução · promessa (degrau da escada) · produto e entregáveis · bônus e obstáculo removido · preço e ancoragem · garantia · urgência verdadeira · provas próprias · objeções prioritárias · lead escolhido · funil · linhagem (o que veio da referência como função) · claims pendentes · primeira hipótese de teste.
