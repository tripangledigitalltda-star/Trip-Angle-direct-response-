# Mapa da oferta de referência

Preencha a partir do que foi visto. Cada linha leva rótulo. Campo sem fonte: NÃO MAPEADO.

## 1. Fonte
Nome da oferta · anunciante · país · idioma · moeda · URLs (anúncio, quiz, VSL, página, checkout) · data da captura · sinais de escala (contagem, IDs, início, repetição) · plataforma de checkout · o que não foi acessado.

## 2. Personas
| Persona | Situação observável | Gatilho que dispara a compra | Linguagem literal usada | Nível de consciência | Evidência |
Uma linha por persona chamada no anúncio, no quiz ou na VSL. Não crie persona que a copy não chama.

## 3. Dores, desejos e crenças
| Dor (na voz do público) | Desejo correspondente | Desejo primário acionado | Crença atual | Crença que a copy instala | Onde aparece |

## 4. Promessa e benefícios
- Promessa principal, literal, com prazo, condição e resultado.
- Promessas secundárias.
- Benefícios em três camadas:
| Característica ou entregável | Benefício funcional | Benefício emocional ou identitário |

## 5. Mecanismo e Big Idea
- Mecanismo do problema: a causa que a copy aponta.
- Mecanismo da solução: como o produto resolve essa causa.
- Nome do mecanismo e o que resta da lógica se o nome for removido.
- Big Idea em uma frase.
- Inimigo nomeado.

## 6. Provas
| Claim | Prova apresentada | Tipo | Fonte | O que sustenta de fato | Limite |
Depoimento, autoridade, estudo e número citados pela copy são ALEGAÇÃO DA COPY.

## 7. Oferta
Produto principal · entregáveis e formato · bônus e o obstáculo que cada um remove · preço · parcelamento · ancoragem · garantia (tipo, prazo, condição) · urgência e escassez (e se parecem verdadeiras) · order bump · upsell · downsell · nome da oferta.

## 8. Objeções
| Objeção | Como a copy responde | Momento na VSL ou página | Força da resposta |

## 9. Funil e estrutura da copy
- Caminho: anúncio → pré-lander → quiz → VSL ou página → checkout → upsell.
- VSL ou carta bloco a bloco:
| Bloco | Tempo ou posição | Função | Resumo em suas palavras | Técnica usada |
Blocos típicos: hook, lead, história, descoberta, mecanismo do problema, mecanismo da solução, prova, apresentação do produto, stack, preço e ancoragem, garantia, urgência, CTA, FAQ, P.S.

## 10. Anúncios e hooks
| ID ou URL | Hook (tipo e texto) | Ângulo | Formato | Lead usado | Continuidade com a VSL |

## 11. Contexto de país (ofertas globais)
Referências culturais, unidades, sazonalidade, regulação, termos que não traduzem, provas que dependem do país, meios de pagamento.
