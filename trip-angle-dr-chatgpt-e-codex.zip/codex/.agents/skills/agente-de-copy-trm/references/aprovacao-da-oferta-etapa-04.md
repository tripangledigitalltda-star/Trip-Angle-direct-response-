# Aprovação da oferta: três conceitos, scorecard e Offer Card (origem: skill 04-mineracao-de-ofertas, consolidada em 13/09/2026)


# 04 — Mineração de Ofertas (construção e aprovação da oferta)

Etapa 04 de 09 da linha de produção Trip Angle. Entra com briefing, inteligência, modelagem e avatar aprovados; sai com **três conceitos de oferta, uma recomendação principal e o conjunto aprovado de promessa, mecanismo, prova, bônus, garantia e preço**, gravado em `04-oferta-aprovada.md` e fechado com o bloco de handoff que abre a Etapa 05 — Copy.

Não é a mineração na Biblioteca de Anúncios (isso é `agente-de-espionagem-trm`). Aqui "minerar" é extrair a oferta do que o projeto já provou.

Dependências externas (repositório `coreyhaines31/marketingskills`, nomes v2): `offers`, `pricing`, `marketing-psychology`, `competitor-profiling`, `customer-research`. Use-as como apoio de método; o procedimento desta etapa é o descrito abaixo.

## Regras desta etapa

1. Nunca inventar número, prova, depoimento, pesquisa ou resultado. O que não está nas entradas é **informação ausente** e entra como pendência, nunca como conteúdo.
2. Rotular toda afirmação como **evidência**, **hipótese**, **decisão** ou **ausente**.
3. Prova sempre a mais próxima possível do claim (hierarquia em `offer-card-7-perguntas-hierarquia-prova.md`).
4. Claims sensíveis (saúde, emagrecimento, renda, finanças, segurança, crianças) exigem revisão específica. CDC, CONAR e ANPD se aplicam.
5. Escassez e urgência só quando verdadeiras. "Por que agora" precisa de motivo real.
6. Modo rascunho: preço, promessa e aprovação final são decisões humanas. A skill recomenda; o operador aprova.
7. Não encerrar sem o bloco `HANDOFF DO PROJETO` preenchido.

## 0. Verificação de entradas (antes de produzir qualquer coisa)

Abra pedindo o **handoff da Etapa 03** e os artefatos anteriores. Confira item a item e liste o que falta. Não gere conceito, promessa, prova ou preço enquanto a tabela abaixo tiver linha em aberto sem decisão explícita do operador.

| Entrada | Onde vem | Se faltar |
|---|---|---|
| `00-briefing-e-plano.md` | Etapa 00 | Pedir. Sem briefing não há recorte de produto, público e restrições. |
| `01-inteligencia-dr.md` (diagnóstico de mercado) | Etapa 01 | Pedir. Sem diagnóstico, "diferenciação" e "relevância" ficam sem base. |
| `02-modelagem.md` (matriz de modelagem) | Etapa 02 | Pedir. Referências entram como padrão observado, nunca como cópia. |
| `03-avatar-ads.md` (avatar, consciência, objeções, linguagem) + bloco `HANDOFF DO PROJETO` da Etapa 03 | Etapa 03 | Pedir. Sem avatar a skill não escreve promessa nem objeções. |
| Custos, preço mínimo e capacidade de entrega | Operador | Pedir. Sem isso, preço e viabilidade ficam marcados como **ausente** e não entram na recomendação. |
| Provas e diferenciais reais (o que existe hoje, com fonte) | Operador | Pedir. Sem prova, todo claim vira hipótese e a oferta não pode ser aprovada. |
| Regras da plataforma e do mercado (política de anúncios, categoria sensível, restrições legais) | Operador | Pedir. Define os claims proibidos. |

Formato da checagem: uma lista "Recebido / Faltando / Ausente por decisão do operador". Quando o operador declarar que algo não existe, registre como **informação ausente** e siga com a restrição correspondente. Não preencha o vazio.

## 1. Processo

### 1.1 Base da oferta
A partir das entradas, fixe em uma linha cada: **problema** (no vocabulário do avatar), **transformação** (estado atual → desejado, delimitada e responsável), **mecanismo do problema** e **mecanismo da solução**. Cada linha recebe rótulo (evidência / hipótese) e aponta a fonte no arquivo de origem.

### 1.2 Produto principal e pilha de valor
Liste o produto principal e os entregáveis com formato, acesso, suporte, prazo e limites. Bônus só entram se removem obstáculo, aceleram ou reduzem risco; caso contrário são volume. Registre o que a operação consegue entregar com a capacidade informada.

### 1.3 Três conceitos com ângulos distintos
Produza três conceitos, cada um com ângulo diferente (não três variações da mesma promessa). Preencha o formulário de conceito de `modelo-oferta-aprovada.md`, campo a campo:
avatar e problema · transformação · promessa responsável · mecanismo · produto principal · bônus · prova disponível · prova ainda necessária · garantia · preço e justificativa · objeções · riscos · headline e CTA provisórios.

Responda para cada conceito as **sete perguntas obrigatórias** (`offer-card-7-perguntas-hierarquia-prova.md`). Pergunta sem resposta sustentada = lacuna declarada no conceito.

### 1.4 Comparação e scorecard
Pontue cada conceito de 1 a 5 nos dez critérios do scorecard (`scorecard-da-oferta.md`): clareza, relevância para o avatar, diferenciação, credibilidade, força da prova, viabilidade de entrega, margem, reversão de risco, simplicidade da decisão, compliance. Nota baixa não se esconde com copy: vira pendência ou hipótese de teste, escrita ao lado da nota.

### 1.5 Recomendação
Recomende um vencedor e justifique com base em **evidência, clareza, desejo, credibilidade e viabilidade**, citando as notas do scorecard e os arquivos de origem. Diga o que os outros dois conceitos perdem e se algum elemento deles migra para o vencedor.

### 1.6 Validação do conceito recomendado
Antes de pedir aprovação, valide: promessa específica e comprovável; mecanismo claro; prova, garantia e preço coerentes com custos e capacidade informados; escassez real ou inexistente. Preencha o **Offer Card** completo (`offer-card-7-perguntas-hierarquia-prova.md`) para o conceito recomendado.

### 1.7 Aprovação humana
Apresente o Offer Card e peça aprovação formal. Registre quem aprovou e quando. Sem aprovação registrada, o arquivo fica como rascunho e o handoff marca "Portão de aprovação: pendente".

## 2. Saída obrigatória

Grave `04-oferta-aprovada.md` seguindo `modelo-oferta-aprovada.md`:

1. Resumo das entradas usadas (com o que ficou ausente).
2. Base da oferta (problema, transformação, mecanismos) com rótulos.
3. Três conceitos completos.
4. Scorecard comparativo.
5. Recomendação e justificativa.
6. Offer Card do conceito aprovado.
7. Claims e provas pendentes, riscos legais e operacionais.
8. Bloco `HANDOFF DO PROJETO`.

## 3. Checklist de saída

- [ ] Todas as entradas da seção 0 foram conferidas e o que falta está listado.
- [ ] Promessa é específica e comprovável.
- [ ] Mecanismo está claro.
- [ ] Valor percebido não depende de exageros.
- [ ] Preço e entrega são viáveis com os custos e a capacidade informados.
- [ ] Escassez e prova são reais.
- [ ] Nenhuma nota baixa do scorecard ficou sem pendência ou hipótese.
- [ ] Claims sensíveis marcados para revisão.
- [ ] Uma oferta foi formalmente aprovada (ou o arquivo está marcado como rascunho).
- [ ] Bloco `HANDOFF DO PROJETO` preenchido.

## 4. Handoff obrigatório

Encerre sempre com o bloco abaixo, todos os campos preenchidos. Somente a oferta aprovada alimenta a Etapa 05; conceitos descartados ficam registrados no arquivo, não no handoff.

```
HANDOFF DO PROJETO
Etapa concluída: 04 — Mineração de Ofertas
Versão e data:
Objetivo:
Entradas utilizadas:
Evidências confirmadas:
Hipóteses abertas:
Decisões aprovadas:
Artefatos produzidos: 04-oferta-aprovada.md
Claims e provas pendentes:
Riscos e restrições:
Métrica principal:
Portão de aprovação:
Próximo agente: 05 — Copy
Próxima ação única:
```

A Etapa 05 abre pedindo exatamente este bloco mais o Offer Card aprovado, o avatar e as provas autorizadas.
