# Cards, matrizes e checklists de criação (literais do Notion Trip Angle)

## Resumo estratégico de uma página (Fase 1 do módulo 03)
Público específico · Situação observável · Desejo prioritário · Problema e impacto · Alternativas já tentadas · Por que não funcionaram · Objeção dominante · Linguagem recorrente · Prova disponível · Hipóteses ainda abertas. Checkpoint: você explica o problema com palavras do cliente e aponta as fontes.

## Pré-requisitos antes de abrir um documento de copy
[ ] mercado e recorte de público · [ ] situação observável · [ ] desejo expresso · [ ] problema prioritário e consequências · [ ] soluções já tentadas · [ ] alternativas e concorrentes · [ ] frases reais coletadas · [ ] objeções e riscos percebidos · [ ] provas disponíveis · [ ] limites legais, operacionais ou de promessa.

## Banco de voz do cliente
| Frase exata (sem reescrever) | Fonte | Situação (quando acontece) | Desejo | Objeção | Prova necessária |

## Estágios de consciência e entrada
| Estágio | O que a pessoa pensa | Objetivo da mensagem | Boa entrada |
|---|---|---|---|
| Não consciente | não nomeia o problema | tornar a situação reconhecível | cena, sintoma, contraste, pergunta concreta |
| Consciente do problema | sabe que algo está errado | organizar o problema e consequências | diagnóstico, causa, custo de manter |
| Consciente da solução | compara caminhos | diferenciar mecanismo e critérios | nova oportunidade, comparação, como funciona |
| Consciente do produto | conhece a oferta, tem dúvidas | reduzir risco, provar adequação | provas, objeções, escopo, garantia, demo |
| Muito consciente | perto de decidir | facilitar a ação | resumo, condições, urgência verdadeira, CTA |
Checkpoint: headline, lead e CTA começam no mesmo nível de consciência.

## Offer Card (módulo 03)
| Campo | Preenchimento |
|---|---|
| Público + situação | quem enfrenta qual momento específico |
| Transformação | do estado atual ao desejado |
| Mecanismo da solução | princípio e sequência que tornam a mudança plausível |
| Entregáveis | o que entra, formato, duração, suporte, acesso |
| Prova | evidências verificáveis e relevantes para o claim |
| Objeções | confiança, valor, tempo, esforço, prioridade, autoridade, risco |
| Preço e condições | valor, parcelas, renovação, custos adicionais, regras |
| Garantia e limites | o que é coberto, prazo, procedimento, exclusões |
| CTA | uma próxima ação objetiva |
Checkpoint: a oferta é entendida sem adjetivos vagos; mecanismo plausível; escopo e limites visíveis; cada claim importante tem prova.

## Estrutura da oferta (Fase 4)
Produto central · Transformação principal · Mecanismo · Entregáveis · Forma de acesso · Onboarding · Prazo e cadência · Suporte · Critérios de sucesso do cliente · Bônus funcionais · Preço e condições · Garantia/redução de risco · Escassez/urgência real · Provas · Limitações e responsabilidades.

## Matriz de prova
| Tipo de prova | O que sustenta | Limite |
|---|---|---|
| Demonstração | funcionamento do processo/produto | não garante o resultado final |
| Dados do produto | uso, conclusão, velocidade, comportamento | precisa de fonte e contexto |
| Caso de cliente | resultado em contexto específico | não representa resultado típico |
| Depoimento | experiência declarada | confirmar autorização e veracidade |
| Especialista/estudo | princípio geral | não prova que seu produto entrega |
| Prova inexistente | nada | bloqueia claim forte; transforme em hipótese |

## Revisão de claims antes de publicar
[ ] resultado anunciado dentro do que o produto entrega · [ ] evidência arquivada para números e declarações · [ ] exceção não tratada como típica · [ ] depoimentos com autorização e contexto · [ ] limitações não omitidas · [ ] garantia, preço, prazo e escassez verdadeiros · [ ] regras do canal, país e categoria · [ ] claims sensíveis (saúde, emagrecimento, dinheiro, segurança, garantia de retorno, comparação absoluta) revisados. CDC arts. 36–38; CONAR; Padrões de Publicidade da Meta.

## Matriz de mensagem
| Elemento | Pergunta | Saída |
|---|---|---|
| Situação | que momento faz a mensagem ser relevante? | cena ou contexto reconhecível |
| Problema | o que impede o progresso? | diagnóstico específico |
| Desejo | que progresso a pessoa procura? | resultado em linguagem real |
| Mecanismo | por que persiste e como a solução muda isso? | explicação simples e diferenciada |
| Promessa | qual mudança responsável propomos? | benefício com condição e escopo |
| Prova | o que reduz a incerteza? | prova conectada ao claim |
| Objeção | o que impede o próximo passo? | resposta, pergunta e evidência |
| CTA | qual é a menor decisão útil agora? | ação única e clara |

## Checklist de uma boa frase
[ ] compreendida na primeira leitura · [ ] verbo e imagem concreta · [ ] benefício relevante, não só função · [ ] sem superlativo sem prova · [ ] voz do público sem caricatura · [ ] leva à próxima frase · [ ] não promete além do que a entrega sustenta.

## Escolha do ativo de venda
| Use quando | Formato | Cuidado |
|---|---|---|
| oferta simples, familiar, baixo risco | página curta | não omitir informação essencial |
| oferta nova, cara, complexa, muitas objeções | página longa | cada seção reduz uma dúvida |
| mecanismo precisa de narrativa/demonstração/sequência | VSL | legenda, controles, resumo escrito |
| segmentar ou personalizar recomendação | quiz/diagnóstico | nenhuma pergunta sem efeito na saída |
| diagnóstico, configuração, confiança | WhatsApp ou ligação | qualificar fit, documentar próximo passo, sem pressão |
| prova depende de ver o produto | demo ou aplicação | critérios de entrada e decisão |

## Estrutura modular de página ou VSL (use só os blocos necessários)
1 Entrada (headline, subheadline, contexto) · 2 Reconhecimento (situação, sintomas, custo) · 3 Diagnóstico (mecanismo do problema) · 4 Nova oportunidade (mecanismo da solução) · 5 Transformação (promessa e para quem) · 6 Como funciona (processo/demonstração) · 7 Prova · 8 Oferta (entregáveis, suporte, limites) · 9 Valor e condições · 10 Risco (garantia, privacidade, política) · 11 Objeções (FAQ priorizada) · 12 Ação (CTA e o que acontece depois).

## QA do ativo
[ ] título e anúncio falam da mesma promessa · [ ] um CTA principal · [ ] oferta e preço claros · [ ] prova próxima do claim · [ ] botão explica a ação · [ ] formulário pede só o necessário · [ ] funciona no celular · [ ] vídeo com legenda e controle · [ ] carregamento e links testados · [ ] política, termos, contato e reembolso acessíveis · [ ] pós-clique e pós-compra definidos. Checkpoint: alguém entende "para quem é, o que recebe, por que acreditar, quanto custa e o que acontece depois" sem falar com você.

## Escolha do funil
| Condição | Rota provável |
|---|---|
| produto simples, compra autônoma | anúncio/conteúdo → página → checkout → onboarding |
| necessidade de educação | conteúdo/anúncio → VSL/página → checkout ou conversa |
| necessidade de segmentação | quiz → recomendação → página/conversa |
| ticket ou risco alto | conteúdo/anúncio → aplicação → descoberta → proposta → onboarding |
| serviço configurável | entrada → diagnóstico → escopo → proposta → kickoff |
Atritos de checkout: [ ] custo total antes da confirmação · [ ] meios de pagamento · [ ] política e suporte visíveis · [ ] poucos campos · [ ] erros orientam correção · [ ] confirmação e próximos passos imediatos · [ ] evento de conversão validado.

## Roteiro de descoberta (venda consultiva)
1 Contrato da conversa · 2 Contexto · 3 Estado atual · 4 Problema · 5 Impacto · 6 Tentativas · 7 Estado desejado · 8 Decisão · 9 Fit · 10 Próximo passo (decisão, tarefa, responsável, data). Perguntas: "O que mudou para isso virar prioridade agora?", "Pode me mostrar como você faz hoje?", "Onde o processo trava?", "Quem mais sente o impacto?", "O que já tentaram?", "Que resultado faria valer a pena?", "Quais critérios para decidir?", "Existe condição que impediria?", "Qual próximo passo faz sentido para os dois?".

## Método CALMA e matriz de objeções
C Calar e ouvir · A Acolher · L Localizar a raiz · M Mostrar evidência · A Acordar o próximo passo.
| Objeção | Raízes possíveis | Pergunta de diagnóstico | Resposta responsável |
|---|---|---|---|
| "Está caro." | valor não entendido, orçamento, prioridade, risco | "Comparado a qual alternativa ou resultado?" | revisar escopo, impacto, prova e condição; não inventar desconto |
| "Não tenho tempo." | esforço, prioridade, momento | "Qual parte parece exigir mais tempo?" | explicar participação real, simplificar ou admitir falta de fit |
| "Preciso pensar." | dúvida não dita, outra pessoa, comparação, baixa urgência | "Que ponto você precisa esclarecer para decidir?" | informação e prazo natural; evitar perseguição |
| "Já tentei algo parecido." | desconfiança, experiência ruim | "O que foi tentado e onde falhou?" | diferenciar mecanismo e limites com prova |
| "Preciso falar com alguém." | autoridade compartilhada | "Quem participa e quais critérios usa?" | preparar resumo, incluir decisores |
| "Agora não." | prioridade, orçamento, capacidade, ausência de dor | "O que precisaria mudar para reavaliar?" | acordar condição/data real ou encerrar |

## Follow-up (três mensagens)
1 Recapitulação: "Pelo que entendi, hoje [situação], isso gera [impacto] e a prioridade é [objetivo]. Combinamos [próximo passo] até [data]. Aqui está [material]. Se algo estiver incorreto, me avise." · 2 Evidência relevante: "Você comentou [objeção]. Separei [demonstração/caso/dado] porque mostra [ponto]. Isso responde ou falta contexto?" · 3 Fechamento do ciclo: "Não quero insistir sem contexto. Faz sentido [próximo passo], prefere retomar em [condição/data] ou encerro por agora?" Registro mínimo: data e canal, etapa, necessidade e impacto, objeção aberta, material enviado, decisão e responsável, próxima ação e data, motivo de perda ou pausa.

## Card Final da Oferta
Nome · Versão e data · Mercado · Segmento · Situação de compra · Desejo · Problema · Crença dominante · Mecanismo do problema · Mecanismo da solução · Nova oportunidade · Big Idea · Ângulo principal · Promessa · Produto · Entregáveis · Bônus funcionais · Preço e condições · Garantia/redução de risco · Provas · Claims pendentes de revisão · Funil escolhido · Métrica principal · Primeiro Test Card · O que permanece como hipótese.

## Rubrica de prontidão (0–2 cada, máx. 20)
Criação: demanda e problema · clareza do segmento · situação observável · força lógica do mecanismo · especificidade da promessa · coerência promessa/produto · prova disponível · economia mínima · segurança dos claims · qualidade do Test Card. 15 = pode seguir para teste pequeno; zero em evidência, entrega, claims ou tracking bloqueia.
Engenharia (módulo 03): público e situação · problema e desejo com evidência · consciência definida · mecanismo plausível · promessa responsável · prova próxima dos claims · escopo/preço/risco/limites · ativo e funil sem lacunas · objeções e follow-up · teste com critério. 17–20 pronto para teste controlado; 12–16 corrigir; 0–11 voltar à pesquisa.

## Briefing de passagem
Para 04 — Criativos: público e situação · estágio de consciência · hipótese de ângulo · hook e promessa · mecanismo · prova disponível · objeção prioritária · CTA · formato e canal · claims proibidos ou que exigem revisão.
Para 05 — Tráfego: objetivo e evento · público/segmento · ativo e URL · hipótese · variável · orçamento e janela · métrica principal · guardrails · critério de pausa · decisão pós-teste.
