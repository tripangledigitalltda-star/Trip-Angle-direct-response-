# Modelo de `04-oferta-aprovada.md`

Copie a estrutura abaixo. Toda afirmação recebe um rótulo entre colchetes: **[EVIDÊNCIA — fonte]**, **[HIPÓTESE]**, **[DECISÃO — quem, quando]** ou **[AUSENTE]**.

---

# 04 — Oferta aprovada · [produto] · v[n] · [data]

## 1. Entradas utilizadas
| Entrada | Recebida | Observação |
|---|---|---|
| 00-briefing-e-plano.md | sim / não | |
| 01-inteligencia-dr.md | sim / não | |
| 02-modelagem.md | sim / não | |
| 03-avatar-ads.md + handoff da Etapa 03 | sim / não | |
| Custos, preço mínimo, capacidade de entrega | sim / não / ausente por decisão | |
| Provas e diferenciais reais | sim / não / ausente por decisão | |
| Regras da plataforma e do mercado | sim / não | |

## 2. Base da oferta
- Problema (vocabulário do avatar): … [rótulo]
- Transformação (estado atual → desejado): … [rótulo]
- Mecanismo do problema: … [rótulo]
- Mecanismo da solução: … [rótulo]
- Produto principal e pilha de valor (entregáveis, formato, acesso, suporte, prazo, limites): … [rótulo]

## 3. Conceitos de oferta

### Conceito A — ângulo: [nome do ângulo]
| Campo | Conteúdo | Rótulo |
|---|---|---|
| Avatar e problema | | |
| Transformação | | |
| Promessa responsável | | |
| Mecanismo | | |
| Produto principal | | |
| Bônus (cada um: que obstáculo remove, acelera ou que risco reduz) | | |
| Prova disponível (com fonte) | | |
| Prova ainda necessária | | |
| Garantia (cobertura, prazo, procedimento, exclusões) | | |
| Preço e justificativa | | |
| Objeções | | |
| Riscos (legais, operacionais, de plataforma) | | |
| Headline provisória | | |
| CTA provisório | | |

Sete perguntas — respostas curtas (ver `offer-card.md`):
1. Para quem é: …
2. Qual mudança é prometida: …
3. Como acontece: …
4. O que a pessoa recebe: …
5. Por que acreditar: …
6. Qual esforço e risco permanecem: …
7. Por que decidir agora: …

### Conceito B — ângulo: [nome do ângulo]
(mesma estrutura)

### Conceito C — ângulo: [nome do ângulo]
(mesma estrutura)

## 4. Scorecard comparativo
(tabela de `scorecard.md`, com evidência ao lado de cada nota e lista de notas baixas convertidas em pendência ou hipótese)

## 5. Recomendação
- Conceito recomendado: …
- Justificativa por evidência, clareza, desejo, credibilidade e viabilidade: …
- O que os descartados perdem: …
- Elementos que migram para o vencedor: …

## 6. Offer Card do conceito aprovado
(tabela completa de `offer-card.md`, 13 campos; campo sem informação = AUSENTE)

## 7. Claims e provas pendentes · riscos
| Claim | Prova disponível | Prova necessária | Sensível? | Ação |
|---|---|---|---|---|
| | | | sim / não | |

Riscos legais e operacionais: …

## 8. Aprovação
- Status: rascunho / aprovada
- Aprovada por: … em …
- Condições da aprovação: …

## 9. HANDOFF DO PROJETO
```
HANDOFF DO PROJETO
Etapa concluída: 04 — Mineração de Ofertas
Versão e data:
Objetivo:
Entradas utilizadas:
Evidências confirmadas:
Hipóteses abertas:
Decisões aprovadas:
Artefatos produzidos: 04-oferta-aprovada.md
Claims e provas pendentes:
Riscos e restrições:
Métrica principal:
Portão de aprovação:
Próximo agente: 05 — Copy
Próxima ação única:
```
