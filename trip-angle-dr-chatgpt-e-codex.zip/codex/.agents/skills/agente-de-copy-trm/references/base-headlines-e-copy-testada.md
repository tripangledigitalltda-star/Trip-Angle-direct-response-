# Base de headlines e copy testada — Hopkins, Caples, Schwab

Destilado de três clássicos de resposta direta para uso operacional na modelagem de ofertas. Fontes: Claude Hopkins, *Scientific Advertising*; John Caples, *Tested Advertising Methods*; Victor Schwab, *How to Write a Good Advertisement* (tradução automática consultada). Nota de origem: o arquivo de Caples fornecido para extração veio com OCR corrompido (texto ilegível em toda a extensão); a seção 2 usa o conteúdo consolidado e amplamente documentado do livro, em prosa própria, sem citação literal nem número de página.

## 1. Hopkins — princípios operacionais

| Princípio | O que ele defende | Aplicação |
|---|---|---|
| Publicidade é só venda | Copy é venda escrita multiplicada; todo anúncio deve se justificar como um vendedor se justificaria | [aplicação] meça cada bloco de copy perguntando "isso ajudaria um vendedor a fechar pessoalmente?" |
| Oferecer serviço, não pedir compra | O leitor é egoísta; anúncio bom vende informação e vantagem, não grita "compre" | [aplicação] abra a oferta pelo problema resolvido, não pelo nome do produto |
| Ser específico | Números e fatos concretos pesam; superlativo genérico é descontado pelo leitor | Hopkins cita: "Chavões e generalidades rolam do entendimento humano como água de um pato" (Hopkins, p.30) |
| Amostragem e prova de risco zero | Reduzir o risco do primeiro contato (amostra, teste grátis, devolução) converte melhor que pedir decisão de compra direta | [aplicação] toda oferta nova testa uma variante com trial, amostra ou garantia estendida antes de subir orçamento |
| Campanha de teste acima de opinião | Nenhuma discussão de mesa decide o que funciona; só o teste em pequena escala, com custo e retorno medidos, decide | [aplicação] nunca escale criativo ou oferta sem teste controlado prévio em orçamento pequeno |
| Psicologia do leitor | O publicitário competente entende por que certos estímulos levam à ação; a copy deve seguir reação humana previsível, não gosto pessoal | [aplicação] valide hipótese de gatilho psicológico com dado de resposta, não com preferência do time |
| Headline seleciona o leitor certo | A função do título é isolar quem pode se interessar, não agradar a todos | [aplicação] escreva o headline pensando em uma pessoa específica da persona, não no "público geral" |
| Contar a história completa | O anúncio deve resolver a objeção até o fim; corte por medo de tamanho é erro, não virtude | [aplicação] a VSL ou página só corta quando a objeção foi de fato neutralizada, nunca por "está longo" |
| Nome que carrega a promessa | Um nome de produto ou mecanismo que já conta parte da história economiza esforço de venda | [aplicação] nomeie mecanismo e oferta com uma palavra que já sugira o benefício ou o inimigo |
| Individualidade | Uma voz e um personagem reconhecíveis rendem mais confiança que um anúncio genérico do mercado | [aplicação] fixe um narrador ou personagem consistente na oferta em vez de trocar voz a cada criativo |
| Os melhores anúncios não pedem para comprar | A copy vende demonstrando serviço; o pedido de compra é consequência, não abertura | Hopkins cita: "Os melhores anúncios não pedem a ninguém para comprar" (Hopkins, p.15) |

**Fonte:** Claude Hopkins, *Scientific Advertising*, capítulos 2 (Apenas vendas), 3 (Oferecer serviço), 5 (Manchetes), 6 (Psicologia), 7 (Ser específico), 13 (Uso de amostras), 15 (Campanhas de teste), 17 (Individualidade), 20 (Um nome que ajuda).

## 2. Caples — o que faz uma headline funcionar

**Os três motores de interesse:**
- **Interesse próprio (self-interest):** o leitor só para quando o título promete algo que resolve a vida dele — ganho, economia, ou solução de um incômodo nomeado.
- **Novidade:** anúncio de algo novo (produto, método, descoberta) tira o leitor do piloto automático porque ele ainda não tem uma resposta pronta para ignorar aquilo.
- **Curiosidade:** funciona como gatilho de atenção, mas sozinha (sem benefício embutido) tende a atrair curioso que não compra; Caples recomenda sempre casar curiosidade com um benefício explícito na mesma frase.

**Categorias de headline com o histórico de resposta mais forte, documentadas por Caples:**
1. Oferta gratuita ou de baixo risco anunciada já no título.
2. "Como fazer" (how-to) — promete um método replicável.
3. Pergunta direta que o leitor já se fez sobre o próprio problema.
4. Notícia — algo nomeado como novo, lançado, descoberto.
5. Testemunho/depoimento em primeira pessoa como manchete.
6. Comando direto ao leitor (verbo de ação no imperativo).
7. Redução de risco explícita (garantia, teste, devolução) já na chamada.

**Padrões de abertura documentados no livro (moldes, não frases literais):**
- Abertura por "Como [verbo] [resultado]" — a fórmula mais recorrente nos testes do autor.
- Abertura por pergunta que nomeia o problema do leitor antes de qualquer menção ao produto.
- Abertura por anúncio de novidade ("Agora", "Novo", "Anunciamos").
- Abertura por número ("X maneiras de", "X motivos para") quando o corpo entrega uma lista real.
- Abertura por depoimento citado, com atribuição a uma pessoa nomeada ou perfil de cliente.

**Regras para o corpo da copy:**
- Frase e parágrafo curtos; uma ideia por parágrafo, sem embutir dois argumentos na mesma sentença.
- Falar direto com "você", nunca em terceira pessoa distante.
- Substituir adjetivo vago por número, prazo ou fato checável.
- Repetir o benefício central mais de uma vez com ângulos diferentes, não só uma vez no topo.
- Fechar todo bloco de argumento com a ponte para a ação, nunca deixar o leitor "só informado".

**O que testar primeiro (ordem de prioridade documentada):**
1. Headline — é o elemento que mais move o retorno; teste-a antes de qualquer outra coisa.
2. Oferta e condição de risco (preço, garantia, bônus) — segundo maior impacto.
3. Formato e extensão do corpo da copy.
4. Layout, imagem e elementos visuais — testado por último, porque move menos o resultado do que o texto.

**Fonte:** John Caples, *Tested Advertising Methods* — síntese de conteúdo consolidado da obra; arquivo-fonte fornecido estava com OCR ilegível, sem citação literal nem número de página.

## 3. Schwab — a estrutura de um bom anúncio

| Passo | Função | Aplicação |
|---|---|---|
| 1. Chamar atenção | Vencer a concorrência editorial e de outros anúncios pela própria manchete ou layout | [aplicação] teste o headline isolado, fora do design, perguntando se ele para o scroll sozinho |
| 2. Mostrar vantagem | Deixar claro, cedo, o que o leitor ganha ou economiza usando o produto | [aplicação] a vantagem central aparece nos primeiros segundos de VSL ou na dobra da página |
| 3. Provar | Sustentar a vantagem com prova concreta antes de pedir crença cega | [aplicação] cada claim de benefício vem com prova associada na mesma seção, não só no fim |
| 4. Persuadir a agarrar a vantagem | Traduzir a prova em desejo pessoal de posse, não só em concordância intelectual | [aplicação] reforce identidade e resultado emocional, não apenas o dado técnico |
| 5. Pedir ação | Fechar com instrução clara do próximo passo, sem deixar a decisão em aberto | [aplicação] todo bloco de fechamento tem um único CTA visível, sem ambiguidade |

Schwab reforça que o leitor é um "convidado não convidado" na publicação: "Você, o anunciante, é o Convidado Não Convidado" (Schwab, p.5) — a copy compete por um espaço que não lhe pertence, então precisa pagar a entrada com relevância imediata.

**Categorias de headline descritas por Schwab:**
- **Positiva (ganho):** mostra o que o leitor ganha, economiza ou realiza usando o produto.
- **Negativa (evitar perda):** mostra o risco, erro ou desconforto que o produto evita — Schwab observa que o medo de perder algo que já se tem costuma pesar mais que a chance de ganhar algo novo.
- **Curiosidade pura:** atrai atenção mas, sem benefício embutido, gera leitura de compromisso frouxo.
- **Apelo ao específico:** número, prazo ou fato concreto no título aumenta a crença mais que o adjetivo genérico.
- **Novo vs. velho e testado:** o apelo à novidade compete com o apelo à segurança do que já é comprovado; a escolha depende de qual objeção pesa mais na persona.

**Desejos humanos listados por Schwab** (a lista que ele recomenda usar para ancorar todo benefício):
saúde e vitalidade · mais dinheiro (ganhar, gastar, economizar, doar) · segurança na terceira idade e independência · avanço profissional e social · mais conforto e lazer · aparência e beleza · aprovação e popularidade · orgulho de realização e de posse · superar obstáculos e competição · curiosidade satisfeita · ser reconhecido como autoridade · pertencer e ser aceito socialmente · proteger quem se ama.

**Fonte:** Victor Schwab, *How to Write a Good Advertisement*, capítulo 1 (Chamar atenção) e capítulo sobre vantagens/desejos humanos (tradução automática consultada, p.4–5, p.39–42).

## 4. Banco de padrões de headline e hook

Moldes com lacunas para preencher por oferta — não são frases dos livros, são estruturas extraídas do padrão documentado. Nível de consciência na escala: inconsciente · consciente do problema · consciente da solução · consciente do produto · mais consciente.

| # | Molde | Origem | Nível de consciência |
|---|---|---|---|
| 1 | Como [resultado desejado] sem [sacrifício comum] em [prazo] | Caples | Consciente do problema |
| 2 | [Número] [pessoas/casos] descobriram como [resultado] mesmo [obstáculo] | Caples | Consciente da solução |
| 3 | O erro em [hábito/área] que está [custando/sabotando] seu [resultado] | Hopkins (especificidade) | Consciente do problema |
| 4 | Descubra por que [grupo] consegue [resultado] enquanto [maioria] continua [problema] | Schwab (curiosidade + benefício) | Consciente do problema |
| 5 | Anunciamos: [novidade/mecanismo] que [benefício específico] | Caples (novidade) | Inconsciente / consciente do produto |
| 6 | Você também comete esse erro em [área]? | Schwab (negativo/pergunta) | Consciente do problema |
| 7 | [Prova social: número] já [resultado] usando [método] — veja como | Caples (testemunho) | Consciente da solução |
| 8 | A verdade sobre [crença comum] que [autoridade/indústria] não conta | Schwab (curiosidade) | Consciente do problema |
| 9 | [Nome do mecanismo]: o motivo real por trás de [problema] | Hopkins (nome que ajuda) | Consciente do problema |
| 10 | Se você consegue [ação simples], você consegue [resultado maior] | Caples (facilidade) | Consciente da solução |
| 11 | [Quantidade específica] em [prazo específico] — sem [sacrifício comum] | Hopkins (especificidade) | Consciente da solução |
| 12 | Pare de [ação errada comum] antes que [consequência nomeada] | Schwab (evitar perda) | Consciente do problema |
| 13 | Como [pessoa comum] conseguiu [resultado] mesmo com [limitação relacionável] | Caples (história pessoal) | Consciente do problema |
| 14 | O [adjetivo] jeito de [resultado] que [grupo/autoridade] usa | Schwab (aprovação social) | Consciente da solução |
| 15 | [Risco evitado] garantido: [condição da garantia] ou [devolução] | Hopkins (amostragem/risco zero) | Consciente do produto |
| 16 | Novo em [ano/contexto]: [mecanismo] substitui [método antigo e desgastado] | Caples (novo vs. velho) | Consciente da solução |
| 17 | [Número] sinais de que [problema] está [piorando/custando caro] | Schwab (específico + negativo) | Consciente do problema |
| 18 | O que [autoridade/especialista] faz de diferente para [resultado] | Caples (autoridade) | Consciente da solução |
| 19 | Antes de [ação que a persona já faz], leia isto sobre [risco oculto] | Schwab (curiosidade + perda) | Consciente do problema |
| 20 | [Resultado] em [prazo curto] — o método que [instituição/grupo] testou | Hopkins (teste/prova) | Consciente da solução |
| 21 | Por que [crença popular] está errada sobre [tema da oferta] | Schwab (curiosidade) | Inconsciente |
| 22 | A pergunta que [persona] devia se fazer antes de [decisão comum] | Caples (pergunta) | Consciente do problema |
| 23 | [Número] passos para [resultado], mesmo começando do zero | Caples (lista/how-to) | Consciente da solução |
| 24 | O que ninguém te disse sobre [problema] antes de [evento/decisão] | Schwab (curiosidade + negativo) | Consciente do problema |
| 25 | De [situação ruim nomeada] para [resultado desejado] em [prazo] | Hopkins (específico) + Caples (história) | Consciente do problema |
| 26 | [Grupo específico]: veja como [resultado] sem [objeção comum da persona] | Hopkins (headline seleciona o leitor) | Consciente da solução |
| 27 | O teste que provou que [crença comum sobre a categoria] está errada | Hopkins (campanha de teste) | Consciente da solução |
| 28 | Só funciona se você [condição simples] — veja se é o seu caso | Schwab (qualificação) | Consciente do problema |
| 29 | [Autoridade/instituição] recomenda [ação] para quem sofre com [problema] | Schwab (autoridade + aprovação) | Consciente da solução |
| 30 | A [objeção comum] que impede [resultado] tem solução em [prazo] | Caples (self-interest + objeção) | Consciente do problema |

**Fonte:** moldes derivados de Hopkins (cap. 5, 7, 13, 15, 20), Caples (categorias e fórmulas de abertura documentadas no livro) e Schwab (cap. 1 e lista de desejos humanos, p.5–42).

## 5. Checklist de revisão de copy

1. O headline isola a persona certa, não tenta agradar todo mundo (Hopkins).
2. O headline promete um benefício específico, não um clichê ou superlativo vago (Hopkins).
3. A vantagem principal aparece cedo, nos primeiros segundos ou na primeira dobra (Schwab).
4. Toda claim de benefício vem com prova associada na mesma seção (Schwab).
5. A copy fala direto com "você", em frases e parágrafos curtos (Caples).
6. Números, prazos e fatos concretos substituem adjetivo genérico onde for possível (Hopkins).
7. O anúncio oferece serviço ou informação antes de pedir a compra (Hopkins).
8. Existe redução de risco explícita — amostra, teste, garantia ou devolução (Hopkins).
9. A objeção mais forte da persona foi nomeada e respondida, não ignorada (Hopkins/Schwab).
10. O benefício central é repetido mais de uma vez, com ângulos diferentes (Caples).
11. Todo bloco de argumento termina com uma ponte para a ação, sem deixar o leitor só "informado" (Caples).
12. O fechamento pede uma ação única e clara, sem ambiguidade sobre o próximo passo (Schwab).
13. A voz e o personagem da copy são consistentes do início ao fim (Hopkins).
14. Pelo menos um elemento de novidade ou curiosidade está casado com um benefício explícito, nunca sozinho (Caples).
15. Existe um plano de teste definido: qual elemento muda primeiro (headline), o que muda depois (oferta), o que muda por último (formato/visual) (Caples/Hopkins).

**Fonte:** consolidado de Hopkins (*Scientific Advertising*), Caples (*Tested Advertising Methods*) e Schwab (*How to Write a Good Advertisement*).
