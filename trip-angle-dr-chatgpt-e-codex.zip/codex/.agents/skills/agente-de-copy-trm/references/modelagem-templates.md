# Templates de modelagem (Trip Angle)

## Ficha de Origem
Referência (nome/código) · Fonte preservada (link, arquivo, gravação) · Data, canal, idioma, país · Unidade analisada (Ad / VSL / página / quiz / checkout) · Pergunta estratégica que justifica a escolha (atenção, explicação, desejo, prova, oferta, funil, conversão) · Ficha de Leitura vinculada · Status de linhagem.

## DNA funcional da referência
| Dimensão | O que a referência faz (função, em verbo) | Como faz (superfície, só para registro) | Rótulo |
|---|---|---|---|
| Interrupção / seleção (hook) | | | |
| Relevância e lacuna (lead) | | | |
| Reenquadramento da causa (ângulo / mecanismo do problema) | | | |
| Explicação da solução (mecanismo) | | | |
| Nova oportunidade / Big Idea | | | |
| Promessa e condições | | | |
| Prova (que dúvida reduz) | | | |
| Produto e componentes (que obstáculo removem) | | | |
| Redução de risco (garantia, urgência) | | | |
| Funil (por que cada transição existe) | | | |
| Ordem dos argumentos / progressão de crença | | | |

## Matriz verde / amarelo / vermelho
| Elemento observado | Faixa | Tratamento |
|---|---|---|
| ex.: diagnóstico de 3 perguntas antes da promessa | VERDE — função "permitir autorreconhecimento antes da solução" | pode orientar hipótese |
| ex.: quiz de 16 telas com IMC | AMARELO — padrão contextual (formato/sequência) | exige pesquisa, adaptação e prova própria |
| ex.: "Mounjaro de Pobre", áudio da nutricionista, "4 pessoas comprando agora" | VERMELHO — nome, prova de terceiros, escassez | não reutilizar |

Transferível como função: interromper pela situação; selecionar a pessoa certa; tornar problema complexo compreensível; contraste entre tentativa anterior e nova possibilidade; demonstrar uma etapa do processo; antecipar objeção; reduzir esforço/demora/risco percebido; organizar progressão de crença; definir decisão mensurável.
Precisa nascer de novo: persona e contexto; pesquisa e linguagem; tese, mecanismo e explicação; Big Idea, ângulo, promessa, hooks; produto, método, componentes, experiência; provas, demonstrações e casos autorizados; nome, identidade, estética, ativos; preço, garantia, bônus, escassez, condições; página, VSL, criativos, checkout.

## Card da Hipótese
- Situação X (persona em circunstância, com linguagem própria):
- Princípio Y (função transferida):
- Configuração própria Z (produto/mecanismo/prova/formato):
- Comportamento M esperado:
- Porque R (razão observável):
- Métrica K · Janela J:
- Variável isolada no experimento:
- O que não muda:
- Risco/claim a revisar:

## Nova Configuração da Oferta
Persona em situação · Problema · Mecanismo do problema · Mecanismo da solução · Princípio transferido · Produto próprio · Promessa defensável (sem resultado automático) · Prova própria · Formato/funil · Hipótese de teste.

## Matriz de Linhagem — referência × nova oferta
| Dimensão | Referência (observado) | Nova oferta (reconstruído) | O que foi aprendido | Distância |
|---|---|---|---|---|
| Persona/situação | | | | |
| Problema e mecanismo | | | | |
| Big Idea / ângulo | | | | |
| Promessa | | | | |
| Prova | | | | |
| Produto e stack | | | | |
| Preço, garantia, escassez | | | | |
| Formato e funil | | | | |
| Hook / linguagem | | | | |
| Identidade visual | | | | |

## Auditoria de originalidade (marcar cada item)
[ ] Página em branco · [ ] Identificação reversa · [ ] Dependência · [ ] Transformação · [ ] Prova própria · [ ] Promessa sustentada · [ ] Multiplicidade · [ ] Verbal · [ ] Visual · [ ] Risco.

## Por que isso é modelagem e não cópia (checklist do exemplo)
O problema de mercado mudou · situação e linguagem reconstruídas · mecanismo operacional próprio · produto e demonstração nasceram do novo obstáculo · promessa limitada ao que a entrega controla · nenhum nome, frase, personagem, claim, prova ou ativo reutilizado · o que permaneceu foi apenas a função abstrata.

## Erros mais comuns
Trocar palavras mantendo a copy; traduzir criativo estrangeiro; confundir mecanismo com nome chamativo; modelar promessa sem produto equivalente; usar prova da referência; manter personagem/autoridade/história alheia; escolher oferta "bonita" sem pergunta estratégica; misturar observação com interpretação; mudar tudo no teste; tratar CTR como prova de oferta; urgência/escassez fictícia; ocultar limitações; depender de uma única referência; consultar swipe file antes de entender o problema; encerrar o teste sem registrar aprendizado.
