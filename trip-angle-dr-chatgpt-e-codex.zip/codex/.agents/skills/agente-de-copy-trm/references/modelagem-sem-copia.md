# Modelagem sem copiar (origem: skill agente-de-copy-trm (modelagem-sem-copia.md), consolidada em 13/09/2026)

# Como modelar uma oferta sem copiar (Modo 03 — Modelar)

Objetivo: transformar uma oferta já analisada em uma hipótese original, documentada e pronta para teste controlado, preservando a função estratégica que gerou o insight sem reutilizar identidade, expressão, prova ou claims da referência. Regra central: a referência fornece perguntas e funções; sua pesquisa fornece a linguagem; seu produto fornece a promessa; sua evidência fornece os claims. Se a nova oferta depende das palavras, personagens, provas ou ativos da referência para funcionar, ela ainda não foi modelada.

Cadeia: REFERÊNCIA → ORIGINAL → OBSERVAÇÃO → DNA → FUNÇÃO → PRINCÍPIO → SUPERFÍCIE → TRANSFERIBILIDADE → VARIÁVEL → HIPÓTESE → RECONSTRUÇÃO → AUDITORIA → TEST CARD → DADOS → APRENDIZADO.

Por que tanta cautela: ideias e métodos não têm proteção autoral, mas texto, imagem, vídeo, voz, design e depoimentos têm; e uma oferta que depende de prova alheia não sustenta a própria promessa. Modelagem bem feita produz algo que funciona sozinho.

## Checkpoint de entrada (não avance com item faltando)
[ ] original preservado (link, arquivo ou gravação) · [ ] data, canal, idioma, país, unidade analisada · [ ] Ficha Final de Leitura concluída · [ ] persona em situação, desejo, problema e crença identificados ou marcados NÃO MAPEADO · [ ] mecanismo do problema e da solução separados · [ ] Big Idea, ângulo, promessa, produto, oferta, prova e funil separados · [ ] claims tratados como alegações · [ ] capacidade própria de entrega definida · [ ] origem/autorização das provas próprias conhecida. Se a análise ainda mistura observação com hipótese, volte à leitura.

## Método em 10 etapas
1. **Escolha uma referência útil** por pergunta estratégica (atenção, explicação, desejo, prova, oferta, funil, conversão), não por gosto: anúncio com destino identificável, página/VSL/quiz acessível, produto e condições compreensíveis, alguma prova, situação de público discernível, comparável com outras.
2. **Descreva a função antes de procurar inspiração**: converta substantivos em verbos funcionais (Hook → chamar pela situação reconhecida; Lead → aumentar relevância e abrir lacuna; Ângulo → reenquadrar a causa; Mecanismo → tornar a solução compreensível e diferenciada; Prova → reduzir dúvida específica; Oferta → reduzir risco/esforço/demora; Funil → conduzir do reconhecimento à ação). "Os três portais secretos" é superfície; "organizar um problema confuso em poucas categorias memoráveis" é função.
3. **Extraia o DNA estratégico**: a relação entre as decisões que organizam a venda (template em `modelagem-templates.md`).
4. **Separe princípio, superfície e propriedade** com o semáforo: VERDE função abstrata (autorreconhecimento, contraste, progressão de crença, demonstração, redução de risco) pode orientar hipóteses; AMARELO padrão contextual (tipo de mecanismo, sequência de funil, categoria de prova, formato, modelo de garantia) exige pesquisa, adaptação profunda e prova própria; VERMELHO expressão e ativo (frases, nomes, histórias, personagens, imagens, vídeos, voz, design, depoimentos, números, autoridade, claim, escassez) não se reutiliza.
5. **Escolha a variável estratégica** (situação/persona, problema, mecanismo, ângulo, produto, prova, formato/funil). Na reconstrução, mude tudo o que for necessário para ser própria; no experimento, isole uma variável.
6. **Escreva a hipótese antes da peça**: "Para pessoa em situação X, aplicar o princípio Y por meio da configuração própria Z poderá melhorar o comportamento M, porque R. Saberemos pela métrica K dentro da janela J." Específica, rastreável, limitada, falsificável, compatível com o produto, proporcional à prova, separada de promessa pública.
7. **Reconstrua em página em branco** (feche a referência): situação com palavras da própria pesquisa → progresso desejado → problema sem o nome/metáfora da referência → mecanismo próprio e defensável → produto a partir dos obstáculos reais → promessa limitada ao que a entrega sustenta → prova própria por claim → Big Idea, ângulos, hooks e linguagem originais → formato e funil pela necessidade de compreensão → só então compare com a referência.
8. **Matriz de linhagem** referência × nova oferta (o que foi aprendido, o que foi reconstruído, por dimensão).
9. **Auditoria de originalidade** (dez testes): página em branco · identificação reversa · dependência · transformação · prova própria · promessa sustentada pelo produto · multiplicidade (princípio + pesquisa, não uma única referência) · verbal (sem tradução/paráfrase próxima) · visual (sem clonar layout, personagens, paleta, cenas, ritmo) · risco (marca, copyright, imagem, música, voz, privacidade, categoria sensível). Falhou item crítico → volta à reconstrução; não corrija trocando sinônimos.
10. **Converta em Test Card** (base 14) antes de publicar. "A versão B vendeu mais nesta janela" é observação; "por causa do mecanismo" é interpretação.

## Coerência promessa × produto × prova
O que a pessoa recebe (entregáveis, acesso, prazo, suporte) · que obstáculo cada componente remove · que resultado é controlável · que prova existe · que limites precisam aparecer. Bloqueios: produto abstrato, bônus por volume, promessa dependente de fatores externos, claim forte sem sustentação, omissão material. Registre alegações sensíveis em 12 — Claims e Risco. Claims de prosperidade, dinheiro, cura, saúde, ciência, energia, religião, autoridade, celebridade, escassez, garantia e resultado permanecem qualificados; não usar medo, culpa ou vulnerabilidade como pressão.

## O que este módulo não autoriza
Copiar frases trocando palavras; traduzir e apresentar como nova; manter persona, história, mecanismo, promessa, provas e visual mudando só o nome; reutilizar depoimentos, números, autoridades, imagens, vídeos, áudios, personagens ou escassez de terceiros; declarar referência "validada" por ter anúncios ativos; usar princípio de marketing para justificar alegação que o produto não comprova.

## Rubrica de prontidão (0–2 por critério, máx. 20)
Rastreabilidade · Decomposição · Princípio × superfície · Originalidade · Pesquisa da persona · Mecanismo · Promessa × produto · Prova e claims · Hipótese · Test Card. 16–20 segue para revisão final e teste pequeno; 12–15 revisar lacunas; 0–11 voltar à análise. Zero em originalidade, promessa × produto, prova/claims ou Test Card bloqueia.

## Entregável obrigatório
Uma página com: evidência de origem, DNA funcional, matriz verde/amarelo/vermelho, variável e hipótese, Nova Configuração da Oferta, Matriz de Linhagem, auditoria de originalidade, claims pendentes e Test Card. Templates em `modelagem-templates.md`.
