# Fichas e templates de leitura (literais do Notion Trip Angle)

## 1. Ficha de Fonte e Linhagem
- Código interno da oferta (`PE-Oxx`, `EM-Oxx`…) e versão da análise
- URL do anúncio · URL final · Anunciante/Página · Domínio · País · Idioma
- Data da primeira captura · Data da revisão
- Formato · Texto · Headline · Criativo · CTA
- Transcrição integral (vídeo/áudio) · Ordem dos blocos da página/VSL/quiz
- Produto, entregáveis, preço, parcelas, garantia, condições (quando observados)
- Checkout, bump, upsell, downsell, pós-compra (quando observados)
- Evidências ausentes · Links quebrados
- Status de linhagem: Confirmada / Parcial controlada / Mesclada (materiais de ofertas diferentes misturados → separar antes de analisar)

## 2. Mapa Estratégico da Oferta (DNA — 19 linhas)
| Elemento | Leitura auditada | Rótulo |
|---|---|---|
| Persona | quem é chamado | |
| Situação | circunstância apresentada pela copy; população externa não mapeada | |
| Desejo | funcional / emocional / social / identitário / espiritual quando aplicável | |
| Dor / problema visível | | |
| Crença pressuposta | "a explicação convencional ou o esforço anterior não explica o resultado" | |
| Inimigo narrativo | somente quando aparece no material | |
| Mecanismo do problema | — alegação da copy | |
| Mecanismo da solução | — apresentação da copy, não fato | |
| Mecanismo único de marketing | "Não confirmado; diferenciação percebida: …" | |
| Big Idea | tese central + CONFIRMADA/PROVÁVEL/NÃO CONFIRMADA | |
| Ângulo | enquadramento escolhido | |
| Promessa | resultado associado — alegação | |
| Hook dominante | função, tipo, próximo bloco | |
| Formato dominante | recipiente; formato ≠ argumento | |
| Prova | depoimento/autoridade/demonstração/história — prova alegada | |
| Produto | o que está documentado; não confundir com arquitetura total | |
| Oferta | produto + condições + componentes + CTA quando observados | |
| Funil | Ad → … ; VSL é roteiro, funil é sequência | |
| CTA | conforme o original; não criar CTA novo | |

## 3. Equação estratégica
Persona (…) + Situação (circunstância apresentada) + Desejo (…) + Problema (…) + Nova causa (…) + Mecanismo (…) + Nova solução (produto/método documentado) + Promessa (…, alegação) + Prova (evidência apresentada) + Oferta (produto, condições e CTA observados) = proposta de venda da copy. "Ferramenta de leitura; não significa que a nova causa seja verdadeira ou que o mecanismo funcione."

## 4. Progressão de crença (7 passos)
1. Crença inicial: a pessoa reconhece dor, estagnação ou curiosidade.
2. Tensão: a explicação anterior parece insuficiente.
3. Nova causa: a copy introduz <mecanismo do problema>.
4. Mecanismo: a copy apresenta <mecanismo da solução>.
5. Aceitação da solução: o produto passa a parecer o próximo passo.
6. Redução de risco/prova: demonstração, autoridade, depoimento, stack, garantia ou urgência, quando observados.
7. Ação: CTA original, sem etapa não mapeada.
"A progressão é uma interpretação estratégica. Ela não mede persuasão real."

## 5. Ângulo em 11 dimensões
Tese · situação · desejo · inimigo · emoção · contraste · reframe · mecanismo · persona · consciência · a própria tese como enquadramento.

## 6. Matriz Claim → Prova → Limite
| Claim (literal) | Tipo (resultado, mecanismo, velocidade, autoridade, escassez, saúde, financeiro) | Prova apresentada | O que a prova sustenta | Limite / risco | Evidência real disponível | Reformulação segura |

## 7. Mapa do Funil
| Etapa | Ação solicitada | Expectativa criada | Dado necessário | Observado? |
|---|---|---|---|---|
| Anúncio | clicar / assistir | por que prestar atenção | impressão, retenção, clique | |
| Quiz / página / VSL | avançar / comprar | por que a tese e a oferta fazem sentido | visita, avanço, lead | |
| Checkout | pagar | quais condições serão contratadas | início, abandono, compra | |
| Pós-compra | ativar / consumir | como começar e receber valor | entrega, ativação, uso | |
Teste de congruência: mudança inesperada de preço, público, mecanismo ou resultado rompe a continuidade. Para cada seta: o que a pessoa acabou de ver, o que espera, que dúvida precisa resolver, qual a única ação, que dado registrar, o que acontece se não avançar.

## 8. Ficha Final de Leitura (DNA, princípio, hipótese)
| Elemento | Leitura auditada |
|---|---|
| Persona / situação | |
| Problema apresentado | explicação da copy, não verdade universal |
| Desejo | |
| Mecanismo da solução | |
| Big Idea | |
| Ângulo | |
| Hook | |
| Prova observada | e o que não prova |
| Produto | |
| Oferta / funil | condições ausentes permanecem não mapeadas |
| Princípio transferível | função → função → função |
| Não transferível | nome, promessa, tradição, currículo, autores, frases, provas, CTA |
| Hipótese | "testar X contra Y, medindo Z" |
"O exemplo confirma a tese comunicada, não a eficácia ou performance comercial."

## 9. Roteiro operacional completo
A — Fonte e contexto: identifique a fonte primária e preserve o original; registre anunciante, domínio, país, idioma, data e versão; transcreva Ads, VSL, página, quiz e checkout; diferencie presença publicitária de performance.
B — Demanda: identifique o produto sem usar a promessa como descrição; quem é chamado; situação e evento de mudança; separe problema, dor, desejo e crenças; soluções tentadas; estágio de consciência.
C — Tese: mecanismo do problema; mecanismo da solução; separe mecanismo, método, produto e skin; nova oportunidade; Big Idea; ângulo e promessa.
D — Persuasão: separe Hook de Lead; formato, canal e placement; desmonte o anúncio por função; progressão da VSL/página; provas, objeções e claims; limite de cada prova.
E — Oferta e extração: separe produto de oferta; stack, preço, garantia, CTA e condições; funil e transições; DNA; princípio funcional vs superfície proprietária; transferível vs não; nova hipótese com identidade, produto e prova próprios; uma variável no Test Card.

## 10. "Faça você primeiro" (seis perguntas antes do gabarito)
1. Persona e situação: quem é chamado e em qual circunstância concreta?
2. Dor e desejo: qual tensão é apresentada e quais dimensões de desejo estão documentadas?
3. Hook, Lead e Ângulo: qual é a entrada, como ela é desenvolvida e qual enquadramento aparece?
4. Mecanismo e prova: qual causa e solução a copy apresenta e qual limite tem a prova?
5. Produto, oferta e funil: o que é entregue, quais condições aparecem e quais etapas são observáveis?
6. Modelagem e teste: qual função pode ser transferida sem copiar superfície, claims ou identidade? Proponha uma variável.

## 11. Comparação transversal (quando houver duas ou mais ofertas)
Passa quando aponta: (1) função comum; (2) tese específica de cada uma; (3) skin/identidade que não se copia; (4) classificação da Big Idea; (5) limite de evidência; (6) uma variável de Test Card. Classificação entre ofertas: clone só com coincidência simultânea de produto, mecanismo e entrega; senão VARIANTE / EXPANSÃO / NOVA FAMÍLIA. Vocabulário semelhante não prova mecanismo igual. Não importar inteligência de um nicho para outro.
