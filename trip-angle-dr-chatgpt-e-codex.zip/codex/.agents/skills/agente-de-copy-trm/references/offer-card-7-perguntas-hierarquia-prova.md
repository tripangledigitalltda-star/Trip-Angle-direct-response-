# Offer Card, sete perguntas e hierarquia de prova (versão consolidada)

Fonte única para a Etapa 04 e para o módulo 03 — Engenharia de Ofertas, Copy e Vendas. As duas páginas de origem traziam redações divergentes; esta versão é a união dos campos, sem acréscimo de conteúdo novo. Onde a redação diverge, a escolha está anotada.

## As sete perguntas obrigatórias

Toda oferta responde às sete. Pergunta sem resposta sustentada por evidência é lacuna declarada, não texto de preenchimento.

| # | Pergunta | O que a resposta precisa conter |
|---|---|---|
| 1 | **Para quem é?** | Recorte de público e situação específica. |
| 2 | **Qual mudança é prometida?** | Resultado específico, responsável e delimitado. |
| 3 | **Como acontece?** | Mecanismo da solução e sequência de etapas. |
| 4 | **O que a pessoa recebe?** | Produto, entregáveis, acesso, suporte e limites. |
| 5 | **Por que acreditar?** | Evidência adequada ao claim: demonstração, evidência, processo, credencial ou caso verificável. |
| 6 | **Qual esforço e risco permanecem?** | Tempo, participação, requisitos e limitações. |
| 7 | **Por que decidir agora?** | Motivo verdadeiro: janela, capacidade, agenda, bônus ou custo da espera. Nunca escassez inventada. |

Nota de consolidação: a pergunta 5 usa a redação do módulo 03 (lista os tipos de evidência); a Etapa 04 dizia apenas "evidência adequada ao claim". A pergunta 7 usa os exemplos de motivo do módulo 03.

## Offer Card

Preencha todos os campos para o conceito recomendado. Campo sem informação recebe **AUSENTE** e vira item em "Claims e provas pendentes" ou "Riscos e restrições" do handoff.

| Campo | Preenchimento | Origem do campo |
|---|---|---|
| Público + situação | Quem enfrenta qual momento específico. | 03 e 04 |
| Transformação | Do estado atual ao estado desejado. | 03 e 04 |
| Mecanismo do problema | Por que o problema persiste apesar das alternativas atuais. | 04 |
| Mecanismo da solução | Princípio e sequência que tornam a mudança plausível. | 03 e 04 |
| Entregáveis e limites | O que entra, formato, duração, acesso, o que não está incluído. | 03 e 04 |
| Suporte e prazo | Canal, cadência e duração do suporte; prazo de entrega ou acesso. | 04 |
| Prova disponível | Evidências verificáveis e relevantes para o claim, com fonte. | 03 e 04 |
| Prova ainda necessária | O que precisaria existir para sustentar cada claim ainda sem prova. | 04 |
| Objeções | Confiança, valor, tempo, esforço, prioridade, autoridade e risco. | 03 e 04 |
| Preço e condições | Valor, parcelas, renovação, custos adicionais e regras. | 03 e 04 |
| Garantia e limites | O que é coberto, prazo, procedimento e exclusões claras. | 03 e 04 |
| CTA | Uma próxima ação objetiva. | 03 e 04 |
| Riscos legais e operacionais | Claims sensíveis, política de plataforma, capacidade de entrega, reembolso. | 04 |

Critério de fechamento (checkpoint 3 do módulo 03): a oferta é entendida sem adjetivos vagos; o mecanismo é plausível; escopo e limites estão visíveis; cada claim importante tem prova correspondente.

## Hierarquia de prova

Use sempre a prova mais próxima possível da promessa. Quanto mais abaixo na lista, menor o alcance do claim que ela sustenta.

1. Demonstração do produto ou processo.
2. Dados próprios com método e contexto.
3. Caso verificável semelhante ao público.
4. Depoimento específico e autorizado.
5. Credencial relevante.
6. Explicação plausível.
7. Opinião.

Prova inexistente bloqueia claim forte: o claim volta a ser hipótese até a prova existir.

## Claims sensíveis

Resultados financeiros, saúde, emagrecimento, segurança, garantia de retorno, crianças e comparações absolutas exigem revisão própria antes de qualquer publicação. Aplicam-se o Código de Defesa do Consumidor (arts. 36–38), o Código do CONAR e a LGPD/ANPD para dados pessoais. Não publicar prova, depoimento ou urgência fabricados.
