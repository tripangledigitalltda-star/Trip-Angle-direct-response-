# Ofertas pós-compra

Origem: regras de order bump, upsell e downsell do AGENTE DE FUNIL (`../../agente-de-funil-trm/references/checkout-e-ofertas-de-compra.md`), equação de valor e melhoria de oferta de `../../agente-de-copy-trm/references/base-oferta-e-mecanismo.md`. Faixas de preço e posições abaixo são **ponto de partida derivado**, para testar, não regra da casa.

## Princípio
Cada oferta adicional resolve o **próximo obstáculo** que o cliente vai encontrar depois de comprar: fazer mais rápido, com menos esforço, com mais certeza ou ir além do resultado inicial. Oferta que não conversa com a compra só aumenta atrito e reembolso.

## Order bump
- **O que é:** complemento pequeno, marcado pelo próprio cliente no checkout.
- **Bom bump:** acelera, facilita ou protege o resultado do produto principal (lista de compras pronta, versão em áudio, planilha, bônus de implementação).
- **Preço:** baixo em relação ao principal, para ser decisão de impulso. Ponto de partida derivado: 20% a 50% do preço do front.
- **Copy:** título com benefício, uma ou duas frases, preço claro, caixa desmarcada.
- **Não pode:** pré-seleção, custo escondido, bump que muda as condições da compra principal.

## Upsell
- **O que é:** oferta mostrada depois do pagamento aprovado, antes do acesso.
- **Bom upsell:** o próximo passo lógico. Ex.: front ensina o que fazer; upsell entrega feito, acompanhado ou mais rápido.
- **Formato:** página curta ou vídeo curto; continuidade com a compra ("parabéns, seu acesso está garantido; antes de entrar..."), uma decisão, recusa visível.
- **Um clique:** use o upsell de um clique da plataforma quando existir.
- **Preço:** pode ser maior que o front; justificado pelo obstáculo que remove.

## Downsell
- Oferecido uma única vez, só a quem recusou o upsell.
- Versão menor, parcelada ou sem um componente do upsell. Não é o mesmo produto mais barato sem motivo, o que desvaloriza o upsell.

## Página de obrigado
Confirmação da compra · como e quando acessar · primeiro passo · suporte · convite para grupo ou comunidade se existir · pedido de opt-in do WhatsApp com finalidade clara.

## Escada de ascensão
| Degrau | Função | Exemplo em infoproduto |
|---|---|---|
| Front | Resolver um problema específico e gerar primeira vitória | Ebook, protocolo, minicurso |
| Bump | Facilitar o front | Material prático complementar |
| Upsell | Próximo obstáculo | Programa completo, acompanhamento em grupo |
| Recorrência | Manter o resultado | Assinatura, comunidade, cardápios mensais |
| Alto ticket | Feito com você ou para você | Mentoria, consultoria |
Convide para o próximo degrau depois da primeira vitória, não antes.

## Ficha de cada oferta
Nome · degrau · obstáculo que remove · público (todos ou segmento) · preço e condição · posição no fluxo · argumento em uma frase · copy · prova disponível · claims para o COMPLIANCE · métrica (taxa de aceitação) · meta declarada.
