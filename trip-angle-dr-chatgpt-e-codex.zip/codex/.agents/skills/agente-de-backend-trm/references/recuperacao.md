# Recuperação de vendas

Origem: follow-up orientado por contexto do módulo 03 (motivo, valor, CTA e condição de saída; recapitulação, evidência, fechamento do ciclo) e regras de consentimento do AGENTE DE COMPLIANCE. Tempos abaixo são **ponto de partida derivado**; ajuste ao prazo de expiração de Pix e boleto da plataforma e teste.

## Regras
- Configure primeiro a recuperação nativa da plataforma de checkout e evite mandar duas mensagens iguais por ferramentas diferentes.
- Só contate quem deixou contato no checkout com base legal para isso, e sempre com saída (descadastro, "não quero receber").
- WhatsApp com opt-in e canal oficial. Poucas mensagens, espaçadas, com valor.
- Nunca inventar escassez, desconto "que acaba em 10 minutos" sem prazo real, ou pressão emocional.

## Sequências por situação
| Situação | Gatilho | Mensagem 1 | Mensagem 2 | Mensagem 3 | Saída |
|---|---|---|---|---|---|
| Carrinho abandonado | Dados preenchidos, sem pagamento | ~15–60 min: lembrete útil com link direto do checkout | ~24 h: responder a objeção principal (prova, garantia, como funciona) | ~48–72 h: fechamento do ciclo | Sem resposta: parar |
| Pix gerado e não pago | Pix emitido, não compensado | Poucos minutos: código e passo a passo para pagar | Antes de expirar: aviso de expiração e novo código se necessário | Após expirar: link para gerar outro pagamento | Parar após a 3ª |
| Boleto emitido | Boleto gerado | Logo após: linha digitável e prazo | Véspera do vencimento: lembrete | Após vencer: link para nova forma de pagamento | Parar |
| Cartão recusado | Transação recusada | Imediato: tentar outro cartão ou Pix, sem expor dado | ~1–3 h: link com meios alternativos | — | Parar |
| Upsell recusado | Recusa na página | Opcional, no dia seguinte ao acesso: benefício do upsell ligado à primeira vitória | — | — | Não insistir |

## Moldes de mensagem (adaptar à voz do COPY)
**Lembrete útil (carrinho):** "Oi, [nome]. Seu pedido de [produto] ficou em aberto. Se foi falta de tempo, o link continua aqui: [link]. Qualquer dúvida sobre [ponto comum de dúvida], é só responder."

**Evidência (objeção):** "Você deixou [produto] no carrinho. Muita gente pergunta [objeção real]. [Resposta com prova ou garantia]. Se isso resolve, finalize aqui: [link]."

**Fechamento do ciclo:** "Não quero ficar insistindo. Se ainda fizer sentido, [link]. Se não for o momento, tudo bem: não envio mais mensagens sobre este pedido."

**Pix:** "Seu Pix de [valor] para [produto] foi gerado. Para pagar: abra o app do banco, escolha Pix copia e cola e cole o código: [código]. Ele vale até [horário]."

## Registro mínimo por contato (módulo 03)
Data e canal · etapa · necessidade e impacto · objeção aberta · material enviado · decisão e responsável · próxima ação e data · motivo de perda ou pausa.
