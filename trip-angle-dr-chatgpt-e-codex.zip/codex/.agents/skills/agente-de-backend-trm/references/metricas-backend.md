# Métricas do backend

## Fórmulas
- **Receita líquida do front** = preço − taxas da plataforma e de pagamento − impostos.
- **Valor esperado do bump** = taxa de aceitação × receita líquida do bump.
- **Valor esperado do upsell** = taxa de aceitação × receita líquida do upsell.
- **Valor esperado do downsell** = (1 − aceitação do upsell) × aceitação do downsell × receita líquida do downsell.
- **Perda por reembolso** = taxa de reembolso × (receita líquida do front + valores adicionais reembolsados).
- **Contribuição por cliente** = receita líquida do front + bump + upsell + downsell − reembolso − custo variável de entrega.
- **Vendas recuperadas** = abandonos contatados × taxa de recuperação; entram como vendas adicionais sem custo de mídia direto.
- **CPA de equilíbrio com backend** = contribuição por cliente. Comparar com o CPA de equilíbrio só do front mostra quanto o backend sustenta.
- **AOV (valor médio do pedido)** = receita bruta ÷ número de pedidos.

## Painel semanal
| Métrica | Fonte | Semana atual | Semana anterior | Meta declarada |
|---|---|---|---|---|
| Vendas do front | Plataforma | | | |
| Aceitação do bump | Plataforma | | | |
| Aceitação do upsell e do downsell | Plataforma | | | |
| AOV | Plataforma | | | |
| Abandono de checkout e recuperação | Plataforma e ferramenta | | | |
| Pix e boleto pagos ÷ gerados | Plataforma | | | |
| Taxa de acesso em 48 h | Área de membros | | | |
| Reembolso e motivo principal | Plataforma | | | |
| Chargeback | Plataforma | | | |
| Contribuição por cliente | Cálculo | | | |

## Leitura
- Janela de reembolso ainda aberta: contribuição é provisória. Não escale mídia com base nela.
- Aceitação de bump muito baixa: argumento ou relação com o produto, antes de preço.
- Upsell alto com reembolso alto: promessa desalinhada ou pressão na página.
- Recuperação baixa com abandono alto: primeiro checar atrito no checkout (FUNIL), depois a sequência.
- Um teste por vez; registrar hipótese, variável, janela e decisão.
