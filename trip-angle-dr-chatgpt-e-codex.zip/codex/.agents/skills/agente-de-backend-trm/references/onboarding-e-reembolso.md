# Onboarding, reembolso e prova real

Regra base: reembolso cai quando o cliente acessa, começa e percebe valor cedo. O direito de arrependimento de 7 dias do CDC não pode ser dificultado; o trabalho é de ativação, não de retenção forçada.

## Primeiros 7 dias (sequência base, derivada)
| Momento | Canal | Objetivo | Conteúdo |
|---|---|---|---|
| Imediato | E-mail e WhatsApp (com opt-in) | Acesso | Link de acesso, login, onde começar, suporte |
| Dia 1 | E-mail ou WhatsApp | Primeira vitória | Uma ação de 10–15 minutos que gera resultado visível (ex.: a primeira receita, o primeiro cardápio) |
| Dia 2 ou 3 | E-mail | Remover travas | Dúvidas mais comuns, como usar no dia a dia |
| Dia 4 ou 5 | WhatsApp ou e-mail | Engajamento | Pergunta simples sobre o progresso; convite para o próximo passo do produto |
| Dia 6 ou 7 | E-mail | Consolidar | Resumo do que já foi feito, próximo marco, apoio disponível |
Quem não acessou em 24 a 48 horas recebe mensagem específica de acesso.

## Pedido de reembolso
1. Processar conforme o direito do cliente, sem condicionar.
2. Perguntar o motivo de forma opcional e curta (não acessou, não era o esperado, dificuldade técnica, arrependimento de compra, outro).
3. Se for dificuldade técnica ou de acesso, oferecer ajuda **junto com** a confirmação de que o reembolso segue se ele quiser.
4. Registrar motivo para o COPY (promessa desalinhada?) e para o FUNIL (checkout confuso?).

## Chargeback
Evidências a guardar: confirmação da compra, acesso e uso registrados, comunicações, termos aceitos. Chargeback alto sinaliza promessa desalinhada, cobrança não reconhecida (nome na fatura diferente da marca) ou fraude: investigar a causa.

## Prova real a partir do backend
- Pedir depoimento depois da primeira vitória, com pergunta aberta sobre o que mudou.
- Autorização escrita para uso em anúncio e página, com nome ou anonimização combinada.
- Registrar contexto: tempo de uso, ponto de partida, o que fez. Resultados atípicos marcados como atípicos.
- Enviar ao AGENTE DE COPY como prova autorizada, com o arquivo da autorização.
