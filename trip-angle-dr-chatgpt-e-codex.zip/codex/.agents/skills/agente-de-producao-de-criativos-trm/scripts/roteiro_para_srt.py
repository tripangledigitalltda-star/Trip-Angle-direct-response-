#!/usr/bin/env python3
"""Gera legenda .srt e lista de textos na tela a partir do roteiro CSV.
Uso: python3 roteiro_para_srt.py roteiro.csv [--max-chars 42]
CSV: inicio_s,fim_s,imagem_acao,fala,texto_tela,som,funcao (modelo em assets/roteiro-modelo.csv).
A fala de cada linha é dividida em blocos de até 2 linhas, com tempo proporcional ao tamanho.
Legenda baseada no roteiro: confira contra o áudio final antes de exportar.
"""
import csv, sys, textwrap, os

def ts(s):
    ms = int(round(s * 1000)); h, ms = divmod(ms, 3600000); m, ms = divmod(ms, 60000); sec, ms = divmod(ms, 1000)
    return f"{h:02d}:{m:02d}:{sec:02d},{ms:03d}"

def main():
    a = sys.argv[1:]
    if not a: print(__doc__); sys.exit(1)
    mx = int(a[a.index("--max-chars")+1]) if "--max-chars" in a else 42
    rows = list(csv.DictReader(open(a[0], encoding="utf-8")))
    srt, n, tela, avisos = [], 1, [], []
    for r in rows:
        i, f = float(r["inicio_s"]), float(r["fim_s"]); fala = (r.get("fala") or "").strip()
        if r.get("texto_tela", "").strip(): tela.append(f"{ts(i)} → {ts(f)} · {r['funcao']} · {r['texto_tela'].strip()}")
        if not fala or fala.startswith("["): 
            if fala.startswith("["): avisos.append(f"linha {r['inicio_s']}s: fala não preenchida")
            continue
        linhas = textwrap.wrap(fala, mx); blocos = [linhas[k:k+2] for k in range(0, len(linhas), 2)]
        total = sum(len(" ".join(b)) for b in blocos); t = i
        for b in blocos:
            d = (f - i) * len(" ".join(b)) / total
            srt.append(f"{n}\n{ts(t)} --> {ts(t+d)}\n" + "\n".join(b) + "\n"); n += 1; t += d
            if d < 0.8: avisos.append(f"bloco curto demais ({d:.2f}s) em {r['inicio_s']}s: encurte a fala ou aumente a cena")
    base = os.path.splitext(a[0])[0]
    open(base + ".srt", "w", encoding="utf-8").write("\n".join(srt))
    open(base + "_texto_tela.txt", "w", encoding="utf-8").write("\n".join(tela) + "\n")
    print(f"{n-1} legendas → {base}.srt\n{len(tela)} textos na tela → {base}_texto_tela.txt")
    for x in avisos: print("aviso:", x)

if __name__ == "__main__": main()
