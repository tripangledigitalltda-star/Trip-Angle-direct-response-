# Roteiro e storyboard

Origem: 04 — Criativos e Biblioteca Visual da Trip Angle (seções 1.2, 4.4, 5.1 e lista de planos).

## Estrutura-base de resposta direta
1 Hook: ganha atenção relevante · 2 Contexto: para quem e em qual situação · 3 Problema: organiza a tensão · 4 Mecanismo: explica causa ou solução · 5 Prova: reduz incerteza · 6 Oferta: apresenta o próximo caminho · 7 CTA: indica ação e consequência. "Um público muito consciente pode começar por oferta; um público consciente do problema pode precisar de contexto e mecanismo."

## Roteiro técnico (colunas obrigatórias)
| Tempo/cena | Imagem e ação | Fala/voz | Texto na tela | Som | Função |
|---|---|---|---|---|---|
| 0–3 s | | | | | Hook: atenção relevante |
| 3–10 s | | | | | Situação ou problema: identificação |
| 10–20 s | | | | | Mecanismo ou demo: compreensão |
| 20–27 s | | | | | Prova e oferta: reduzir dúvida |
| 27–30 s | | | | | Produto ou ação: CTA |
"Os tempos são um ponto de partida, não uma regra." Vídeos mais longos repetem o miolo (mecanismo e prova) sem mudar a mensagem.

## Regra da unidade
Um público dominante · uma situação principal · uma mensagem memorável · uma prova prioritária · um CTA principal. Várias cenas podem existir; argumentos concorrentes não.

## Checkpoints do roteiro
- Se o som for desligado, a abertura continua compreensível?
- Se o primeiro frame for removido, o restante cumpre o que ele prometeu?
- O hook usa as primeiras palavras e o primeiro visual para chamar a persona do card?
- O CTA diz a ação e o que acontece depois, igual à página de destino?

## Storyboard
Um quadro por linha do roteiro: número · tempo · enquadramento (plano geral, médio, close, detalhe, tela) · ação · texto na tela e posição · transição. Pode ser rascunho ou imagem gerada por IA a partir da imagem canônica.

## Lista de planos a captar ou gerar
Plano principal · B-roll obrigatório · demonstração · closes de produto ou interface · reações · tela final · captação de áudio · versões sem texto e sem música · autorizações de pessoas, locais e marcas.

## Formatos e risco comum
UGC/creator: fingir espontaneidade · Talking head: monólogo sem apoio visual · Demonstração: mostrar sem explicar · Screen recording: texto pequeno e dados expostos · Estático: excesso de texto · Carrossel: primeiro cartão sem motivo para avançar · Testimonial: resultado sem contexto ou permissão · Animação: estética que distrai.
