# Criativos e Biblioteca Visual — templates literais (04)

## Entregáveis obrigatórios
1 Creative Card · 2 Swipe diagnóstico · 3 Matriz de conceitos (ângulo × hook × formato × prova) · 4 Roteiro/storyboard (cena, fala, texto, som, duração) · 5 Kit visual · 6 Ativo mestre · 7 Pacote de adaptações · 8 Checklist de QA e compliance · 9 Test Card · 10 Registro de aprendizado.

## Como usar o módulo
1 Escolha uma oferta real · 2 Abra o briefing do módulo 03 · 3 Pesquise referências com objetivo definido · 4 Selecione uma hipótese de ângulo e uma prova · 5 Estruture conceito, hook e formato · 6 Roteiro/storyboard · 7 Ativo mestre · 8 Derivações por canal (não redimensionamento automático) · 9 QA e compliance · 10 Pacote aprovado ao módulo 05.

## Ficha de decomposição de referência (swipe diagnóstico)
URL e data · país, idioma, canal · oferta e público aparente · estágio de consciência · ângulo · primeiro frame · hook verbal · texto na tela · formato e duração · corpo do argumento · mecanismo/prova · objeção tratada · CTA · elementos de produção · o que é observável · o que é só interpretação · hipótese reutilizável.
Pode reaproveitar: sequência narrativa; tipo de pergunta; categoria de hook; forma de demonstrar; lógica de prova; ritmo ou contraste; relação problema–CTA. Não copie: texto integral; identidade/personagem/rosto; cenas e composição reconhecíveis; depoimento ou resultado; logo, música, vídeo, PI; promessa que sua oferta não sustenta. Fontes: Meta Ad Library, TikTok Creative Center, YouTube ABCD, concorrentes, avaliações/comentários/calls/suporte.

## Formatos — funciona bem para / risco
UGC/creator-led — identificação, experiência / fingir espontaneidade · Talking head — autoridade, mecanismo, objeções / monólogo sem apoio · Demonstração — produto, interface, processo / mostrar sem explicar · Screen recording — SaaS, tutoriais / texto pequeno, dados sensíveis · Estático — uma ideia, contraste, oferta direta / excesso de texto · Carrossel — etapas, lista / primeiro cartão sem motivo · Testimonial/case — prova, objeções / resultado sem contexto ou permissão · Animação/motion — conceito abstrato, mecanismo, dados / estética que distrai.
Formatos registrados na base 06: UGC testemunhal + demonstração de objeto; UGC de alerta/sintoma + livro; unboxing demonstrativo; especialista para câmera + análise; professor para câmera; testemunho de ritual simples; testemunho religioso + oração; professor/storytelling longo; storytelling de figura pública; storytelling histórico com objeto; rotina noturna/UGC 10 min; storytelling de linhagem. Estrutura-padrão: hook → problema → explicação/mecanismo → prova ou autoridade → oferta → CTA.

## Lista de planos e plataformas
Plano principal; B-roll obrigatório; demonstração; closes de produto/interface; reações; tela final; captação de áudio; versões sem texto e sem música; autorizações de pessoas, locais e marcas. TikTok 9:16 ≥720p com safe zone; Shorts vertical social-first; YouTube ABCD (Atenção, Branding, Conexão, Direção); Meta adapta assets por placement. Adaptação: Reels/Stories 9:16 com área segura e legendas; feeds quadrado/vertical; in-stream 16:9; display múltiplas proporções. Acessibilidade: legendas sincronizadas, não depender só de cor, contraste 4,5:1, sem texto pequeno, testar sem som.

## Kit de identidade e prompt
Kit: marca; persona (idade aparente, traços, cabelo, pele, corpo, voz, roupa, papel); realismo (documental, creator, editorial, publicitário, 3D, ilustração); ambiente; câmera; luz; composição; continuidade; restrições.
Modelo: "Criar [tipo de asset] para [objetivo/placement]. Mostrar [persona com identidade fixa] realizando [ação] em [ambiente]. Composição [plano/posição/espaço], câmera [lente/ângulo], luz [descrição], paleta [cores], acabamento [realismo/estilo]. Manter [elementos de continuidade]. Evitar [restrições]."
Consistência: mesma referência de personagem; atributos bloqueados; uma dimensão por vez; ficha de lente/luz/paleta; imagem canônica antes das cenas; revisar mãos, texto, objetos, reflexos, anatomia, logos.
Pastas: 00_BRIEF · 01_REFERENCIAS · 02_ASSETS-MESTRE · 03_ROTEIROS · 04_EDICOES · 05_EXPORTS · 06_APROVADOS · 07_RESULTADOS.

## QA (marcar tudo)
Estratégica: [ ] corresponde ao Creative Card · [ ] consciência correta · [ ] uma mensagem · [ ] hook e corpo contínuos · [ ] prova corresponde ao claim · [ ] CTA combina com destino.
Visual/técnica: [ ] primeiro frame compreensível · [ ] texto legível no celular · [ ] legenda/voz/som revisados · [ ] resolução/proporção/duração · [ ] área segura · [ ] sem artefatos de IA · [ ] URL e tracking correspondem à versão · [ ] export assistido do início ao fim.
Factual: [ ] números com fonte · [ ] depoimentos genuínos e autorizados · [ ] demonstração representa uso real · [ ] comparação justa · [ ] urgência e escassez verdadeiras · [ ] limitações não escondidas.
Direitos: [ ] licenças (música, fonte, imagem, vídeo, template) · [ ] autorizações (voz, rosto, local, marca) · [ ] contrato de creator · [ ] dados pessoais ocultados · [ ] avatar não imita pessoa real · [ ] arquivo de autorização vinculado.

## Test Card criativo
Hipótese · Evidência de partida · Variável principal · Controle · Versões · Público/canal/placement · Janela e orçamento · Métrica principal · Métricas de guarda · Critério de decisão · Resultado · Aprendizado · Próximo teste.

## Briefing para 05 — Tráfego
ID e nome do criativo · versão da oferta · hipótese e variável · público e consciência · ângulo, hook, formato, duração · placement e arquivo · URL de destino · evento e métrica · controle e variantes · claims e restrições · janela, orçamento, regra de pausa · decisão esperada.

## Sprint de 10 dias
D1 Creative Card · D2 Swipe diagnóstico · D3 Matriz priorizada · D4 Seleção de execuções · D5 Plano de produção · D6–7 Ativos mestres · D8 Pacote por placement · D9 Aprovação documentada · D10 Test Card + briefing 05. Rubrica 0–2 × 10: 17–20 pronto para teste; 12–16 corrigir; 0–11 voltar ao briefing.

## Exemplo (clínicas) — três conceitos, uma onda
A Situação: hook visual "notificações acumulam em três telas", verbal "Quantos contatos ficam sem resposta porque ninguém sabe quem vem primeiro?", UGC + B-roll. B Objeção: "Automatizar triagem não significa automatizar a conversa", talking head + demo. C Demonstração: "Veja o que acontece nos primeiros 30 segundos após um novo contato", screen recording. Manter oferta, CTA e duração; variar só os três ângulos.
