# Kit visual, prompts e TRM LAB

Origem: 04 — Criativos e Biblioteca Visual (kit de identidade e prompt) e estrutura do TRM LAB CRIATIVOS.

## Kit de identidade
Marca · persona (idade aparente, traços, cabelo, pele, corpo, voz, roupa, papel no vídeo) · realismo (documental, creator, editorial, publicitário, 3D, ilustração) · ambiente · câmera · luz · composição · continuidade · restrições.

## Modelo de prompt da casa
"Criar [tipo de asset] para [objetivo/placement]. Mostrar [persona com identidade fixa] realizando [ação] em [ambiente]. Composição [plano/posição/espaço], câmera [lente/ângulo], luz [descrição], paleta [cores], acabamento [realismo/estilo]. Manter [elementos de continuidade]. Evitar [restrições]."
Para vídeo, acrescente: duração da tomada, movimento de câmera, ação do começo ao fim da tomada e o que não pode mudar entre tomadas.

## Consistência
Mesma referência de personagem em todas as cenas · atributos bloqueados · mudar uma dimensão por vez · ficha fixa de lente, luz e paleta · gerar a imagem canônica antes das cenas · revisar mãos, texto, objetos, reflexos, anatomia e logos.

## Limites para pessoas geradas por IA
- Não imita pessoa real, celebridade, médico ou influenciador identificável.
- Não se apresenta como cliente, paciente ou especialista, nem dá depoimento de resultado.
- Não mostra antes e depois corporal nem resultado de saúde.
- Sinalize conteúdo gerado ou alterado por IA quando a plataforma ou a lei exigir.

## TRM LAB como fonte de produção
- Pastas de "hooks" têm clipes de B-roll mudo de 3 a 12 s, organizados por tipo (identificação, prova social, segredo, transformação, quebra de padrão e outros). Use como abertura visual ou cobertura, sempre com a fala e o texto próprios.
- "TRM FORMATOS" tem exemplos numerados de formatos. Cite o número do formato no card para manter a linhagem.
- Liste pastas com `python3 agente-de-ads-trm/scripts/lab_listar.py <id-da-pasta>` e registre na lista de B-roll: pasta · arquivo · id · cena onde entra · segundos usados.
- Antes de usar clipe de terceiros do laboratório em anúncio pago, confirme origem e direito de uso. Sem confirmação, use só como referência de enquadramento.

## Pastas da produção
00_BRIEF · 01_REFERENCIAS · 02_ASSETS-MESTRE · 03_ROTEIROS · 04_EDICOES · 05_EXPORTS · 06_APROVADOS · 07_RESULTADOS.
