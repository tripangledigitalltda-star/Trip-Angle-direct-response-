# Adaptação por placement e export

Origem: 04 — Criativos e Biblioteca Visual (planos e plataformas, acessibilidade) e nomenclatura de `../../agente-de-trafego-trm/references/base-trafego-e-escala.md`.

## Placements e proporções
| Placement | Proporção | Cuidados |
|---|---|---|
| Reels, Stories, TikTok, Shorts | 9:16 | Área segura: texto e rosto longe das bordas superior e inferior e da lateral direita onde ficam botões; legendas; resolução mínima 720p |
| Feed Facebook e Instagram | 4:5 ou 1:1 | Recompor, não esticar; texto legível em tela pequena |
| In-stream e YouTube | 16:9 | Marca e mensagem cedo; estrutura ABCD (Atenção, Branding, Conexão, Direção) |
A Meta adapta assets por placement, mas o operador revisa a prévia de cada um. Confirme as especificações atuais da plataforma antes do export final.

## Recompor em vez de cortar
Grave ou gere com margem. Para cada proporção, reposicione o sujeito, reescreva a posição do texto na tela e confira a área segura. Quando não houver margem, use fundo estendido ou desfocado em vez de cortar rosto, produto ou texto.

## Legendas e acessibilidade
Legendas sincronizadas em todo vídeo · não depender só de cor · contraste mínimo 4,5:1 · sem texto pequeno · testar sem som · no máximo duas linhas por legenda.

## Textos do anúncio
| Campo | Regra |
|---|---|
| Texto principal | Primeira linha carrega o hook; aprovado pelo COPY |
| Título | Promessa ou benefício da página de destino |
| Descrição | Complemento opcional |
| CTA do botão | Coerente com a ação da página |

## Nomes de arquivo e anúncio
Padrão da base de tráfego: `ÂNGULO__HOOK__FORMATO__PERSONA__VERSÃO`, acrescido de `__PROPORÇÃO` no arquivo exportado. Exemplo: `ANG_MECANISMO__HOOK_PERGUNTA__UGC__MULHER40__V01__9x16.mp4`. Códigos em maiúsculas, sem acento, sem espaço.

## Manifesto de variações (colunas)
nome · angulo · hook · formato · persona · versao · proporcao · duracao_s · variavel_da_onda · controle (sim/não) · arquivo · texto_principal · titulo · cta · url_destino · status_qa · autorizacoes
