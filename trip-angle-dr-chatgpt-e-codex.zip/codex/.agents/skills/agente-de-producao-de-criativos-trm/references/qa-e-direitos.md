# QA e direitos (marcar tudo por peça)

Origem: 04 — Criativos e Biblioteca Visual.

## Estratégica
- [ ] Corresponde ao Creative Card
- [ ] Consciência correta
- [ ] Uma mensagem
- [ ] Hook e corpo contínuos
- [ ] Prova corresponde ao claim
- [ ] CTA combina com o destino

## Visual e técnica
- [ ] Primeiro frame compreensível
- [ ] Texto legível no celular
- [ ] Legenda, voz e som revisados
- [ ] Resolução, proporção e duração corretas
- [ ] Área segura respeitada
- [ ] Sem artefatos de IA (mãos, texto, objetos, reflexos, anatomia, logos)
- [ ] URL e tracking correspondem à versão
- [ ] Export assistido do início ao fim

## Factual
- [ ] Números com fonte
- [ ] Depoimentos genuínos e autorizados
- [ ] Demonstração representa uso real
- [ ] Comparação justa
- [ ] Urgência e escassez verdadeiras
- [ ] Limitações não escondidas

## Direitos
- [ ] Licenças de música, fonte, imagem, vídeo e template
- [ ] Autorizações de voz, rosto, local e marca
- [ ] Contrato de creator
- [ ] Dados pessoais ocultados
- [ ] Avatar não imita pessoa real
- [ ] Arquivo de autorização vinculado

## Erros que mais geram retrabalho (04)
Abrir a ferramenta antes do briefing · confundir imagem bonita com criativo estratégico · copiar anúncio sem entender o princípio · testar ângulo, hook, formato e CTA ao mesmo tempo · usar personagem diferente em cada cena · adaptar 16:9 para 9:16 apenas cortando · colocar texto demais no primeiro frame · criar hook que o corpo não entrega · usar depoimento, resultado ou especialista fictício · ignorar licenças e autorizações · medir apenas CTR · não registrar versão, hipótese e resultado · escalar peça sem revisar a entrega da oferta · acumular exports sem nome e sem vínculo com testes.
