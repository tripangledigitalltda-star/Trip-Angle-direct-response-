# Arquitetura do produto

Origem: "Como Criar uma Oferta do Zero", fase 4 (produto a partir dos obstáculos), "Como Modelar uma Oferta sem Copiar" (coerência promessa × produto × prova) e Playbook de Oferta DR (gate zero de produto), da Trip Angle. Faixas e exemplos de formato marcados como derivados.

## Do obstáculo ao componente (método da casa)
obstáculo → resultado intermediário → prova de conclusão → formato → componente

| Obstáculo do cliente | Resultado intermediário | Prova de conclusão | Formato | Componente |
|---|---|---|---|---|
| Ex.: não sabe o que comer no café da manhã | Café da manhã definido para a semana | Lista marcada dos 7 cafés | Cardápio + lista de compras | Módulo 1, página X |

## Camadas possíveis (casa)
Diagnóstico e plano · método central · ferramentas e templates · implementação guiada · suporte · acompanhamento · comunidade · medição. Use só as camadas que removem obstáculo da persona e que a operação consegue entregar.

## Bônus (casa)
Bônus que não remove obstáculo, acelera ou reduz risco só aumenta volume. Para cada bônus: qual obstáculo, em que momento do uso, qual resultado.

## Gate de produto (Playbook)
"Existe uma entrega definida, acessível e compatível com a promessa?" Se falhar: bloquear.

## Coerência promessa × produto × prova (modelagem)
O que a pessoa recebe (entregáveis, acesso, prazo, suporte) · que obstáculo cada componente remove · que resultado é controlável · que prova existe · que limites precisam aparecer. Bloqueios: produto abstrato, bônus por volume, promessa dependente de fatores externos, claim forte sem sustentação, omissão material.

## Primeira vitória
Uma ação curta, no primeiro uso, que gera resultado visível e conectado à promessa. Escreva em uma frase: "No primeiro dia, a pessoa consegue [resultado visível] fazendo [ação] em [tempo]." Coloque no início do produto e na mensagem de acesso.

## Formatos comuns em infoproduto de DR (derivado)
| Formato | Serve para | Cuidado |
|---|---|---|
| Ebook ou guia | Explicar método e dar referência | Não virar texto longo sem ação |
| Protocolo de N dias | Sequência diária com tarefa e marco | Dias com tarefa clara e realista |
| Cardápio e lista de compras | Remover decisão diária | Porções e substituições; aviso de saúde |
| Receitas | Execução prática | Ingredientes acessíveis, tempo real, fotos próprias ou licenciadas |
| Checklist e planilha | Acompanhar progresso | Simples, imprimível |
| Videoaulas | Demonstração e confiança | Curtas, uma ideia por aula |
| Comunidade ou suporte | Dúvidas e constância | Só se a operação sustentar |

## Escada de valor
Front resolve um problema específico e gera primeira vitória · bump facilita o front · upsell remove o próximo obstáculo · recorrência mantém o resultado. Coordene com o AGENTE DE BACKEND para que cada degrau exista de fato.
