# Produção de conteúdo do produto

## Regras de escrita
- Linguagem da persona, frases curtas, verbo no imperativo quando for instrução.
- Cada capítulo termina com uma ação concreta.
- Nada de encher: se uma página não ajuda a executar, sai.
- Termos técnicos explicados na primeira vez.

## Moldes

### Ebook ou guia
Capa · como usar este material (uma página) · primeira vitória · capítulos (conceito curto → passo a passo → exemplo → ação) · materiais práticos · próximos passos · aviso legal e fontes.

### Protocolo de N dias
Visão geral dos N dias · preparação (lista de compras, o que separar) · um bloco por dia: objetivo do dia · tarefa · tempo estimado · marco de conclusão · dica de dificuldade comum · fechamento com revisão e próximo ciclo.

### Cardápio
Tabela por dia e refeição · porção indicativa · substituições · lista de compras por semana · observação de que é um exemplo geral, não prescrição individual.

### Receita
Nome · rende · tempo de preparo · ingredientes com medidas · modo de preparo numerado · substituições · dica de armazenamento · informação nutricional só com fonte e método de cálculo citados.

### Checklist ou planilha
Título · objetivo · itens marcáveis ou colunas de acompanhamento · instrução de uso em uma linha.

### Roteiro de videoaula
Objetivo da aula · abertura com o problema em 1 frase · demonstração em passos · erro comum · ação da aula · duração-alvo curta.

## Saúde, alimentação e emagrecimento
- Conteúdo educativo e de rotina. Não diagnosticar, não prescrever para doença, não prometer quilos com prazo, não sugerir suspender ou substituir medicamento.
- Aviso visível no início e no fim: o material não substitui acompanhamento de médico ou nutricionista; pessoas com condições de saúde, gestantes e lactantes devem consultar um profissional antes.
- Informação nutricional: cite a fonte (por exemplo, a Tabela Brasileira de Composição de Alimentos, TACO, ou rótulo do fabricante) e diga que são valores aproximados.
- Se um profissional real assina o conteúdo, ele revisa e aprova, e o material respeita o código de ética do conselho dele.

## Direitos e originalidade
- Não copiar texto, receita com texto idêntico, imagem ou estrutura de produto concorrente, livro ou site.
- Imagens próprias, licenciadas ou geradas por IA revisadas; registre a origem em uma lista de licenças.
- Fontes de dados e referências listadas no fim do material.
