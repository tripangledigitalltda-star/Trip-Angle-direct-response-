# Entrega, matriz promessa × produto e QA

## 1. Área de membros
Estrutura: boas-vindas (vídeo ou texto curto com o primeiro passo) · Módulo 1 com a primeira vitória · módulos seguintes na ordem de uso · materiais para download · bônus · suporte e dúvidas frequentes.
Ordem de liberação: tudo liberado ou por dias, conforme o método. Liberação por dias só se a copy não prometeu acesso imediato a tudo.
Textos de acesso para o BACKEND: e-mail e WhatsApp de boas-vindas, lembrete de primeiro acesso, mensagem da primeira vitória.

## 2. Matriz promessa × produto (obrigatória)
| Promessa, benefício ou bônus da copy | Onde aparece na copy | Componente que entrega | Página ou aula | Status (entregue, ajustar copy, incluir no produto) |
|---|---|---|---|---|
Nenhuma linha pode ficar sem componente na entrega final.

## 3. QA do produto (marcar tudo)
Promessa e entrega
- [ ] Todas as linhas da matriz têm componente
- [ ] Primeira vitória no início, curta e visível
- [ ] Bônus prometidos entregues com o nome usado na copy
Conteúdo
- [ ] Cada capítulo ou dia termina com ação
- [ ] Linguagem da persona, sem jargão sem explicação
- [ ] Sem depoimento, resultado, estudo ou especialista inventado
- [ ] Aviso de saúde no início e no fim, quando o tema for saúde ou alimentação
- [ ] Informação nutricional com fonte ou retirada
Direitos
- [ ] Textos e receitas originais
- [ ] Imagens próprias, licenciadas ou geradas com revisão; lista de licenças salva
- [ ] Profissional citado real, com autorização e revisão
Arquivo e acesso
- [ ] PDF revisado página por página (quebras, tabelas, imagens, links)
- [ ] Legível no celular
- [ ] Área de membros testada com um acesso de teste
- [ ] Links de download funcionando
